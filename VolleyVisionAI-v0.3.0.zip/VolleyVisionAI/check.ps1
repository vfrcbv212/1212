﻿$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
if (-not (Test-Path '.venv\Scripts\python.exe')) { throw 'Сначала выполните .\setup.ps1' }
& .\.venv\Scripts\python.exe scripts\doctor.py
if ($LASTEXITCODE -ne 0) { throw 'Найдены проблемы установки. См. список выше; данные не изменены.' }
