﻿$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
if (-not (Test-Path '.venv\Scripts\python.exe')) { throw 'Сначала выполните .\setup.ps1' }
if (-not (Test-Path 'frontend\dist\index.html')) { throw 'Интерфейс не собран. Выполните .\setup.ps1' }
Write-Host 'VolleyVision AI: http://localhost:8765 — оставьте это окно открытым. Остановка: Ctrl+C или .\stop.ps1'
& .\.venv\Scripts\python.exe scripts\serve.py
if ($LASTEXITCODE -ne 0) { throw 'Сервер завершился с ошибкой. См. журнал выше.' }
