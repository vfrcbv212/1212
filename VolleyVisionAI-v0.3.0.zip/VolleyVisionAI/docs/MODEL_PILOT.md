# Реальная локальная детекция: запуск, проверка, ограничения

В этой стадии подключён настоящий YOLOX ONNX, не демонстрационный адаптер. Он выдаёт person/sports-ball bbox и confidence на исходных кадрах. Без внешнего сервиса. **Детекция не распознаёт волейбольные действия, номера игроков и исходы розыгрышей.**

## Установка и повторение
```powershell
.\.venv\Scripts\python.exe -m pip install -r requirements-ai.lock
.\.venv\Scripts\python.exe scripts\install_models.py --model yolox-tiny
.\.venv\Scripts\python.exe scripts\install_models.py --model yolox-tiny --check
```
Linux: `.venv/bin/python` вместо Windows-пути. Для сравнения установить `--model all`, затем:
```powershell
.\.venv\Scripts\python.exe scripts\benchmark_models.py --output docs\CPU_MODEL_PILOT.json
```
Проверка без сети: `--check`; установка из заранее скопированного **точного** официального ONNX: `--model yolox-tiny --offline-path C:\Models\yolox_tiny.onnx`. Размер/SHA256 нельзя отключить или заменить для обхода ошибки. При неудаче новая `.part` удаляется, старый файл не используется как проверенный. Нужны официальный GitHub и release-assets.githubusercontent.com только во время установки. После установки анализ локальный.

В исходном архиве нет крупных весов и venv. `data/models/` сохраняется на диске пользователя отдельно. Источники, версии, точные хеши и условия — MODEL_REGISTRY.md, docs/MODEL_SOURCES.md.

## API для конвейера
- `get_runtime_info(model_id='yolox-tiny',device='auto')`: наличие/проверка весов, optional-зависимости, доступные providers, предварительный выбор, хеш/версия. Сессия при этом не создаётся.
- `YoloXDetector(model_id,device,strategy)` создаёт проверенную локальную сессию; `detect_frame(bgr)` возвращает наблюдения пиксельных bbox. `runtime` записывает фактически активный provider и время загрузки.
- `scan_segment(path,start,end,sample_fps=5,strategy='fullframe',device='auto',cancel_event=None,progress=None,detector=None)`: сегмент до60s, интервал `[start,end)`, потоковое декодирование. `detector` можно переиспользовать между сегментами. Возвращает frames/time/detections, manifest и фактические timings. Пауза выбрасывает InterruptedError, не выдаёт неполный сегмент за готовый.
- Таймкоды читаются из исходного videoPTS. Если backend не предоставляет монотонные PTS и доступен FPS, используется явно отмеченное `estimated_frame_index`; это не гарантия точного кадра для VFR. Профиль OCR/касания по такой записи требует отдельной проверки.
- Person/ball-треки: heuristic greedy-IoU, IDs ограничены сегментом. `player_id/team_id=None`, identity unknown. Не создаются виртуальные/интерполированные контакты или очки.

Два режима поиска мяча: fullframe и tiles (полный кадр +4 перекрывающихся высокодетальных view). Tiles сохраняет область полёта над полом и не превращает отсутствие детекции в аут. Он делает больше inference-вызовов и не назван «точным» без реального пилота. Смена вида детектора/масштаба/частоты должна входить в ключ кеша анализа.

## Что действительно измерено
Проверено на Linux CPU, ONNX Runtime1.32.0, NumPy2.5.4, OpenCV5.0.0.93. Небольшое настоящее NASA-фото с человеком, публичное достояние; полный источник/хеш в CPU_MODEL_PILOT.json. Один человек найден обоими моделями; warm/cold timings и4 комбинации записаны отдельно. Конфигурация Tiny/fullframe выбрана как быстрый **начальный CPU smoke baseline**, не как самая точная для iPhone-волейбола.

Отдельный unit/integration test строит1s MP4 из этого фото и действительно выполняет inference на sourcePTS0/.5s. Это сконструированный ролик, не матч; он доказывает работу видео-конвейера и отмены, не precision/recall событий. Ни соседние кадры, ни одно фото не считаются train/test-пилотом.

Не измерены: волейбольный мяч, номера, ID-switches на игроках, границы розыгрышей/действия/исходы, реальный матч IMG_2011.mp4, 4K/HEVC-съёмка iPhone, Windows/CUDA/VRAM и Safari. Для этих метрик в замерах null с причиной, не нулевые ошибки. Система с нулём принятых событий здесь не называется качественным автоматическим анализатором.
