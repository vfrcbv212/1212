# Источники и проверка условий моделей

Проверено по официальным источникам 2026-11-15 (клиентская дата). Это проверка доступных документов и происхождения артефактов, не заявление о качестве на волейболе. Крупные веса и пользовательские видео в Git не помещаются. Контрольные суммы фактически скачанных YOLOX записывает установщик/реестр модели.

## YOLOX Tiny / Small ONNX

- Официальный репозиторий: https://github.com/Megvii-BaseDetection/YOLOX
- Наблюдённый `main`: `6ddff4824372906469a7fae2dc3206c7aa4bbaee`.
- Тег `0.1.1rc0`: `e1052df71842031413f6030723c3607b839c80ce`.
- Лицензия кода Apache-2.0, документ доступен с TLS-проверкой: https://raw.githubusercontent.com/Megvii-BaseDetection/YOLOX/0.1.1rc0/LICENSE
- Точные готовые ONNX-артефакты связаны **официальным** текущим руководством: https://raw.githubusercontent.com/Megvii-BaseDetection/YOLOX/6ddff4824372906469a7fae2dc3206c7aa4bbaee/demo/ONNXRuntime/README.md
- Tiny: https://github.com/Megvii-BaseDetection/YOLOX/releases/download/0.1.1rc0/yolox_tiny.onnx — HEAD200, 20 219 662 байта, вход416×416.
- Small: https://github.com/Megvii-BaseDetection/YOLOX/releases/download/0.1.1rc0/yolox_s.onnx — HEAD200, 35 858 002 байта, вход640×640.
- Это COCO-детекторы 80 классов, включая person и sports ball. Они не являются моделями волейбольных касаний, номеров или результатов розыгрыша.
- Отдельного текста лицензии **именно бинарных весов**, отличного от лицензии официального проекта, в просмотренных документах не найдено. Происхождение официальное; нельзя выдавать это за найденный отдельный model card или разрешение на перепубликацию чужих обучающих изображений. Веса загружаются пользователем из официального источника, а не встраиваются в архив приложения.
- У старого README на самом теге и текущего README отличаются ссылки на release storage и опубликованные mAP; чужие mAP не являются результатом данного пилота. Пользоваться точным URL/хешем выбранного артефакта.

## RF-DETR Nano / Small

Официальный сайт лицензий https://roboflow.com/model-licenses/rf-detr блокируется прокси этой среды (403), но официальный исходник README доступен:

- https://raw.githubusercontent.com/roboflow/rf-detr/b49df291cdd6b8d19fb722ab402e9a018d2edcd4/README.md
- https://raw.githubusercontent.com/roboflow/rf-detr/b49df291cdd6b8d19fb722ab402e9a018d2edcd4/LICENSE
- В `License` явно указаны Apache-2.0 для пакета и моделей detection Nano/Small/Medium/Large, а PML1.0 для Atto/Femto/Pico/XL/2XL из `rfdetr[plus]`. Не переносить Apache-2.0 автоматически на Plus-модели.
- Официальный реестр артефактов: https://raw.githubusercontent.com/roboflow/rf-detr/b49df291cdd6b8d19fb722ab402e9a018d2edcd4/src/rfdetr/assets/model_weights.py
- Nano URL: https://repo.roboflow.com/rfdetr/nano_coco/checkpoint_best_regular.pth ; опубликованный MD5 `fb6504cce7fbdc783f7a46991f07639f`.
- Small URL: https://repo.roboflow.com/rfdetr/small_coco/checkpoint_best_regular.pth ; опубликованный MD5 `fb37061c1af7bace359c91b723a8d5c1`.
- Запрос HEAD к официальному серверу весов отклонён прокси403. Эти модели не скачаны и не измерены здесь; SHA256/размер не выдуманы. MD5 здесь — опубликованная метаинформация производителя, не замена собственной SHA256-проверки после скачивания.
- Формат .pth не исполнять через небезопасный full-pickle loader. У текущего исходника RF-DETR предусмотрен `trust_checkpoint=False` и `weights_only=True`; предпочитать проверенный ONNX/weights-only при будущей интеграции.

## TrackNet и волейбольные веса

Просмотренный https://github.com/yastrebksv/TrackNet прямо называет реализацию неофициальной и предназначенной для теннисных телезаписей1280×720/30fps. Ссылка на веса ведёт в Google Drive; отдельная лицензия весов и волейбольные контрольные данные не установлены. Не скачивать и не выдавать их за разрешённые волейбольные веса.

https://github.com/Chang-Chia-Chi/TrackNet-Badminton-Tracking-tensorflow2 содержит MIT-лицензию кода: https://raw.githubusercontent.com/Chang-Chia-Chi/TrackNet-Badminton-Tracking-tensorflow2/main/LICENSE . Это бадминтонная реализация; условия точных готовых волейбольных весов/датасета не подтверждены. Исследовательский подход можно оценить после подготовки разрешённых данных, но готовность модели не заявляется.

## Датасет и тестовые изображения

Официальный COCO terms URL https://cocodataset.org/#termsofuse блокируется прокси403. Лицензия `cocoapi/license.txt` относится к API-коду, а не ко всем изображениям COCO. Нельзя объявлять все фотографии COCO Apache/MIT или одной CC-лицензией; права исходных Flickr-изображений следует проверять индивидуально. Датасет для обучения не скачивался.

Разрешённый небольшой **реальный** проверочный снимок человека: Eileen Collins/NASA из `scikit-image`:

- https://raw.githubusercontent.com/scikit-image/scikit-image/v0.19.3/skimage/data/astronaut.png
- Пояснение происхождения и прав: https://raw.githubusercontent.com/scikit-image/scikit-image/v0.19.3/skimage/data/_fetchers.py , функция `astronaut`: “No known copyright restrictions, released into the public domain”, NASA Great Images, исходная ссылка https://flic.kr/p/r9qvLn .
- На нём можно проверять реальный инференс класса person, но **нет спортивного мяча**, поэтому он не измеряет recall мяча, волейбольные события или качество на iPhone.

Commons API/хост изображений также блокируются403. Достоверно лицензированный реальный кадр с мячом и точной разметкой в этой среде пока не установлен. Не подменять его случайным JPEG из репозитория с неизвестными правами и не рисовать ball precision/recall по изображению без мяча.

## ONNX Runtime CPU/GPU — отдельные установочные профили

Повторно проверено2026-11-15 по официальным источникам:

- Официальный исходник CUDA EP документации, pinned commit `e3d000e3fe1b113c4153e6250dd605c2d03da3f0`: https://raw.githubusercontent.com/microsoft/onnxruntime/e3d000e3fe1b113c4153e6250dd605c2d03da3f0/docs/execution-providers/CUDA-ExecutionProvider.md . Обычный сайт onnxruntime.ai в этой среде заблокирован403; источник из официальной ветки gh-pages доступен с TLS.
- Документ говорит: PyPI GPU-пакеты начиная с1.27 по умолчанию собраны с CUDA13.0; отдельная CUDA12-сборка требует12.8+, она не подменяется автоматически. Таблица сайта заканчивается1.30.x, поэтому **строка1.32.x не выдумана**.
- Точный `onnxruntime-gpu==1.32.0` дополнительно проверен по https://pypi.org/pypi/onnxruntime-gpu/1.32.0/json и https://raw.githubusercontent.com/microsoft/onnxruntime/v1.32.0/setup.py : CUDA extras требуют `nvidia-cuda-nvrtc~=13.0`, `nvidia-cuda-runtime~=13.0`, `nvidia-cufft~=12.0`, `nvidia-curand~=10.0`, cuDNN extra — `nvidia-cudnn-cu13~=9.0`.
- Официальный CPython3.12 Windows AMD64 wheel: `onnxruntime_gpu-1.32.0-cp312-cp312-win_amd64.whl`, 157765830bytes, PyPI SHA256 `d8bc5d7668872889d605c1e7253581e021db7dea41a142ad2ab78d6d96f3f289`. ORT MIT; NVIDIA DLL-пакеты имеют собственные условия, часто `LicenseRef-NVIDIA-Proprietary`, а не MIT/Apache. Их не включаем в исходный ZIP и не называем открытыми весами модели.

`requirements-ai.lock` остаётся реально проверенным CPU-профилем. `requirements-ai-cuda.lock` фиксирует **отдельный потенциально совместимый** Windows/NVIDIA профиль и runtime-колёса. Все указанные Windows wheel-версии доступны в официальном PyPI; они не устанавливались/не запускались на GPU в данной среде:

| Пакет | Точная версия | Windows wheel, байт |
|---|---|---:|
| onnxruntime-gpu[cuda,cudnn] |1.32.0|157765830|
| nvidia-cuda-nvrtc |13.0.88|76807835|
| nvidia-cuda-runtime |13.0.96|2927037|
| nvidia-cufft |12.0.0.61|213342123|
| nvidia-curand |10.4.0.35|55242481|
| nvidia-cudnn-cu13 |9.12.0.46|303914745|
| nvidia-cublas |13.0.2.14|401887280|
| nvidia-nvjitlink |13.0.88|36035115|

Наличие wheel не доказывает совместимость конкретного драйвера/ПК. GPU-профиль скачивает примерно1.25GB runtime-пакетов, не обновляет системный драйвер и требует проверки установленного NVIDIA-драйвера. CPU и GPU ONNX Runtime нельзя одновременно устанавливать в один venv. Поддерживаемый API `onnxruntime.preload_dlls()` вызывается перед CUDA-session: он ищет уже установленные NVIDIA/PyTorch/system DLLs. После создания session сохраняется реально выбранный provider; `device='cuda'` отвергает уход на CPU, `auto` явно отмечает fallback. Наличие `CUDAExecutionProvider` ещё не является измерением VRAM или доказательством размещения каждого оператора на GPU (`gpu_operator_placement_verified=false`). Все Windows/CUDA/VRAM/FPS-показатели остаются непроверенными до запуска на целевом ПК.

### Телеметрия и установка весов

Официальный https://raw.githubusercontent.com/microsoft/onnxruntime/v1.32.0/docs/Privacy.md отмечает, что отключение через API может происходить после минимального initialization event. Поэтому `vision.py` выставляет `ORT_DISABLE_TELEMETRY=1` **до импорта ONNX Runtime**, затем дополнительно вызывает `disable_telemetry_events()` перед session. Приложение не обращается к внешнему AI API. Самостоятельно импортирующие ORT диагностические/служебные скрипты должны соблюдать тот же порядок.

Установщик модели теперь проверяет каждый HTTPS target **до** следующего HTTP-запроса: разрешены только github.com, release-assets.githubusercontent.com и objects.githubusercontent.com, без userinfo/необычных портов. Не более6 ответов цепочки; затем размер и SHA256 точного артефакта обязательны. Неподдерживаемое перенаправление не запрашивается даже при настройке HTTP-клиента follow_redirects. TLS/контрольные суммы не отключаются.
