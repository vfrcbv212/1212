# Актуальная версия — 0.3.0, пилот локальной детекции
Продолжение0.2/ec8c7fa в том же репозитории. Промежуточный интеграционный коммит `4aad91d`; следующий коммит фиксирует выпуск, его SHA смотреть `git log -1`.

Работают: ручная база0.2; resumable/browser+allowlist/local import; setup/маска/произвольные ориентиры/карточки; реальные Tiny/Small ONNX CPU; простые локальные треки; сегментный cache/resume; автооткрывающийся HTML/версированные JSONCSVXLSX; backup setup/analysis/uploads; local/remote-private middleware и Windows-скрипты.

Финальный прогон:268 backend passed (55.62s),27 frontend passed,3 browser E2E passed (16.4s),0failed/0skipped; Ruff/build/Alembic/doctor успешны. Логи `docs/validation`, подробности TEST_REPORT.md и docs/VALIDATION_MATRIX.md. Источники моделей/лицензионные оговорки MODEL_REGISTRY.md/docs/MODEL_SOURCES.md. Файлы weights только data/models, не Git/архив исходников.

Это НЕ полный AI-разбор волейбола: OCR/игровые действия/исходы/автосчёт не реализованы, accepted_events0. Реальное качество матча не измерено, IMG_2011.mp4 недоступен; Windows/NVIDIA/iPhone/другая сеть/Tailscale тариф не проверены. Ничего не push и не опубликовано.

Версионный кандидат распакован и проверен: новый сервер/БД, настоящий CPU-анализ/отчёт/экспорты/остановка прошли. Доказательства `docs/validation/release-smoke.*`. Финальные документы не меняют core-код. Далее — реальный фрагмент и эталон, нативная Windows/GPU/iPhone-приёмка, затем события/идентификация. Точка продолжения и чеклисты: docs/PROJECT_STATE.md, docs/TASKS.md, docs/RESUME_PROMPT.md. Не повторять пройденные проверки без новой причины.
