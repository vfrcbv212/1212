﻿param([switch]$WithAI, [ValidateSet('cpu','cuda')][string]$Device = 'cpu')
$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
if (-not (Get-Command git -ErrorAction SilentlyContinue)) { throw 'Установите Git с git-scm.com: он нужен для резервной копии кода и истории.' }
if (-not (Get-Command py -ErrorAction SilentlyContinue)) { throw 'Установите Python 3.12 с python.org (Python Launcher).' }
& py -3.12 -c "import sys; assert sys.version_info[:2] == (3,12); print(sys.version)"
if ($LASTEXITCODE -ne 0) { throw 'Нужен Python 3.12.' }
if (-not (Get-Command node -ErrorAction SilentlyContinue)) { throw 'Установите Node.js 22 LTS или 24 LTS с nodejs.org.' }
& node -e "let v=process.versions.node.split('.').map(Number); if(v[0]<22 || (v[0]===22 && v[1]<12)) process.exit(1)"
if ($LASTEXITCODE -ne 0) { throw 'Нужен Node.js 22.12+ или 24 LTS.' }
foreach ($tool in @('ffmpeg','ffprobe')) { if (-not (Get-Command $tool -ErrorAction SilentlyContinue)) { throw "Добавьте $tool в PATH. Ссылки на официальные сборки: https://ffmpeg.org/download.html" } }
if (Get-Command nvidia-smi -ErrorAction SilentlyContinue) { & nvidia-smi } else { Write-Host 'NVIDIA GPU не обнаружена. Текущая версия работает на CPU; CUDA не требуется.' }
& py -3.12 -m venv .venv
if ($LASTEXITCODE -ne 0) { throw 'Не удалось создать venv.' }
& .\.venv\Scripts\python.exe -m pip install -r requirements.lock
if ($LASTEXITCODE -ne 0) { throw 'Ошибка установки Python-зависимостей.' }
Push-Location frontend
try {
    & npm.cmd ci
    if ($LASTEXITCODE -ne 0) { throw 'Ошибка npm ci.' }
    & npm.cmd run build
    if ($LASTEXITCODE -ne 0) { throw 'Ошибка сборки интерфейса.' }
} finally { Pop-Location }
& .\.venv\Scripts\python.exe -m alembic upgrade head
if ($LASTEXITCODE -ne 0) { throw 'Ошибка миграции базы.' }
if ($WithAI) { & (Join-Path $PSScriptRoot 'setup-ai.ps1') -Device $Device }
Write-Host 'Установка завершена. Запустите .\start.ps1. AI отдельно: setup-ai.ps1'
