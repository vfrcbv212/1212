import importlib.util
import json
import zipfile

from volleyvision.db import DATA, ROOT

spec = importlib.util.spec_from_file_location("backup_next", ROOT / "scripts" / "backup.py")
backup = importlib.util.module_from_spec(spec)
spec.loader.exec_module(backup)


def test_backup_keeps_calibration_observations_and_omits_access_secrets_and_weights(tmp_path, client):
    for folder in ("setup", "analysis/fixture", "models", "uploads/fixture"):
        (DATA / folder).mkdir(parents=True, exist_ok=True)
    (DATA / "setup" / "13.json").write_text('{"revision":2,"cards":[]}', encoding="utf-8")
    (DATA / "analysis" / "fixture" / "summary.json").write_text('{"accepted_events":0}', encoding="utf-8")
    (DATA / "models" / "secret-large-weight.onnx").write_bytes(b"not-a-model-test-fixture")
    (DATA / "remote-private.json").write_text('{"upstream_token":"SYNTHETIC_SECRET_NOT_REAL"}')
    (DATA / "uploads" / "fixture" / "manifest.json").write_text('{"status":"incomplete"}')
    archive = backup.backup(tmp_path / "metadata.zip", data=DATA)
    with zipfile.ZipFile(archive) as z:
        names = z.namelist()
        assert "data/setup/13.json" in names
        assert "data/analysis/fixture/summary.json" in names
        assert not any("/models/" in n or "/uploads/" in n or n.endswith("remote-private.json") for n in names)
        manifest = json.loads(z.read("manifest.json"))
        assert manifest["analysis_configuration_included"] is True
        assert manifest["model_weights_included"] is False
    restored = backup.restore(archive, tmp_path / "restored")
    assert json.loads((restored / "data" / "setup" / "13.json").read_text())["revision"] == 2
    assert (restored / "data" / "analysis" / "fixture" / "summary.json").is_file()
    # Don't leak fake fixture state into other tests sharing their temporary DATA.
    for path in (
        DATA / "models" / "secret-large-weight.onnx",
        DATA / "remote-private.json",
        DATA / "uploads" / "fixture" / "manifest.json",
    ):
        path.unlink(missing_ok=True)


def test_full_backup_restores_actual_run_cards_manual_correction_and_source(tmp_path, client, match, monkeypatch):
    import sqlite3
    import time
    import pytest
    from volleyvision import vision

    models = ROOT / "data" / "models"
    monkeypatch.setenv("VOLLEYVISION_MODELS_DIR", str(models))
    if not vision.get_model_manifest("yolox-tiny")["verified"]:
        pytest.skip("Для полного inference/backup сценария нужны проверенные optional веса")
    event = client.post(
        f"/api/matches/{match.mid}/events",
        json={
            "rally_id": match.rally,
            "time": 1,
            "kind": "attack",
            "team_id": match.a,
            "player_id": match.p,
            "outcome": "kill",
        },
    ).json()
    changed = client.put(
        f"/api/events/{event['id']}",
        json={
            "rally_id": match.rally,
            "time": 1,
            "kind": "attack",
            "team_id": match.a,
            "player_id": match.p,
            "outcome": "error",
            "revision": 1,
        },
    )
    assert changed.status_code == 200, changed.text
    setup = client.put(
        f"/api/videos/{match.vid}/setup",
        json={
            "revision": 0,
            "cards": [
                {
                    "player_id": match.p,
                    "team_id": match.a,
                    "number": "7",
                    "confirmed": True,
                    "samples": [{"time": 1, "bbox": [0.1, 0.1, 0.3, 0.9]}],
                }
            ],
        },
    )
    assert setup.status_code == 200
    run = client.post(
        f"/api/videos/{match.vid}/analysis", json={"device": "cpu", "sample_fps": 1, "segment_seconds": 2}
    )
    assert run.status_code == 201, run.text
    run = run.json()
    for _ in range(200):
        state = client.get(f"/api/analysis/{run['id']}").json()
        if state["status"] in {"completed", "failed"}:
            break
        time.sleep(0.05)
    assert state["status"] == "completed", state
    assert state["summary"]["accepted_events"] == 0
    archive = backup.backup(tmp_path / "full-real-run.zip", include_videos=True, data=DATA)
    restored = backup.restore(archive, tmp_path / "restored-real-run")
    with sqlite3.connect(restored / "data" / "volleyvision.db") as db:
        assert db.execute("SELECT outcome,revision FROM events WHERE id=?", (event["id"],)).fetchone() == ("error", 2)
        assert db.execute("SELECT count(*) FROM corrections WHERE entity=?", ("event",)).fetchone()[0] == 1
        fingerprint = db.execute("SELECT fingerprint FROM analysis_runs WHERE id=?", (run["id"],)).fetchone()[0]
        path = db.execute("SELECT path FROM videos WHERE id=?", (match.vid,)).fetchone()[0]
        assert db.execute("PRAGMA foreign_key_check").fetchall() == []
    assert (restored / "data" / path).is_file()
    assert json.loads((restored / "data" / "setup" / f"{match.vid}.json").read_text())["cards"][0]["confirmed"] is True
    segment = restored / "data" / "analysis" / fingerprint / "segment-000000.json"
    assert segment.is_file() and json.loads(segment.read_text())["fingerprint"] == fingerprint
