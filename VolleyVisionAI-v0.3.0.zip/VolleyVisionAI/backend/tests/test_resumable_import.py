"""Real file chunks, restart-like resume, hashes and allowlisted local imports."""

import concurrent.futures
import hashlib
import importlib.util
import json
import struct
from types import SimpleNamespace

import pytest
from sqlalchemy import select

from volleyvision import imports
from volleyvision.db import DATA, ROOT, Session
from volleyvision.models import Video


@pytest.fixture(autouse=True)
def isolated_upload_state(tmp_path, monkeypatch):
    monkeypatch.setattr(imports, "UPLOAD_ROOT", tmp_path / "uploads")
    monkeypatch.delenv("VOLLEYVISION_IMPORT_ROOT", raising=False)


@pytest.fixture
def mid(client):
    teams = [client.post("/api/teams", json={"name": n}).json()["id"] for n in ("Загрузка А", "Загрузка Б")]
    response = client.post("/api/matches", json={"home_id": teams[0], "away_id": teams[1], "date": "2026-11-15"})
    assert response.status_code == 201
    return response.json()["id"]


@pytest.fixture
def content(video_file):
    # A valid free atom produces multiple chunks without faking video metadata.
    size = 196608
    return video_file.read_bytes() + struct.pack(">I4s", size + 8, b"free") + bytes(size)


def new_upload(client, mid, data, **override):
    body = {
        "name": "original.mp4",
        "size": len(data),
        "sha256": hashlib.sha256(data).hexdigest(),
        "chunk_size": 65536,
        **override,
    }
    response = client.post(f"/api/matches/{mid}/uploads", json=body)
    assert response.status_code == 201, response.text
    return response.json()


def send_chunk(client, upload, data, index):
    chunk = data[index * upload["chunk_size"] : (index + 1) * upload["chunk_size"]]
    return client.put(
        f"/api/uploads/{upload['id']}/chunks/{index}",
        content=chunk,
        params={"sha256": hashlib.sha256(chunk).hexdigest()},
        headers={"Content-Type": "application/octet-stream"},
    )


def complete_parts(client, upload, data):
    for index in range(upload["total_chunks"]):
        response = send_chunk(client, upload, data, index)
        assert response.status_code == 200, response.text


def test_resume_only_missing_chunks_and_finalize_idempotently(client, mid, content):
    upload = new_upload(client, mid, content)
    response = send_chunk(client, upload, content, 1)
    assert response.status_code == 200
    assert response.json()["received"] == [1]
    assert response.json()["received_bytes"] == 65536
    # In-memory locks are not the source of truth; restart-like reconstruction uses disk.
    imports._locks.clear()
    same = new_upload(client, mid, content)
    assert same["id"] == upload["id"]
    assert same["received"] == [1]
    part = imports.UPLOAD_ROOT / upload["id"] / "1.chunk"
    old_stat = part.stat().st_mtime_ns
    assert send_chunk(client, upload, content, 1).status_code == 200
    assert part.stat().st_mtime_ns == old_stat
    for index in set(range(upload["total_chunks"])) - {1}:
        assert send_chunk(client, upload, content, index).status_code == 200
    first = client.post(f"/api/uploads/{upload['id']}/finalize")
    assert first.status_code == 200, first.text
    second = client.post(f"/api/uploads/{upload['id']}/finalize")
    assert second.status_code == 200 and first.json()["id"] == second.json()["id"]
    video = first.json()
    assert video["sha256"] == hashlib.sha256(content).hexdigest()
    assert video["size"] == len(content) and video["duration"] == 4
    assert hashlib.sha256((DATA / video["path"]).read_bytes()).hexdigest() == video["sha256"]
    assert not list((imports.UPLOAD_ROOT / upload["id"]).glob("*.chunk"))
    status = client.get(f"/api/uploads/{upload['id']}").json()
    assert status["status"] == "completed" and status["received_bytes"] == len(content)
    with Session() as db:
        assert len(list(db.scalars(select(Video).where(Video.match_id == mid)))) == 1


def test_parallel_finalize_registers_one_video(client, mid, content):
    upload = new_upload(client, mid, content)
    complete_parts(client, upload, content)
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        responses = list(pool.map(lambda _: client.post(f"/api/uploads/{upload['id']}/finalize"), range(2)))
    assert all(r.status_code == 200 for r in responses), [r.text for r in responses]
    assert responses[0].json()["id"] == responses[1].json()["id"]


def test_incomplete_upload_cannot_be_registered(client, mid, content):
    upload = new_upload(client, mid, content)
    assert send_chunk(client, upload, content, 0).status_code == 200
    response = client.post(f"/api/uploads/{upload['id']}/finalize")
    assert response.status_code == 409
    assert client.get(f"/api/matches/{mid}").json()["videos"] == []


def test_bad_chunk_hash_and_length_do_not_accept_partial_data(client, mid, content):
    upload = new_upload(client, mid, content)
    chunk = content[: upload["chunk_size"]]
    response = client.put(f"/api/uploads/{upload['id']}/chunks/0", content=chunk, params={"sha256": "0" * 64})
    assert response.status_code == 422
    response = client.put(
        f"/api/uploads/{upload['id']}/chunks/0",
        content=chunk[:-1],
        params={"sha256": hashlib.sha256(chunk[:-1]).hexdigest()},
    )
    assert response.status_code == 413
    assert client.get(f"/api/uploads/{upload['id']}").json()["received"] == []
    assert not list(imports.UPLOAD_ROOT.glob("incoming-*.part"))


def test_chunk_index_and_upload_id_are_bounded(client, mid, content):
    upload = new_upload(client, mid, content)
    assert client.get("/api/uploads/not-a-uuid").status_code == 404
    response = client.put(f"/api/uploads/{upload['id']}/chunks/-1", content=b"x", params={"sha256": "0" * 64})
    assert response.status_code == 422
    response = client.put(f"/api/uploads/{upload['id']}/chunks/99999", content=b"x", params={"sha256": "0" * 64})
    assert response.status_code == 422


def test_full_checksum_must_match_before_register(client, mid, content):
    upload = new_upload(client, mid, content, sha256="0" * 64)
    complete_parts(client, upload, content)
    response = client.post(f"/api/uploads/{upload['id']}/finalize")
    assert response.status_code == 422
    assert "SHA-256" in response.json()["detail"]
    assert client.get(f"/api/matches/{mid}").json()["videos"] == []
    manifest = imports._read(upload["id"])
    assert not (DATA / "originals" / manifest["target_name"]).exists()
    assert not (DATA / "originals" / manifest["target_name"]).with_suffix(".part").exists()


def test_detect_corrupted_staged_part_then_repair_only_that_part(client, mid, content):
    upload = new_upload(client, mid, content)
    complete_parts(client, upload, content)
    chunk_path = imports.UPLOAD_ROOT / upload["id"] / "1.chunk"
    chunk_path.write_bytes(bytes(chunk_path.stat().st_size))
    response = client.post(f"/api/uploads/{upload['id']}/finalize")
    assert response.status_code == 422 and "Часть 1" in response.json()["detail"]
    assert 1 not in client.get(f"/api/uploads/{upload['id']}").json()["received"]
    assert send_chunk(client, upload, content, 1).status_code == 200
    assert client.post(f"/api/uploads/{upload['id']}/finalize").status_code == 200


def test_truncated_part_can_be_resent(client, mid, content):
    upload = new_upload(client, mid, content)
    assert send_chunk(client, upload, content, 0).status_code == 200
    (imports.UPLOAD_ROOT / upload["id"] / "0.chunk").write_bytes(b"truncated")
    assert client.get(f"/api/uploads/{upload['id']}").json()["received"] == []
    assert send_chunk(client, upload, content, 0).status_code == 200
    assert client.get(f"/api/uploads/{upload['id']}").json()["received"] == [0]


def test_cancel_upload_preserves_registered_video(client, mid, content):
    upload = new_upload(client, mid, content)
    assert send_chunk(client, upload, content, 0).status_code == 200
    assert client.delete(f"/api/uploads/{upload['id']}").status_code == 200
    assert client.get(f"/api/uploads/{upload['id']}").status_code == 404
    fresh = new_upload(client, mid, content)
    complete_parts(client, fresh, content)
    video = client.post(f"/api/uploads/{fresh['id']}/finalize").json()
    assert client.delete(f"/api/uploads/{fresh['id']}").status_code == 409
    assert (DATA / video["path"]).is_file()


def test_low_disk_space_fails_before_accepting_new_upload(client, mid, content, monkeypatch):
    monkeypatch.setattr(imports.shutil, "disk_usage", lambda _: SimpleNamespace(free=0))
    response = client.post(
        f"/api/matches/{mid}/uploads",
        json={"name": "video.mp4", "size": len(content), "sha256": hashlib.sha256(content).hexdigest()},
    )
    assert response.status_code == 507


@pytest.mark.parametrize("name", ["../escape.mp4", "C:\\secret.mp4", "video.exe", "bad\x00.mp4"])
def test_unsafe_names_are_rejected(client, mid, content, name):
    response = client.post(
        f"/api/matches/{mid}/uploads",
        json={"name": name, "size": len(content), "sha256": hashlib.sha256(content).hexdigest()},
    )
    assert response.status_code == 422


def test_file_content_not_extension_proves_video(client, mid):
    data = b"not a real MP4 file"
    upload = new_upload(client, mid, data)
    complete_parts(client, upload, data)
    assert client.post(f"/api/uploads/{upload['id']}/finalize").status_code == 422
    assert client.get(f"/api/matches/{mid}").json()["videos"] == []


def test_local_import_disabled_until_server_allowlist_configured(client, mid):
    assert client.get("/api/local-import/files").json() == {"configured": False, "path": "", "files": []}
    assert client.post(f"/api/matches/{mid}/local-import", json={"path": "video.mp4"}).status_code == 403


def test_local_import_reads_only_allowlisted_folder_and_keeps_source(client, mid, video_file, tmp_path, monkeypatch):
    folder = tmp_path / "allowed"
    folder.mkdir()
    original = folder / "матч.mp4"
    data = video_file.read_bytes()
    original.write_bytes(data)
    monkeypatch.setenv("VOLLEYVISION_IMPORT_ROOT", str(folder))
    files = client.get("/api/local-import/files").json()
    assert files["configured"] is True
    assert files["files"][0]["path"] == "матч.mp4"
    assert str(folder) not in json.dumps(files)
    first = client.post(
        f"/api/matches/{mid}/local-import", json={"path": "матч.mp4", "sha256": hashlib.sha256(data).hexdigest()}
    )
    assert first.status_code == 201, first.text
    again = client.post(f"/api/matches/{mid}/local-import", json={"path": "матч.mp4"})
    assert again.status_code == 201 and again.json()["id"] == first.json()["id"]
    assert original.read_bytes() == data
    assert client.get(f"/api/videos/{first.json()['id']}/stream").content == data


@pytest.mark.parametrize("path", ["../outside.mp4", "/etc/passwd", "C:\\private\\video.mp4"])
def test_local_import_rejects_escape_paths(client, mid, tmp_path, monkeypatch, path):
    monkeypatch.setenv("VOLLEYVISION_IMPORT_ROOT", str(tmp_path))
    assert client.post(f"/api/matches/{mid}/local-import", json={"path": path}).status_code == 422


def test_symlink_escape_is_not_listed_or_imported(client, mid, video_file, tmp_path, monkeypatch):
    folder = tmp_path / "allowed"
    folder.mkdir()
    (folder / "escape.mp4").symlink_to(video_file)
    monkeypatch.setenv("VOLLEYVISION_IMPORT_ROOT", str(folder))
    assert client.get("/api/local-import/files").json()["files"] == []
    assert client.post(f"/api/matches/{mid}/local-import", json={"path": "escape.mp4"}).status_code == 403


def test_local_expected_checksum_mismatch_keeps_source_and_removes_new_copy(client, mid, video_file, monkeypatch):
    monkeypatch.setenv("VOLLEYVISION_IMPORT_ROOT", str(video_file.parent))
    before = set((DATA / "originals").iterdir())
    response = client.post(f"/api/matches/{mid}/local-import", json={"path": video_file.name, "sha256": "0" * 64})
    assert response.status_code == 422 and video_file.exists()
    assert set((DATA / "originals").iterdir()) == before


fragment_spec = importlib.util.spec_from_file_location(
    "prepare_fragment_script", ROOT / "scripts" / "prepare_fragment.py"
)
fragment = importlib.util.module_from_spec(fragment_spec)
fragment_spec.loader.exec_module(fragment)


@pytest.mark.parametrize("mode", ["copy", "compress"])
def test_prepare_fragment_preserves_source_and_labels_quality(video_file, tmp_path, mode):
    source_digest = hashlib.sha256(video_file.read_bytes()).hexdigest()
    output = tmp_path / f"excerpt-{mode}.mp4"
    report = fragment.prepare(video_file, output, start=1, duration=2, mode=mode)
    assert output.is_file() and output.with_suffix(".mp4.json").is_file()
    assert hashlib.sha256(video_file.read_bytes()).hexdigest() == source_digest
    assert report["compressed"] is (mode == "compress")
    assert report["under_32_mib"] is True
    assert report["output"]["width"] == 320 and report["output"]["codec_name"] == "h264"
    assert report["sha256"] == hashlib.sha256(output.read_bytes()).hexdigest()


def test_fragment_never_overwrites_source_or_existing_output(video_file):
    with pytest.raises(ValueError, match="не заменяются"):
        fragment.prepare(video_file, video_file)


def test_resume_recovers_assembly_completed_before_database_registration(client, mid, content):
    upload = new_upload(client, mid, content)
    complete_parts(client, upload, content)
    manifest = imports._read(upload["id"])
    target = DATA / "originals" / manifest["target_name"]
    target.write_bytes(content)  # Power failure after atomic rename, before DB commit.
    old_mtime = target.stat().st_mtime_ns
    imports._locks.clear()
    response = client.post(f"/api/uploads/{upload['id']}/finalize")
    assert response.status_code == 200, response.text
    assert response.json()["path"] == str(target.relative_to(DATA))
    assert target.stat().st_mtime_ns == old_mtime  # No second assembly/copy.


def test_resume_recovers_database_commit_before_completion_marker(client, mid, content):
    upload = new_upload(client, mid, content)
    complete_parts(client, upload, content)
    first = client.post(f"/api/uploads/{upload['id']}/finalize").json()
    manifest = imports._read(upload["id"])
    manifest["status"] = "uploading"
    manifest.pop("video_id")
    imports._save(manifest)
    imports._locks.clear()
    retry = client.post(f"/api/uploads/{upload['id']}/finalize")
    assert retry.status_code == 200 and retry.json()["id"] == first["id"]
    assert len(client.get(f"/api/matches/{mid}").json()["videos"]) == 1


def test_existing_video_does_not_require_resending_any_chunks(client, mid, video_file):
    data = video_file.read_bytes()
    first = client.post(f"/api/matches/{mid}/videos", files={"file": (video_file.name, data, "video/mp4")})
    assert first.status_code == 201
    upload = new_upload(client, mid, data)
    assert upload["status"] == "completed"
    assert upload["received_bytes"] == len(data)
    assert upload["video"]["id"] == first.json()["id"]


def test_corrupted_manifest_cannot_choose_arbitrary_output_path(client, mid, content):
    upload = new_upload(client, mid, content)
    manifest = imports._read(upload["id"])
    manifest["target_name"] = "../../outside.mp4"
    (imports.UPLOAD_ROOT / upload["id"] / "manifest.json").write_text(json.dumps(manifest))
    assert client.get(f"/api/uploads/{upload['id']}").status_code == 409
    assert client.post(f"/api/uploads/{upload['id']}/finalize").status_code == 409


def test_local_source_swap_during_open_rejected(client, mid, video_file, tmp_path, monkeypatch):
    from pathlib import Path

    folder = tmp_path / "allowed"
    folder.mkdir()
    source = folder / "allowed.mp4"
    source.write_bytes(video_file.read_bytes())
    outside = tmp_path / "private.mp4"
    outside.write_bytes(video_file.read_bytes())
    original_open = Path.open

    def swapped_open(path, mode="r", *args, **kwargs):
        if path == source and mode == "rb":
            return original_open(outside, mode, *args, **kwargs)
        return original_open(path, mode, *args, **kwargs)

    monkeypatch.setenv("VOLLEYVISION_IMPORT_ROOT", str(folder))
    monkeypatch.setattr(Path, "open", swapped_open)
    response = client.post(f"/api/matches/{mid}/local-import", json={"path": "allowed.mp4"})
    assert response.status_code == 409
    assert client.get(f"/api/matches/{mid}").json()["videos"] == []
