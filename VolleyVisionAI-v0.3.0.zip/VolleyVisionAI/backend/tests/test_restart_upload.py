"""Real localhost disconnect+server restart; not a claim about iPhone/mobile networks."""

import hashlib
import os
import socket
import signal
import struct
import subprocess
import sys
import time

import httpx

from volleyvision.db import ROOT


def test_upload_survives_broken_socket_and_process_restart(tmp_path, video_file):
    data = tmp_path / "persistent-data"
    env = {**os.environ, "VOLLEYVISION_DATA": str(data), "VOLLEYVISION_PROFILE": "local"}
    subprocess.run(
        [sys.executable, "-m", "alembic", "upgrade", "head"], cwd=ROOT, env=env, check=True, capture_output=True
    )
    with socket.socket() as pick:
        pick.bind(("127.0.0.1", 0))
        port = pick.getsockname()[1]
    base = f"http://127.0.0.1:{port}"
    logfile = (tmp_path / "server.log").open("w")

    def start():
        process = subprocess.Popen(
            [
                sys.executable,
                "-m",
                "uvicorn",
                "volleyvision.main:app",
                "--app-dir",
                "backend",
                "--host",
                "127.0.0.1",
                "--port",
                str(port),
                "--log-level",
                "error",
            ],
            cwd=ROOT,
            env=env,
            stdout=logfile,
            stderr=logfile,
        )
        for _ in range(100):
            if process.poll() is not None:
                raise AssertionError((tmp_path / "server.log").read_text())
            try:
                if httpx.get(base + "/api/health", timeout=0.5).status_code == 200:
                    return process
            except httpx.HTTPError:
                pass
            time.sleep(0.05)
        process.terminate()
        process.wait(timeout=10)
        raise AssertionError("Server failed readiness")

    process = start()
    try:
        with httpx.Client(base_url=base, timeout=15) as client:
            teams = [
                client.post("/api/teams", json={"name": name}).json()["id"]
                for name in ("SYNTHETIC restartA", "SYNTHETIC restartB")
            ]
            mid = client.post(
                "/api/matches", json={"home_id": teams[0], "away_id": teams[1], "date": "2026-11-15"}
            ).json()["id"]
            payload = video_file.read_bytes() + struct.pack(">I4s", 196616, b"free") + bytes(196608)
            body = {
                "name": "SYNTHETIC-restart.mp4",
                "size": len(payload),
                "sha256": hashlib.sha256(payload).hexdigest(),
                "chunk_size": 65536,
            }
            upload = client.post(f"/api/matches/{mid}/uploads", json=body).json()
            ident = upload["id"]
            first = payload[:65536]
            assert (
                client.put(
                    f"/api/uploads/{ident}/chunks/0",
                    params={"sha256": hashlib.sha256(first).hexdigest()},
                    content=first,
                ).status_code
                == 200
            )
            accepted = data / "uploads" / ident / "0.chunk"
            original_mtime = accepted.stat().st_mtime_ns
            second = payload[65536:131072]
            # A real socket disconnect before declared body length, not a fake HTTP response.
            with socket.create_connection(("127.0.0.1", port), timeout=3) as connection:
                path = f"/api/uploads/{ident}/chunks/1?sha256={hashlib.sha256(second).hexdigest()}"
                headers = f"PUT {path} HTTP/1.1\r\nHost: 127.0.0.1:{port}\r\nContent-Type: application/octet-stream\r\nContent-Length: 65536\r\nConnection: close\r\n\r\n"
                connection.sendall(headers.encode() + second[:100])
            time.sleep(0.1)
            assert client.get(f"/api/uploads/{ident}").json()["received"] == [0]
        process.terminate()
        assert process.wait(timeout=10) in (0, -signal.SIGTERM)
        logfile.flush()
        assert "Exception in ASGI application" not in (tmp_path / "server.log").read_text()
        process = start()
        with httpx.Client(base_url=base, timeout=15) as client:
            resumed = client.post(f"/api/matches/{mid}/uploads", json=body).json()
            assert resumed["id"] == ident and resumed["received"] == [0]
            assert accepted.stat().st_mtime_ns == original_mtime
            sent = []
            for index in set(range(resumed["total_chunks"])) - set(resumed["received"]):
                piece = payload[index * 65536 : (index + 1) * 65536]
                response = client.put(
                    f"/api/uploads/{ident}/chunks/{index}",
                    params={"sha256": hashlib.sha256(piece).hexdigest()},
                    content=piece,
                )
                assert response.status_code == 200, response.text
                sent.append(index)
            assert 0 not in sent
            response = client.post(f"/api/uploads/{ident}/finalize")
            assert response.status_code == 200, response.text
            assert response.json()["sha256"] == body["sha256"]
            assert client.post(f"/api/uploads/{ident}/finalize").json()["id"] == response.json()["id"]
            assert len(client.get(f"/api/matches/{mid}").json()["videos"]) == 1
    finally:
        if process.poll() is None:
            process.terminate()
            process.wait(timeout=10)
        logfile.close()
