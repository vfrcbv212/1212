"""Analysis infrastructure tests use explicitly controlled detector observations.

These tests validate queue/cache/report integrity, never real model accuracy.
"""

import json
import threading
from types import SimpleNamespace

import pytest
from sqlalchemy import select

from volleyvision import analysis, jobs
from volleyvision.analysis_models import AnalysisRun
from volleyvision.db import Session
from volleyvision.models import Event, Job


@pytest.fixture
def detector(monkeypatch, client, request):
    # The app worker is deliberately stopped so checkpoint interruptions can be
    # controlled exactly; model quality is tested separately by vision tests.
    jobs.stop()
    import hashlib

    # Each controlled detector is a distinct test model, so persisted segments
    # from another fixture cannot masquerade as this test's scan output.
    state = {
        "calls": [],
        "installed": True,
        "sha": hashlib.sha256(request.node.nodeid.encode()).hexdigest(),
        "interrupt_after": None,
    }

    def manifest(model_id="yolox-tiny"):
        return {
            "model_id": model_id,
            "version": "test-fixture-v1",
            "sha256": state["sha"],
            "installed": state["installed"],
            "verified": state["installed"],
            "input_size": [416, 416],
        }

    def scan(path, start, end, **kwargs):
        state["calls"].append((start, end))
        if state["interrupt_after"] == len(state["calls"]):
            raise InterruptedError("intentional checkpoint fixture interruption")
        return {
            "frames": [
                {"time": start, "detections": [{"class_name": "person", "confidence": 0.9, "bbox": [10, 10, 30, 40]}]},
                {
                    "time": end,
                    "detections": [{"class_name": "sports ball", "confidence": 0.6, "bbox": [30, 30, 34, 34]}],
                },
            ],
            "runtime": {
                "provider": "CPUExecutionProvider",
                "elapsed_seconds": 0.1,
                "inference_seconds": 0.04,
                "decode_seconds": 0.02,
            },
        }

    fake = SimpleNamespace(
        get_model_manifest=manifest,
        get_runtime_info=lambda *args: {"active_device": "cpu"},
        YoloXDetector=lambda **kw: object(),
        scan_segment=scan,
    )
    monkeypatch.setattr(analysis, "_vision", lambda: fake)
    return state


def enqueue(client, match, **params):
    response = client.post(f"/api/videos/{match.vid}/analysis", json={"segment_seconds": 2, **params})
    assert response.status_code == 201, response.text
    return response.json()


def test_analysis_requests_are_idempotent_and_parameter_sensitive(client, match, detector):
    first = enqueue(client, match)
    duplicate = enqueue(client, match)
    changed = enqueue(client, match, sample_fps=4)
    assert first["id"] == duplicate["id"] and first["job_id"] == duplicate["job_id"]
    assert first["id"] != changed["id"]
    assert client.get(f"/api/videos/{match.vid}/analysis/latest").json()["id"] == changed["id"]
    with Session() as db:
        assert len(list(db.scalars(select(AnalysisRun)))) == 2
        assert len(list(db.scalars(select(Job)))) == 2


def test_missing_model_does_not_create_pretend_analysis(client, match, detector):
    detector["installed"] = False
    response = client.post(f"/api/videos/{match.vid}/analysis", json={})
    assert response.status_code == 503
    with Session() as db:
        assert not list(db.scalars(select(AnalysisRun)))
        assert not list(db.scalars(select(Job)))


def test_segments_resume_without_reanalysis_and_keep_manual_events(client, match, detector):
    with Session() as db:
        db.add(
            Event(
                match_id=match.mid,
                rally_id=match.rally,
                video_id=match.vid,
                time=1,
                kind="attack",
                team_id=match.a,
                player_id=match.p,
                outcome="kill",
            )
        )
        db.commit()
    run = enqueue(client, match)
    detector["interrupt_after"] = 2
    with pytest.raises(InterruptedError):
        analysis.process_analysis(run["job_id"], threading.Event())
    with Session() as db:
        job = db.get(Job, run["job_id"])
        assert job.checkpoint["segments_done"] == [0]
    detector["interrupt_after"] = None
    result = analysis.process_analysis(run["job_id"], threading.Event())
    assert detector["calls"] == [(0, 2), (2, 4), (2, 4)]
    assert result["reused_segments"] == [0]
    assert result["recomputed_segments"] == [1]
    assert result["sampled_frames"] == 2  # Exact boundary frame is not counted twice.
    assert result["person_observations"] == 2
    assert result["ball_observations"] == 0
    assert result["accepted_events"] == 0
    with Session() as db:
        events = list(db.scalars(select(Event)))
        assert len(events) == 1 and events[0].outcome == "kill" and events[0].status == "manual"
    report = client.get(f"/api/matches/{match.mid}/report?run_id={run['id']}").json()
    assert report["statistics"]["trusted_events"] == 1
    assert report["coverage"]["sampled_frames"] == 2
    assert len(report["timeline"]) == 2
    assert report["maps"]["coordinate_system"] == "normalized_image"
    assert report["coverage"]["accepted_events"] == 0


def test_corrupt_segment_is_recomputed_and_model_change_does_not_mix_cache(client, match, detector):
    run = enqueue(client, match)
    analysis.process_analysis(run["job_id"], threading.Event())
    with Session() as db:
        stored = db.get(AnalysisRun, run["id"])
        file = analysis._folder(stored) / "segment-000000.json"
    envelope = json.loads(file.read_text())
    envelope["payload"]["frames"][0]["time"] = 999
    file.write_text(json.dumps(envelope))
    detector["calls"].clear()
    analysis.process_analysis(run["job_id"], threading.Event())
    assert detector["calls"] == [(0, 2)]
    detector["sha"] = "f" * 64
    with pytest.raises(ValueError, match="изменился"):
        analysis.process_analysis(run["job_id"], threading.Event())


def test_queue_dispatch_completes_analysis_without_proxy_path_mutation(client, match, detector):
    from volleyvision.models import Video

    run = enqueue(client, match)
    jobs.stop_event.clear()
    jobs.process_next()
    status = client.get(f"/api/analysis/{run['id']}").json()
    assert status["status"] == "completed"
    assert status["progress"] == 1
    assert status["summary"]["scope"] == "object_observations_only"
    with Session() as db:
        assert db.get(Video, match.vid).proxy_path is None


def test_report_html_escapes_source_and_discloses_detection_limits(client, match, detector):
    from volleyvision.models import Video

    with Session() as db:
        db.get(Video, match.vid).name = "<script>alert(1)</script>.mp4"
        db.commit()
    run = enqueue(client, match)
    analysis.process_analysis(run["job_id"], threading.Event())
    html = client.get(f"/api/matches/{match.mid}/report.html?run_id={run['id']}")
    assert html.status_code == 200
    assert "<script>alert(1)</script>" not in html.text
    assert "&lt;script&gt;" in html.text
    assert "Автоматически принятых волейбольных действий: 0" in html.text
    assert "не полное распознавание матча" in html.text
    assert "Карта наблюдений в изображении" in html.text


def test_no_analysis_report_still_returns_existing_statistics(client, match, detector):
    response = client.get(f"/api/matches/{match.mid}/report")
    assert response.status_code == 200
    assert response.json()["run"] is None
    assert response.json()["coverage"]["accepted_events"] == 0
    assert client.get(f"/api/matches/{match.mid}/report.html").status_code == 200


def test_wrong_match_run_is_not_exposed(client, match, detector):
    from volleyvision.models import Match

    run = enqueue(client, match)
    with Session() as db:
        other = Match(home_id=match.a, away_id=match.b, date="2026-11-15", title="Other")
        db.add(other)
        db.commit()
        other_id = other.id
    response = client.get(f"/api/matches/{other_id}/report?run_id={run['id']}")
    assert response.status_code == 404


def test_invalid_analysis_window_is_rejected(client, match, detector):
    assert client.post(f"/api/videos/{match.vid}/analysis", json={"start": 3, "end": 2}).status_code == 422
    assert client.post(f"/api/videos/{match.vid}/analysis", json={"end": 100}).status_code == 422
    assert client.post(f"/api/videos/{match.vid}/analysis", json={"sample_fps": "Infinity"}).status_code == 422


def test_real_weights_video_to_observation_report(client, match, tmp_path, monkeypatch):
    """Real inference smoke on a static clip of a public-domain NASA photo.

    It validates installed weights and plumbing, not sports/event accuracy.
    """
    import subprocess
    from volleyvision import vision
    from volleyvision.db import ROOT

    jobs.stop()
    monkeypatch.setattr(vision, "DATA", ROOT / "data")  # Explicit installed-weight location, not source data.
    manifest = vision.get_model_manifest("yolox-tiny")
    if not manifest["verified"] or not vision.get_runtime_info()["dependencies_installed"]:
        pytest.skip("Optional AI dependencies/verified weights not installed; install per MODEL_REGISTRY.md")
    photo = ROOT / "backend" / "tests" / "fixtures" / "astronaut.png"
    assert photo.is_file()
    clip = tmp_path / "synthetic-static-nasa-photo.mp4"
    subprocess.run(
        [
            "ffmpeg",
            "-nostdin",
            "-v",
            "error",
            "-loop",
            "1",
            "-i",
            str(photo),
            "-t",
            "2",
            "-r",
            "10",
            "-c:v",
            "libx264",
            "-pix_fmt",
            "yuv420p",
            "-threads",
            "2",
            str(clip),
        ],
        check=True,
    )
    with clip.open("rb") as stream:
        response = client.post(f"/api/matches/{match.mid}/videos", files={"file": (clip.name, stream, "video/mp4")})
    assert response.status_code == 201, response.text
    vid = response.json()["id"]
    requested = client.post(
        f"/api/videos/{vid}/analysis", json={"sample_fps": 2, "segment_seconds": 2, "device": "cpu"}
    )
    assert requested.status_code == 201, requested.text
    jobs.stop_event.clear()
    jobs.process_next()
    status = client.get(f"/api/analysis/{requested.json()['id']}").json()
    assert status["status"] == "completed", status
    assert status["summary"]["person_observations"] >= 1
    assert status["summary"]["sampled_frames"] == 4
    assert status["summary"]["accepted_events"] == 0
    assert status["summary"]["active_providers"] == ["CPUExecutionProvider"]
    report = client.get(f"/api/matches/{match.mid}/report?run_id={status['id']}").json()
    assert report["coverage"]["person_observations"] >= 1
    assert report["statistics"]["trusted_events"] == 0
    assert len(report["maps"]["person_footpoints"]) >= 1


def _stored_source(match):
    from volleyvision.db import DATA
    from volleyvision.models import Video

    with Session() as db:
        return DATA / db.get(Video, match.vid).path


def test_same_size_source_tamper_is_rejected_before_cache_reuse(client, match, detector):
    run = enqueue(client, match)
    first = analysis.process_analysis(run["job_id"], threading.Event())
    assert first["source_verification"]["method"] == "streamed_sha256_before_cache_reuse"
    source = _stored_source(match)
    original = source.read_bytes()
    altered = bytearray(original)
    altered[len(altered) // 2] ^= 1
    source.write_bytes(altered)
    detector["calls"].clear()
    with pytest.raises(ValueError, match="SHA256"):
        analysis.process_analysis(run["job_id"], threading.Event())
    assert detector["calls"] == []
    # Restoring the exact original permits safe cache reuse, without inference.
    source.write_bytes(original)
    resumed = analysis.process_analysis(run["job_id"], threading.Event())
    assert resumed["reused_segments"] == [0, 1]
    assert resumed["inference_seconds_this_attempt"] == 0
    assert resumed["decode_seconds_this_attempt"] == 0
    assert resumed["inference_seconds"] == pytest.approx(0.08)
    assert resumed["decode_seconds"] == pytest.approx(0.04)
    assert resumed["metrics_scope"] == "original_segment_measurements_including_reused"
    assert detector["calls"] == []


def test_changed_size_is_rejected_before_model_or_cache_processing(client, match, detector):
    run = enqueue(client, match)
    with _stored_source(match).open("ab") as f:
        f.write(b"changed")
    with pytest.raises(ValueError, match="Размер"):
        analysis.process_analysis(run["job_id"], threading.Event())
    assert detector["calls"] == []
    with Session() as db:
        assert db.get(AnalysisRun, run["id"]).summary == {}


def test_source_change_during_inference_is_not_committed(client, match, detector, monkeypatch):
    run = enqueue(client, match)
    real_scan = analysis._vision().scan_segment

    def changing_scan(*args, **kwargs):
        result = real_scan(*args, **kwargs)
        with _stored_source(match).open("ab") as source:
            source.write(b"mid-segment change")
        return result

    monkeypatch.setattr(analysis._vision(), "scan_segment", changing_scan)
    with pytest.raises(ValueError, match="изменилось"):
        analysis.process_analysis(run["job_id"], threading.Event())
    with Session() as db:
        stored = db.get(AnalysisRun, run["id"])
        assert stored.summary == {}
        assert not (analysis._folder(stored) / "segment-000000.json").exists()
        assert not list(db.scalars(select(Event)))


def test_streamed_source_verification_can_be_cancelled_without_buffering(tmp_path):
    import hashlib

    path = tmp_path / "verification-input.bin"
    block = b"x" * (1024 * 1024)
    with path.open("wb") as stream:
        for _ in range(3):
            stream.write(block)

    class CancelAfterOneChunk:
        calls = 0

        def is_set(self):
            self.calls += 1
            return self.calls >= 3

    cancel = CancelAfterOneChunk()
    expected = hashlib.sha256(block * 3).hexdigest()
    with pytest.raises(InterruptedError, match="Проверка"):
        analysis._verify_source(path, expected, 3 * len(block), cancel)
    assert cancel.calls == 3
    assert path.stat().st_size == 3 * len(block)


def test_cancelled_cached_analysis_does_not_publish_a_new_summary(client, match, detector):
    run = enqueue(client, match)
    cancel = threading.Event()
    cancel.set()
    with pytest.raises(InterruptedError):
        analysis.process_analysis(run["job_id"], cancel)
    assert detector["calls"] == []
    with Session() as db:
        assert db.get(AnalysisRun, run["id"]).summary == {}


def test_track_ids_are_scoped_to_segment_and_balls_use_decoded_dimensions(client, match, detector, monkeypatch):
    original_scan = analysis._vision().scan_segment

    def tracked_scan(*args, **kwargs):
        result = original_scan(*args, **kwargs)
        first = result["frames"][0]
        first.update(width=100, height=200)
        first["detections"] = [
            {"class_name": "sports ball", "track_id": 1, "bbox": [40, 90, 60, 110], "confidence": 0.7}
        ]
        return result

    monkeypatch.setattr(analysis._vision(), "scan_segment", tracked_scan)
    run = enqueue(client, match)
    analysis.process_analysis(run["job_id"], threading.Event())
    with Session() as db:
        stored = db.get(AnalysisRun, run["id"])
        folder = analysis._folder(stored)
    first = json.loads((folder / "segment-000000.json").read_text())["payload"]["frames"][0]
    second = json.loads((folder / "segment-000001.json").read_text())["payload"]["frames"][0]
    assert first["segment_index"] == 0 and second["segment_index"] == 1
    assert first["detections"][0]["track_id"] == second["detections"][0]["track_id"] == 1
    assert first["detections"][0]["track_uid"] != second["detections"][0]["track_uid"]
    report = client.get(f"/api/matches/{match.mid}/report?run_id={run['id']}").json()
    assert report["maps"]["ball_centers"] == [[0.5, 0.5], [0.5, 0.5]]
    assert [frame["segment_index"] for frame in report["timeline"]] == [0, 1]
    page = client.get(f"/api/analysis/{run['id']}/observations?offset=0&limit=1").json()
    assert page["actions_inferred"] is False
    assert page["total_frames"] == 2
    assert page["next_offset"] == 1
    assert page["frames"][0]["detections"][0]["track_id"] == 1
    assert page["frames"][0]["video_id"] == match.vid
    assert page["frames"][0]["segment_index"] == 0
    assert page["source_sha256"]
    next_page = client.get(f"/api/analysis/{run['id']}/observations?offset=1&limit=1").json()
    assert next_page["next_offset"] is None
    assert next_page["frames"][0]["segment_index"] == 1
    assert client.get(f"/api/analysis/{run['id']}/observations?limit=1001").status_code == 422


def test_runtime_or_processor_version_change_refuses_stale_execution(client, match, detector, monkeypatch):
    run = enqueue(client, match)
    fake = analysis._vision()
    monkeypatch.setattr(
        fake, "get_runtime_info", lambda *args: {"active_device": "cpu", "versions": {"onnxruntime": "changed"}}
    )
    with pytest.raises(ValueError, match="библиотек"):
        analysis.process_analysis(run["job_id"], threading.Event())
    monkeypatch.setattr(fake, "get_runtime_info", lambda *args: {"active_device": "cpu"})
    with Session() as db:
        stored = db.get(AnalysisRun, run["id"])
        stored.config = {**stored.config, "processor_version": "previous-worker"}
        db.commit()
    with pytest.raises(ValueError, match="конвейера"):
        analysis.process_analysis(run["job_id"], threading.Event())
    assert detector["calls"] == []


def test_reused_and_new_segments_must_have_same_actual_provider(client, match, detector, monkeypatch):
    run = enqueue(client, match)
    detector["interrupt_after"] = 2
    with pytest.raises(InterruptedError):
        analysis.process_analysis(run["job_id"], threading.Event())
    detector["interrupt_after"] = None
    old_scan = analysis._vision().scan_segment

    def gpu_scan(*args, **kwargs):
        result = old_scan(*args, **kwargs)
        result["runtime"]["provider"] = "CUDAExecutionProvider"
        return result

    monkeypatch.setattr(analysis._vision(), "scan_segment", gpu_scan)
    with pytest.raises(ValueError, match="CPU/GPU"):
        analysis.process_analysis(run["job_id"], threading.Event())
    with Session() as db:
        assert db.get(AnalysisRun, run["id"]).summary == {}


@pytest.mark.parametrize("fmt", ["json", "csv", "xlsx"])
def test_report_exports_pin_exact_manual_data_version(client, match, detector, fmt):
    import io
    from openpyxl import load_workbook

    created = client.post(
        f"/api/matches/{match.mid}/events",
        json={
            "rally_id": match.rally,
            "time": 1,
            "kind": "attack",
            "team_id": match.a,
            "player_id": match.p,
            "outcome": "kill",
        },
    )
    assert created.status_code == 201, created.text
    run = enqueue(client, match)
    analysis.process_analysis(run["job_id"], threading.Event())
    report = client.get(f"/api/matches/{match.mid}/report?run_id={run['id']}").json()
    path = f"/api/matches/{match.mid}/report/export/{fmt}?run_id={run['id']}&data_version={report['data_version']}"
    exported = client.get(path)
    assert exported.status_code == 200, exported.text[:200]
    assert exported.headers["etag"] == '"' + report["data_version"] + '"'
    if fmt == "json":
        assert exported.json()["data_version"] == report["data_version"]
        assert exported.json()["statistics"] == report["statistics"]
    elif fmt == "csv":
        assert report["data_version"] in exported.text
        assert "kill" in exported.text
    else:
        wb = load_workbook(io.BytesIO(exported.content))
        assert wb["Версия и ограничения"]["B1"].value == report["data_version"]
        rows = list(wb["Статистика"].values)
        attack = next(row for row in rows if row[:3] == (str(match.a), "team", "attack"))
        assert attack[3] == 1 and attack[5] == 100 and attack[6] == 100
    e = created.json()
    changed = client.put(
        f"/api/events/{e['id']}",
        json={
            "rally_id": match.rally,
            "time": 1,
            "kind": "attack",
            "team_id": match.a,
            "player_id": match.p,
            "outcome": "error",
            "revision": e["revision"],
        },
    )
    assert changed.status_code == 200
    stale = client.get(path)
    assert stale.status_code == 409
    assert "изменились" in stale.json()["detail"]
    refreshed = client.get(f"/api/matches/{match.mid}/report?run_id={run['id']}").json()
    assert refreshed["data_version"] != report["data_version"]
    assert refreshed["statistics"]["teams"][str(match.a)]["attack"]["efficiency"] == -100


def test_report_html_downloads_include_current_version_and_corrupt_observations_are_not_exported(
    client, match, detector
):
    run = enqueue(client, match)
    analysis.process_analysis(run["job_id"], threading.Event())
    report = client.get(f"/api/matches/{match.mid}/report?run_id={run['id']}").json()
    rendered = client.get(f"/api/matches/{match.mid}/report.html?run_id={run['id']}").text
    assert "/report/export/xlsx?data_version=" + report["data_version"] in rendered
    assert "&amp;run_id=" + str(run["id"]) in rendered
    assert '/export/xlsx">' not in rendered
    with Session() as db:
        stored = db.get(AnalysisRun, run["id"])
        path = analysis._folder(stored) / "segment-000000.json"
    envelope = json.loads(path.read_text())
    envelope["payload"]["frames"][0]["detections"][0]["bbox"] = [0, 0, 999, 999]
    path.write_text(json.dumps(envelope))
    response = client.get(f"/api/analysis/{run['id']}/observations?limit=2").json()
    assert response["total_frames"] == 1
    assert response["missing_or_invalid_segments"] == [0]
    assert len(response["frames"]) == 1
    assert response["frames"][0]["segment_index"] == 1


def test_floor_map_uses_calibration_only_for_unclipped_observed_person_feet(client, match, detector, monkeypatch):
    calibration = {
        "mode": "court",
        "homography": [[18, 0, 0], [0, 9, 0], [0, 0, 1]],
        "visibility_polygon": [[0.1, 0.1], [0.9, 0.1], [0.9, 0.9], [0.1, 0.9]],
        "lens_status": "uncorrected",
    }
    monkeypatch.setattr(
        analysis,
        "_setup",
        lambda vid: {
            "video_id": vid,
            "revision": 1,
            "calibration": calibration,
            "cards": [],
            "config_sha256": "a" * 64,
        },
    )
    old_scan = analysis._vision().scan_segment

    def floor_scan(*args, **kwargs):
        result = old_scan(*args, **kwargs)
        first = result["frames"][0]
        first.update(width=100, height=200)
        first["detections"] = [
            {"class_name": "person", "bbox": [40, 40, 60, 100]},
            {"class_name": "person", "bbox": [40, 40, 60, 200]},  # Feet cropped by frame.
            {"class_name": "person", "bbox": [90, 40, 100, 100]},  # Outside observed mask.
            {"class_name": "sports ball", "bbox": [40, 90, 60, 110]},
        ]
        return result

    monkeypatch.setattr(analysis._vision(), "scan_segment", floor_scan)
    run = enqueue(client, match)
    analysis.process_analysis(run["job_id"], threading.Event())
    report = client.get(f"/api/matches/{match.mid}/report?run_id={run['id']}").json()
    floor = report["maps"]["floor_person_feet"]
    assert len(floor) == 2
    assert all(point["court"] == [9, 4.5] and point["approximate"] is True for point in floor)
    assert all(point["source"] == "person_bbox_bottom" for point in floor)
    assert report["maps"]["ball_centers"] == [[0.5, 0.5], [0.5, 0.5]]
    assert report["maps"]["floor_projection"]["lens_status"] == "uncorrected"
    rendered = client.get(f"/api/matches/{match.mid}/report.html?run_id={run['id']}").text
    assert "Приблизительные точки ног на полу" in rendered
    assert "не физическое измерение" in rendered
    assert "OCR" in rendered


def test_downloaded_html_has_original_application_base_for_episode_links(client, match):
    response = client.get(f"/api/matches/{match.mid}/report.html")
    assert response.status_code == 200
    assert '<base href="http://127.0.0.1:8765/">' in response.text


def test_html_names_are_escaped_and_renaming_changes_report_version(client, match):
    from volleyvision.models import Team

    first = client.get(f"/api/matches/{match.mid}/report").json()
    with Session() as db:
        db.get(Team, match.a).name = "<script>alert(1)</script>"
        db.commit()
    changed = client.get(f"/api/matches/{match.mid}/report").json()
    assert first["data_version"] != changed["data_version"]
    html = client.get(f"/api/matches/{match.mid}/report.html").text
    assert "<script>alert(1)</script>" not in html
    assert "&lt;script&gt;alert(1)&lt;/script&gt;" in html
    assert "Игроки — доверенная ручная разметка" in html
