import importlib.util
import sqlite3

from volleyvision.db import DATA, ROOT

spec = importlib.util.spec_from_file_location("doctor_script", ROOT / "scripts" / "doctor.py")
doctor = importlib.util.module_from_spec(spec)
spec.loader.exec_module(doctor)


def test_diagnostics_never_creates_a_missing_database(tmp_path):
    data = tmp_path / "not-yet-created"
    checks = doctor.inspect(data)
    assert not data.exists()
    assert any(c["name"] == "База данных" and not c["ok"] for c in checks)
    assert any(c["name"] == "AI / CUDA" and not c["required"] for c in checks)


def test_diagnostics_checks_integrity_without_changing_events(client):
    with sqlite3.connect(DATA / "volleyvision.db") as db:
        before = db.execute("SELECT count(*) FROM events").fetchone()[0]
    checks = doctor.inspect(DATA)
    assert next(c for c in checks if c["name"] == "Целостность SQLite")["ok"]
    assert next(c for c in checks if c["name"] == "Миграции")["ok"]
    with sqlite3.connect(DATA / "volleyvision.db") as db:
        assert db.execute("SELECT count(*) FROM events").fetchone()[0] == before
