# Public-domain real-person inference fixture
`astronaut.png` is NASA photograph of astronaut Eileen Collins, distributed by scikit-image as public-domain data.
Source: https://raw.githubusercontent.com/scikit-image/scikit-image/v0.19.3/skimage/data/astronaut.png
Rights evidence: https://github.com/scikit-image/scikit-image/blob/v0.19.3/skimage/data/_fetchers.py (`astronaut` documents NASA/public-domain origin).
No faces are recognized or identified: the fixture tests the generic COCO `person` class only. One person, no sports ball. It is not volleyball footage and cannot validate ball/event/player-identity accuracy. A video built from this photo is explicitly a constructed transport/inference smoke test.
