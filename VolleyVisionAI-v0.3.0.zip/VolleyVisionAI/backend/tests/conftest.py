import os
import tempfile
import shutil
from pathlib import Path

os.environ["VOLLEYVISION_DATA"] = tempfile.mkdtemp(prefix="volleyvision-tests-")

import pytest  # noqa: E402
from alembic import command  # noqa: E402
from alembic.config import Config  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402

from volleyvision.db import Base, ROOT, DATA, engine  # noqa: E402
from volleyvision.main import app  # noqa: E402


@pytest.fixture(autouse=True)
def clean_db():
    # These are ephemeral fixture directories, never the user's project data.
    assert DATA.parent == Path(tempfile.gettempdir()) and DATA.name.startswith("volleyvision-tests-")
    for folder in ("setup", "analysis", "uploads", "originals", "derived", "exports"):
        path = DATA / folder
        if path.exists():
            shutil.rmtree(path)
        path.mkdir()
    command.upgrade(Config(str(ROOT / "alembic.ini")), "head")
    with engine.begin() as conn:
        for table in reversed(Base.metadata.sorted_tables):
            conn.execute(table.delete())


@pytest.fixture
def client():
    # Do not start worker except in queue-specific tests.
    with TestClient(app, base_url="http://127.0.0.1:8765", follow_redirects=False) as c:
        yield c


from test_workflow import match, video_file  # noqa: E402,F401
