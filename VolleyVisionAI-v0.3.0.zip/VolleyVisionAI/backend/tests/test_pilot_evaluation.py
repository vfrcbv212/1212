"""Known-answer evaluator fixtures. Synthetic labels are not real model validation."""

import importlib.util
import json
import math
import subprocess
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[2]
spec = importlib.util.spec_from_file_location("pilot_evaluator", ROOT / "scripts" / "evaluate_pilot.py")
pilot = importlib.util.module_from_spec(spec)
spec.loader.exec_module(pilot)


def documents():
    metadata = {
        "id": "synthetic-pilot-v1",
        "annotation_status": "human_verified",
        "synthetic": True,
        "bbox_units": "pixels",
        "partitions": [{"match_id": "m1", "camera_id": "c1", "split": "test"}],
    }
    truth = {
        "schema": 1,
        "dataset": metadata,
        "coverage": [
            {
                "match_id": "m1",
                "camera_id": "c1",
                "video_id": "v1",
                "start": 0,
                "end": 20,
                "events": True,
                "detections": ["person", "sports ball"],
                "rallies": True,
                "statistics": True,
            }
        ],
        "events": [],
        "detections": [],
        "rallies": [],
        "statistics": [],
    }
    pred = {
        "schema": 1,
        "dataset": {"id": metadata["id"], "bbox_units": "pixels"},
        "events": [],
        "detections": [],
        "rallies": [],
        "statistics": [],
    }
    return truth, pred


def row(ident, **kwargs):
    return {"id": ident, "match_id": "m1", "camera_id": "c1", "video_id": "v1", **kwargs}


def event(ident, time, kind="attack", **kwargs):
    return row(ident, time=time, kind=kind, status="accepted", **kwargs)


def box(ident, time, kind="person", bbox=None, **kwargs):
    return row(ident, time=time, class_name=kind, bbox=bbox or [0, 0, 10, 10], **kwargs)


def test_exact_event_metrics_and_unknown_attributes_have_known_denominators():
    truth, pred = documents()
    truth["events"] = [
        event("a", 1, player_id="p1", team_id="a", outcome="kill", direction="diagonal"),
        event("b", 2, "serve", player_id="p2", team_id="b", outcome="ace"),
        event("c", 3, player_id="p3", outcome=None),
    ]
    pred["events"] = [
        event("1", 1.1, player_id=None, team_id="a", outcome="error", direction="diagonal"),
        event("2", 2.1, "serve", player_id="p2", team_id="b", outcome="ace"),
        event("3", 6),
        {**event("4", 3), "status": "hypothesis"},
    ]
    got = pilot.evaluate(truth, pred)
    assert got["events"]["tp"] == 2
    assert got["events"]["fp"] == 1
    assert got["events"]["fn"] == 1
    assert got["events"]["precision"] == pytest.approx(2 / 3)
    assert got["events"]["recall"] == pytest.approx(2 / 3)
    assert got["events"]["f1"] == pytest.approx(2 / 3)
    assert got["events"]["hypotheses"] == 1
    assert got["events"]["player"]["unknown"] == 1
    assert got["events"]["player"]["accuracy_on_assigned"] == 1
    assert got["events"]["player"]["assignment_coverage"] == 0.5
    assert got["events"]["player"]["correct_fraction_of_identifiable"] == 0.5
    assert got["events"]["outcome"]["accuracy_on_assigned"] == 0.5
    assert got["events"]["direction"]["accuracy_on_assigned"] == 1
    assert got["events"]["by_kind"]["serve"]["precision"] == 1
    assert got["quality_gate"]["evaluated"] is False


def test_maximum_cardinality_not_nearest_greedy_and_deterministic_cost():
    truth, pred = documents()
    truth["events"] = [event("a", 1), event("b", 1.4)]
    # Nearest greedy pairs a->second(.1); b can then match neither first(.6)
    # but a->first(.2), b->second(.3) provides both true positives.
    pred["events"] = [event("first", 0.8), event("second", 1.1)]
    got = pilot.evaluate(truth, pred, event_tolerance=0.35)
    assert got["events"]["tp"] == 2
    assert {(x["truth_id"], x["prediction_id"]) for x in got["events"]["matched"]} == {("a", "first"), ("b", "second")}
    # All candidates within tolerance: choose minimum sum temporal distance.
    pred["events"] = [event("first", 1.05), event("second", 1.35)]
    got = pilot.evaluate(truth, pred, event_tolerance=1)
    assert [(x["truth_id"], x["prediction_id"]) for x in got["events"]["matched"]] == [("a", "first"), ("b", "second")]


def test_duplicate_detection_is_false_positive_and_interpolation_is_excluded():
    truth, pred = documents()
    truth["detections"] = [
        box("person", 1, player_id="p1", team_id="a"),
        box("ball", 1, "sports ball", [20, 20, 24, 24]),
    ]
    pred["detections"] = [
        box("one", 1.01, player_id="p1", team_id="a"),
        box("duplicate", 1.01),
        box("ball-bad", 1, "sports ball", [50, 50, 54, 54]),
        box("interpolated", 1, "sports ball", [20, 20, 24, 24], observed=False),
    ]
    got = pilot.evaluate(truth, pred)
    assert got["detections"]["tp"] == 1
    assert got["detections"]["fp"] == 2
    assert got["detections"]["fn"] == 1
    assert got["detections"]["precision"] == pytest.approx(1 / 3)
    assert got["detections"]["recall"] == 0.5
    assert got["detections"]["non_observed_predictions_excluded"] == 1
    assert got["detections"]["by_class"]["sports ball"]["recall"] == 0
    assert got["detections"]["player"]["correct"] == 1


def test_id_switches_are_track_identity_and_never_number_identity():
    truth, pred = documents()
    truth["detections"] = [
        box("g1", 1, track_id="true-track", player_id="p7", team_id="north"),
        box("g2", 1.5, track_id="true-track", player_id="p7", team_id="north"),
        box("g3", 2, track_id="true-track", player_id="p7", team_id="north"),
    ]
    pred["detections"] = [
        box("p1", 1, track_id=4, player_id="p7", team_id="north"),
        box("p2", 1.5, track_id=5, player_id="p7", team_id="south"),
        box("p3", 2, track_id=None, player_id=None),
    ]
    got = pilot.evaluate(truth, pred)
    assert got["detections"]["tracking"]["id_switches"] == 1
    assert got["detections"]["tracking"]["comparable_transitions"] == 1
    assert got["detections"]["tracking"]["unknown_predicted_track_ids"] == 1
    assert got["detections"]["player"]["assigned"] == 2
    assert got["detections"]["player"]["correct"] == 1
    assert got["detections"]["player"]["unknown"] == 1
    assert got["detections"]["player"]["accuracy_on_assigned"] == 0.5


def test_sources_coverage_and_class_prevent_false_matches():
    truth, pred = documents()
    truth["events"] = [event("g", 1)]
    pred["events"] = [event("other-video", 1, video_id="v2"), event("wrong-kind", 1, "serve"), event("unobserved", 21)]
    got = pilot.evaluate(truth, pred)
    assert got["events"]["tp"] == 0
    assert got["events"]["fp"] == 1  # Only in-scope wrong-class prediction.
    assert got["events"]["fn"] == 1
    assert got["events"]["accepted_predictions"] == 1


def test_rally_both_boundaries_and_unknown_status_are_required():
    truth, pred = documents()
    truth["rallies"] = [row("g1", start=1, end=5), row("g2", start=8, end=12)]
    pred["rallies"] = [
        row("p1", start=1.2, end=5.2, status="accepted"),
        row("p2", start=8.1, end=13, status="accepted"),
        row("p3", start=8, end=12, status="review"),
    ]
    got = pilot.evaluate(truth, pred)
    assert got["rallies"]["tp"] == 1
    assert got["rallies"]["fp"] == 1
    assert got["rallies"]["fn"] == 1
    assert got["rallies"]["matched"][0]["end_absolute_error"] == pytest.approx(0.2)


def test_zero_accepted_events_cannot_look_like_perfect_model():
    truth, pred = documents()
    truth["events"] = [event("g1", 1)]
    pred["events"] = [{**event("p1", 1), "status": "hypothesis"}]
    got = pilot.evaluate(truth, pred)
    assert got["events"]["precision"] is None
    assert got["events"]["recall"] == 0
    assert got["events"]["f1"] == 0
    assert any("Ноль принятых" in message for message in got["warnings"])
    empty, pempty = documents()
    assert pilot.evaluate(empty, pempty)["events"]["f1"] is None


def test_stat_error_only_known_values_and_complete_coverage():
    truth, pred = documents()
    truth["statistics"] = [
        row("g1", metric="attack_attempts", team_id="a", value=8),
        row("g2", metric="aces", team_id="a", value=2),
        row("g3", metric="jump_height", player_id="p1", value=None),
    ]
    pred["statistics"] = [
        row("p1", metric="attack_attempts", team_id="a", value=6),
        row("p2", metric="aces", team_id="a", value=None),
        row("p3", metric="jump_height", player_id="p1", value=0),
    ]
    got = pilot.evaluate(truth, pred)["statistics"]
    assert got["known_truth_values"] == 2
    assert got["compared_values"] == 1
    assert got["unknown_predictions"] == 1
    assert got["unknown_truth_values"] == 1
    assert got["mean_absolute_error"] == 2
    assert got["errors"][0]["error"] == -2
    truth["coverage"][0]["statistics"] = False
    assert pilot.evaluate(truth, pred)["statistics"]["known_truth_values"] == 0


def test_split_leakage_dataset_mismatch_and_unverified_truth_fail():
    truth, pred = documents()
    truth["dataset"]["partitions"].append({"match_id": "m1", "camera_id": "c2", "split": "train"})
    with pytest.raises(ValueError, match="Утечка"):
        pilot.evaluate(truth, pred)
    truth, pred = documents()
    pred["dataset"]["id"] = "wrong"
    with pytest.raises(ValueError, match="различаются"):
        pilot.evaluate(truth, pred)
    truth, pred = documents()
    truth["dataset"]["annotation_status"] = "automatic"
    with pytest.raises(ValueError, match="независимо"):
        pilot.evaluate(truth, pred)


@pytest.mark.parametrize("value", [math.nan, math.inf, -1])
def test_bad_tolerances_are_rejected(value):
    truth, pred = documents()
    with pytest.raises(ValueError):
        pilot.evaluate(truth, pred, event_tolerance=value)


def test_invalid_boxes_duplicate_ids_and_missing_coverage_are_rejected():
    truth, pred = documents()
    pred["detections"] = [box("bad", 1, bbox=[0, 0, 0, 10])]
    with pytest.raises(ValueError, match="площадь"):
        pilot.evaluate(truth, pred)
    truth, pred = documents()
    pred["events"] = [event("same", 1), event("same", 2)]
    with pytest.raises(ValueError, match="повторный"):
        pilot.evaluate(truth, pred)
    truth, pred = documents()
    truth.pop("coverage")
    with pytest.raises(ValueError, match="coverage"):
        pilot.evaluate(truth, pred)


def test_cli_writes_reproducible_input_hashes_and_refuses_overwrite(tmp_path):
    truth, pred = documents()
    truth["events"] = [event("g1", 1)]
    pred["events"] = [event("p1", 1)]
    source = tmp_path / "truth.json"
    result = tmp_path / "pred.json"
    out = tmp_path / "metrics.json"
    source.write_text(json.dumps(truth), encoding="utf-8")
    result.write_text(json.dumps(pred), encoding="utf-8")
    cmd = [
        sys.executable,
        str(ROOT / "scripts" / "evaluate_pilot.py"),
        "--truth",
        str(source),
        "--predictions",
        str(result),
        "--output",
        str(out),
    ]
    ran = subprocess.run(cmd, capture_output=True, text=True, check=True)
    assert "не автоматическое" in ran.stdout
    payload = json.loads(out.read_text())
    assert payload["events"]["f1"] == 1
    assert len(payload["input_sha256"]["truth"]) == 64
    again = subprocess.run(cmd, capture_output=True, text=True)
    assert again.returncode == 2
    assert json.loads(out.read_text()) == payload


def test_iou_known_answer():
    assert pilot.iou([0, 0, 10, 10], [5, 0, 15, 10]) == pytest.approx(1 / 3)
    assert pilot.iou([0, 0, 2, 2], [3, 3, 4, 4]) == 0


def test_missing_team_is_unknown_identity_not_false_player_error():
    truth, pred = documents()
    truth["events"] = [event("g", 1, player_id="7", team_id="north")]
    pred["events"] = [event("p", 1, player_id="7", team_id=None)]
    got = pilot.evaluate(truth, pred)["events"]["player"]
    assert got["assigned"] == 0
    assert got["unknown"] == 1
    assert got["accuracy_on_assigned"] is None
    assert got["correct_fraction_of_all_known_truth"] == 0


def test_bad_metadata_and_coverage_raise_clear_validation_errors():
    truth, pred = documents()
    pred["dataset"] = []
    with pytest.raises(ValueError, match="dataset"):
        pilot.evaluate(truth, pred)
    truth, pred = documents()
    truth["coverage"][0]["detections"] = None
    with pytest.raises(ValueError, match="detections"):
        pilot.evaluate(truth, pred)


def test_duplicate_stat_semantics_are_rejected_instead_of_last_value_winning():
    truth, pred = documents()
    truth["statistics"] = [
        row("g1", metric="aces", team_id="a", value=1),
        row("g2", metric="aces", team_id="a", value=2),
    ]
    with pytest.raises(ValueError, match="Повторная статистическая"):
        pilot.evaluate(truth, pred)


def gpu_module():
    module_spec = importlib.util.spec_from_file_location("gpu_diagnostics", ROOT / "scripts" / "diagnose_gpu.py")
    module = importlib.util.module_from_spec(module_spec)
    module_spec.loader.exec_module(module)
    return module


def test_missing_nvidia_command_does_not_claim_no_physical_gpu(monkeypatch):
    module = gpu_module()
    monkeypatch.setattr(module.shutil, "which", lambda _: None)
    result = module.nvidia_info()
    assert result["status"] == "not_available"
    assert result["physical_gpu_count"] is None
    assert result["gpus"] == []


def test_gpu_readout_does_not_claim_model_cuda_execution(monkeypatch):
    module = gpu_module()
    monkeypatch.setattr(module.shutil, "which", lambda _: "/fake/nvidia-smi")
    monkeypatch.setattr(
        module.subprocess, "run", lambda *a, **k: type("Result", (), {"stdout": "NVIDIA Test, 555.1, 12288\n"})()
    )
    result = module.nvidia_info()
    assert result["status"] == "observed"
    assert result["gpus"][0]["vram_total_mib"] == 12288
    monkeypatch.setattr(module, "nvidia_info", lambda: result)
    monkeypatch.setattr(
        module, "onnx_info", lambda: {"available_providers": ["CUDAExecutionProvider", "CPUExecutionProvider"]}
    )
    report = module.inspect()
    assert report["validation"]["cuda_execution_verified"] is False
    assert report["validation"]["model_inference_executed"] is False
    assert report["validation"]["vram_peak_measured"] is False


@pytest.mark.parametrize("coordinates", [[-0.1, 0, 0.5, 0.5], [0, 0, 1.1, 0.5]])
def test_normalized_boxes_reject_outside_image_even_with_matching_units(coordinates):
    truth, pred = documents()
    truth["dataset"]["bbox_units"] = "normalized"
    pred["dataset"]["bbox_units"] = "normalized"
    truth["detections"] = [box("g1", 1, bbox=[0, 0, 0.5, 0.5])]
    pred["detections"] = [box("p1", 1, bbox=coordinates)]
    with pytest.raises(ValueError, match="0..1"):
        pilot.evaluate(truth, pred)


def test_interpolated_position_is_not_observed_even_if_flag_claims_observed():
    truth, pred = documents()
    truth["detections"] = [box("ball", 1, "sports ball", [0, 0, 5, 5])]
    pred["detections"] = [box("interpolated", 1, "sports ball", [0, 0, 5, 5], observed=True, interpolated=True)]
    got = pilot.evaluate(truth, pred)["detections"]
    assert got["tp"] == 0 and got["fn"] == 1
    assert got["fp"] == 0
    assert got["non_observed_predictions_excluded"] == 1
    assert got["precision"] is None and got["recall"] == 0
