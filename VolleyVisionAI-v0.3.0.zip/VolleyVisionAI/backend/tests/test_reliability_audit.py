"""Regression checks for archive safety, queue recovery and launcher failure paths."""

import importlib.util
import json
import os
import sqlite3
import threading
from contextlib import closing
from types import SimpleNamespace

import pytest
from sqlalchemy.exc import OperationalError

from volleyvision import db as db_module, jobs
from volleyvision.db import DATA, ROOT, Session
from volleyvision.models import Job, Video


def load_script(name):
    spec = importlib.util.spec_from_file_location("audit_" + name, ROOT / "scripts" / (name + ".py"))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


backup_script = load_script("backup")
serve_script = load_script("serve")


def test_backup_preserves_preexisting_partial_file(tmp_path, client):
    other_work = tmp_path / "project.zip.part"
    other_work.write_text("another operation owns this file")
    output = backup_script.backup(tmp_path / "project.zip", data=DATA)
    assert output.is_file()
    assert other_work.read_text() == "another operation owns this file"
    assert list(tmp_path.glob("project.zip.*.part")) == []


def test_archive_publication_never_replaces_racing_destination(tmp_path):
    temporary, output = tmp_path / "pending", tmp_path / "archive.zip"
    temporary.write_bytes(b"new archive")
    output.write_bytes(b"existing user file")
    with pytest.raises(ValueError, match="уже существует"):
        backup_script._publish_no_replace(temporary, output)
    assert output.read_bytes() == b"existing user file"
    assert temporary.read_bytes() == b"new archive"


def test_backup_without_videos_clears_omitted_proxy_only_in_snapshot(tmp_path, client, match):
    with Session() as db:
        db.get(Video, match.vid).proxy_path = "derived/not-included.mp4"
        db.commit()
    archive = backup_script.backup(tmp_path / "metadata.zip", data=DATA)
    restored = backup_script.restore(archive, tmp_path / "restored")
    with closing(sqlite3.connect(restored / "data" / "volleyvision.db")) as db:
        assert db.execute("SELECT proxy_path FROM videos WHERE id=?", (match.vid,)).fetchone()[0] is None
    with Session() as db:
        assert db.get(Video, match.vid).proxy_path == "derived/not-included.mp4"
    assert (restored / "MISSING_VIDEOS.txt").is_file()


def test_sqlite_handles_explicitly_close_for_windows(tmp_path, client, monkeypatch):
    handles = []
    original_connect = sqlite3.connect

    class TrackedConnection(sqlite3.Connection):
        was_closed = False

        def close(self):
            self.was_closed = True
            return super().close()

    def connect(*args, **kwargs):
        kwargs["factory"] = TrackedConnection
        connection = original_connect(*args, **kwargs)
        handles.append(connection)
        return connection

    monkeypatch.setattr(backup_script.sqlite3, "connect", connect)
    archive = backup_script.backup(tmp_path / "portable.zip", data=DATA)
    backup_script.restore(archive, tmp_path / "restored")
    assert len(handles) == 3
    assert all(h.was_closed for h in handles)


@pytest.mark.parametrize("name", ["code/CON.txt", "code/file.", "code/folder /a", "code/.git/config"])
def test_restore_rejects_windows_paths_before_extraction(name, tmp_path):
    import zipfile

    archive = tmp_path / "unsafe.zip"
    with zipfile.ZipFile(archive, "w") as z:
        z.writestr("manifest.json", json.dumps({"format": 1, "files": {name: "0" * 64}, "originals_included": False}))
        z.writestr(name, "bad")
    with pytest.raises(ValueError):
        backup_script.restore(archive, tmp_path / "restored")
    assert not (tmp_path / "restored").exists()


def test_restore_rejects_case_aliases(tmp_path):
    import zipfile

    archive = tmp_path / "case.zip"
    with zipfile.ZipFile(archive, "w") as z:
        z.writestr("manifest.json", json.dumps({"format": 1, "files": {"code/A.py": "0" * 64, "code/a.py": "0" * 64}}))
        z.writestr("code/A.py", "one")
        z.writestr("code/a.py", "two")
    with pytest.raises(ValueError, match="совпадающие"):
        backup_script.restore(archive, tmp_path / "restored")


def test_launcher_closes_reserved_sockets_on_migration_failure(tmp_path, monkeypatch):
    sockets = []

    class FakeSocket:
        closed = False

        def __enter__(self):
            return self

        def __exit__(self, *args):
            self.close()

        def close(self):
            self.closed = True

        def setsockopt(self, *args):
            pass

        def bind(self, *args):
            pass

        def listen(self, *args):
            pass

    def socket():
        result = FakeSocket()
        sockets.append(result)
        return result

    def fail(*args):
        raise RuntimeError("test migration failure")

    monkeypatch.setattr(db_module, "DATA", tmp_path)
    monkeypatch.setattr(serve_script.socket, "socket", socket)
    monkeypatch.setattr(serve_script.command, "upgrade", fail)
    with pytest.raises(RuntimeError, match="migration failure"):
        serve_script.run()
    assert len(sockets) == 2 and all(s.closed for s in sockets)
    assert not (tmp_path / "server.json").exists()


def test_runtime_state_is_private_and_atomic(tmp_path, monkeypatch):
    state = tmp_path / "server.json"
    serve_script._write_state(state, {"token": "a" * 64})
    if os.name != "nt":
        assert state.stat().st_mode & 0o777 == 0o600
    original = state.read_bytes()

    def fail(*args):
        raise ValueError("test write failure")

    monkeypatch.setattr(serve_script.json, "dump", fail)
    with pytest.raises(ValueError):
        serve_script._write_state(state, {"token": "b" * 64})
    assert state.read_bytes() == original
    assert list(tmp_path.glob("server-*.tmp")) == []


def test_stop_token_handles_tcp_fragmentation():
    chunks = iter([b"a" * 17, b"a" * 47 + b"\n"])
    conn = SimpleNamespace(recv=lambda count: next(chunks))
    assert serve_script._read_token(conn) == "a" * 64


def test_stop_does_not_claim_completion_after_only_ack(tmp_path, monkeypatch):
    monkeypatch.setattr(db_module, "DATA", tmp_path)
    state = tmp_path / "server.json"
    state.write_text(json.dumps({"token": "a" * 64, "port": 12345}))

    class FakeConnection:
        def __enter__(self):
            return self

        def __exit__(self, *args):
            pass

        def sendall(self, value):
            assert value == b"a" * 64 + b"\n"

        def recv(self, size):
            return b"OK"

    monkeypatch.setattr(serve_script.socket, "create_connection", lambda *args, **kwargs: FakeConnection())
    with pytest.raises(RuntimeError, match="ещё завершает"):
        serve_script.stop(timeout=0)
    assert state.exists()


def test_worker_start_is_idempotent(monkeypatch):
    existing = SimpleNamespace(is_alive=lambda: True)
    monkeypatch.setattr(jobs, "worker", existing)
    jobs.start()
    assert jobs.worker is existing


def test_worker_loop_survives_one_transient_failure(monkeypatch):
    stop = threading.Event()
    calls = []

    def process():
        calls.append(1)
        if len(calls) == 1:
            raise OperationalError("temporary SQLite lock", {}, Exception("locked"))
        stop.set()

    monkeypatch.setattr(jobs, "stop_event", stop)
    monkeypatch.setattr(jobs, "process_next", process)
    jobs.loop()
    assert len(calls) == 2


def test_worker_retries_saving_completed_result_after_sqlite_lock(client, match, monkeypatch):
    jobs.stop()
    with Session() as db:
        job = Job(video_id=match.vid, kind="proxy", status="running")
        db.add(job)
        db.commit()
        jid = job.id
    calls = []

    def sometimes_session():
        calls.append(1)
        if len(calls) == 1:
            raise OperationalError("temporary lock", {}, Exception("locked"))
        return Session()

    monkeypatch.setattr(jobs, "Session", sometimes_session)
    monkeypatch.setattr(jobs, "stop_event", threading.Event())
    jobs._finish(jid, match.vid, "completed", path="derived/saved.mp4")
    with Session() as db:
        assert db.get(Job, jid).status == "completed"
        assert db.get(Video, match.vid).proxy_path == "derived/saved.mp4"
    assert len(calls) == 2


def test_worker_can_process_after_a_failed_job(client, match, monkeypatch):
    jobs.stop()
    with Session() as db:
        first = Job(video_id=match.vid, kind="proxy")
        second = Job(video_id=match.vid, kind="proxy")
        db.add_all([first, second])
        db.commit()
        first_id, second_id = first.id, second.id
    attempts = []

    def process(video, cancel):
        attempts.append(1)
        if len(attempts) == 1:
            raise ValueError("bad source")
        return "derived/recovered.mp4"

    monkeypatch.setattr(jobs, "make_proxy", process)
    monkeypatch.setattr(jobs, "stop_event", threading.Event())
    jobs.process_next()
    jobs.process_next()
    with Session() as db:
        assert db.get(Job, first_id).status == "failed"
        assert db.get(Job, second_id).status == "completed"


def test_full_backup_refuses_to_claim_missing_originals(tmp_path, client, match):
    with Session() as db:
        video = db.get(Video, match.vid)
        original_path = video.path
        video.path = "originals/missing-file.mp4"
        db.commit()
    try:
        with pytest.raises(ValueError, match="отсутствуют исходные видео"):
            backup_script.backup(tmp_path / "full.zip", include_videos=True, data=DATA)
        assert not (tmp_path / "full.zip").exists()
        assert list(tmp_path.glob("full.zip.*.part")) == []
        # Metadata can still be backed up; no source record is changed to fake success.
        assert backup_script.backup(tmp_path / "metadata.zip", data=DATA).is_file()
    finally:
        with Session() as db:
            db.get(Video, match.vid).path = original_path
            db.commit()


def test_worker_restart_serializes_with_inflight_stop(monkeypatch):
    original_thread = threading.Thread
    joining, release, started = threading.Event(), threading.Event(), threading.Event()

    class PreviousWorker:
        alive = True

        def join(self, timeout):
            joining.set()
            assert release.wait(2)
            self.alive = False

        def is_alive(self):
            return self.alive

    class NewWorker:
        alive = False

        def __init__(self, **kwargs):
            pass

        def start(self):
            self.alive = True

        def is_alive(self):
            return self.alive

    monkeypatch.setattr(jobs, "worker", PreviousWorker())
    monkeypatch.setattr(jobs, "stop_event", threading.Event())
    monkeypatch.setattr(jobs.threading, "Thread", NewWorker)
    stopping = original_thread(target=jobs.stop)
    stopping.start()
    assert joining.wait(2)

    def start():
        jobs.start()
        started.set()

    restarting = original_thread(target=start)
    restarting.start()
    try:
        assert not started.wait(0.05)
    finally:
        release.set()
        stopping.join(2)
        restarting.join(2)
    assert started.is_set()
    assert isinstance(jobs.worker, NewWorker) and jobs.worker.is_alive()


@pytest.mark.parametrize("started", [False, True])
def test_launcher_rejects_normal_return_without_server_readiness(tmp_path, monkeypatch, started):
    """Some server/lifespan failure paths return rather than raising an exception."""
    sockets = []

    class FakeSocket:
        closed = False

        def __enter__(self):
            return self

        def __exit__(self, *args):
            self.close()

        def close(self):
            self.closed = True

        def setsockopt(self, *args):
            pass

        def bind(self, *args):
            pass

        def listen(self, *args):
            pass

        def getsockname(self):
            return ("127.0.0.1", 12345)

    def socket():
        result = FakeSocket()
        sockets.append(result)
        return result

    server = SimpleNamespace(started=started, should_exit=True, run=lambda **kwargs: None)
    monkeypatch.setattr(db_module, "DATA", tmp_path)
    monkeypatch.setattr(serve_script.socket, "socket", socket)
    monkeypatch.setattr(serve_script.command, "upgrade", lambda *args: None)
    monkeypatch.setattr(serve_script.uvicorn, "Server", lambda config: server)
    monkeypatch.setattr(serve_script.threading, "Thread", lambda **kwargs: SimpleNamespace(start=lambda: None))
    monkeypatch.setattr(serve_script.sys, "argv", ["serve.py", "--no-browser"])
    if started:
        serve_script.run()
    else:
        with pytest.raises(RuntimeError, match="не запустился"):
            serve_script.run()
    assert len(sockets) == 2 and all(s.closed for s in sockets)
    assert not (tmp_path / "server.json").exists()
