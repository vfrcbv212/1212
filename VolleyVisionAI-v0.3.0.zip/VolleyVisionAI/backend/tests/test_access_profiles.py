"""Global access checks exercise routes/files and a realistic private-proxy chain."""

import asyncio
import json

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient

from volleyvision import access
from volleyvision.access import AccessConfig, AccessMiddleware
from volleyvision.main import app

HOST = "desktop.example-tail.ts.net"
TOKEN = "a" * 64
CONFIG = AccessConfig("remote-private", HOST, frozenset({"owner@example.com"}), TOKEN)
PREFIX = CONFIG.upstream_prefix


def private_headers(**overrides):
    return {
        "host": HOST,
        "x-forwarded-host": HOST,
        "x-forwarded-proto": "https",
        "tailscale-user-login": "owner@example.com",
        **overrides,
    }


def remote_client(config=CONFIG, peer="127.0.0.1"):
    private_app = FastAPI()
    # Reuse real existing/future endpoint routes, without nested local middleware.
    private_app.router.routes = app.router.routes
    private_app.add_middleware(AccessMiddleware, config=config)
    return TestClient(private_app, base_url=f"https://{HOST}", client=(peer, 50000), follow_redirects=False)


@pytest.mark.parametrize(
    "path",
    [
        "/api/matches",
        "/api/teams",
        "/api/jobs",
        "/api/videos/1/stream",
        "/api/clips/1/download",
        "/api/matches/1/export/json",
        "/",
        "/assets/test.js",
        "/api/matches/1/report",
        "/api/uploads",
    ],
)
def test_unknown_user_cannot_read_any_route(path):
    with remote_client() as client:
        r = client.get(PREFIX + path, headers=private_headers(**{"tailscale-user-login": "stranger@example.com"}))
    assert r.status_code == 403
    assert "stranger" not in r.text


def test_forged_identity_headers_without_private_upstream_path_do_not_authenticate():
    with remote_client() as client:
        for path in ["/api/matches", "/api/videos/1/stream", "/api/matches/1/export/json"]:
            assert client.get(path, headers=private_headers()).status_code == 403
            assert client.get("/__vv_upstream_" + "b" * 64 + path, headers=private_headers()).status_code == 403


def test_nonloopback_cannot_spoof_proxy_even_with_capability():
    with remote_client(peer="100.64.0.9") as client:
        assert client.get(PREFIX + "/api/teams", headers=private_headers()).status_code == 403


@pytest.mark.parametrize(
    "overrides",
    [
        {"tailscale-user-login": ""},
        {"tailscale-user-login": "owner@example.com,other@example.com"},
        {"host": "attacker.example"},
        {"x-forwarded-host": "attacker.example"},
        {"x-forwarded-proto": "http"},
        {"tailscale-funnel-request": "?1"},
        {"origin": "https://attacker.example"},
        {"origin": "null"},
        {"sec-fetch-site": "cross-site"},
        {"sec-fetch-site": "same-site"},
    ],
)
def test_private_proxy_requires_all_authorization_parts(overrides):
    with remote_client() as client:
        assert client.get(PREFIX + "/api/teams", headers=private_headers(**overrides)).status_code == 403


def test_authorized_private_request_serves_actual_api_and_writes(client):
    with remote_client() as private:
        r = private.post(
            PREFIX + "/api/teams", headers=private_headers(origin=f"https://{HOST}"), json={"name": "Private Team"}
        )
        assert r.status_code == 201, r.text
        response = private.get(PREFIX + "/api/teams", headers=private_headers())
        assert response.status_code == 200
        assert response.json()[0]["name"] == "Private Team"
        assert response.headers["cache-control"] == "no-store"
        assert TOKEN not in response.text
        assert response.headers["referrer-policy"] == "same-origin"


def test_authorized_private_video_keeps_http_range(client, match):
    with remote_client() as private:
        response = private.get(PREFIX + f"/api/videos/{match.vid}/stream", headers=private_headers(range="bytes=0-99"))
        assert response.status_code == 206
        assert len(response.content) == 100
        exported = private.get(PREFIX + f"/api/matches/{match.mid}/export/json", headers=private_headers())
        assert exported.status_code == 200
        assert exported.json()["match"]["id"] == match.mid


def test_local_profile_does_not_trust_tailscale_or_forwarded_headers(client):
    assert client.get("/api/teams").status_code == 200
    assert client.get("/api/teams", headers={"Tailscale-User-Login": "owner@example.com"}).status_code == 403
    assert client.get("/api/teams", headers={"X-Forwarded-Host": HOST}).status_code == 403


def test_private_requires_explicit_complete_configuration(tmp_path, monkeypatch):
    path = tmp_path / "private.json"
    monkeypatch.setattr(access, "config_path", lambda: path)
    with pytest.raises(ValueError, match="не настроен"):
        access.load_config("remote-private")
    path.write_text(json.dumps({"format": 1, "hostname": HOST, "allowed_logins": [], "upstream_token": TOKEN}))
    with pytest.raises(ValueError, match="allowed_logins"):
        access.load_config("remote-private")
    assert access.load_config("local").profile == "local"
    with pytest.raises(ValueError, match="Профиль"):
        access.load_config("public")


def test_configure_preserves_capability_without_printing_it(tmp_path, monkeypatch, capsys):
    path = tmp_path / "private.json"
    monkeypatch.setattr(access, "config_path", lambda: path)
    first = access.configure(HOST, ["Owner@example.com"])
    second = access.configure(HOST, ["Owner@example.com", "coach@example.com"])
    assert first.upstream_token == second.upstream_token
    assert second.allowed_logins == frozenset({"owner@example.com", "coach@example.com"})
    assert first.upstream_token not in capsys.readouterr().out
    assert not list(tmp_path.glob("*.tmp"))


def test_denied_upstream_request_strips_capability_before_access_log():
    middleware = AccessMiddleware(lambda *_: None, config=CONFIG)
    scope = {
        "type": "http",
        "method": "GET",
        "path": PREFIX + "/api/matches",
        "raw_path": (PREFIX + "/api/matches").encode(),
        "query_string": b"",
        "client": ("127.0.0.1", 9),
        "headers": [
            (k.encode(), v.encode())
            for k, v in private_headers(**{"tailscale-user-login": "other@example.com"}).items()
        ],
    }
    messages = []

    async def send(message):
        messages.append(message)

    asyncio.run(middleware(scope, None, send))
    assert scope["path"] == "/api/matches"
    assert TOKEN.encode() not in scope["raw_path"]
    assert messages[0]["status"] == 403


def test_repeated_identity_header_is_rejected():
    with remote_client() as client:
        headers = list(private_headers().items()) + [("tailscale-user-login", "owner@example.com")]
        assert client.get(PREFIX + "/api/teams", headers=headers).status_code == 403


def test_nonascii_unauthorized_path_is_denied_instead_of_crashing():
    with remote_client() as client:
        assert client.get("/матчи", headers=private_headers()).status_code == 403


@pytest.mark.parametrize(
    "payload",
    [
        {"format": 1, "hostname": None, "allowed_logins": ["owner@example.com"], "upstream_token": TOKEN},
        {"format": 1, "hostname": HOST, "allowed_logins": "owner@example.com", "upstream_token": TOKEN},
        {"format": 1, "hostname": HOST, "allowed_logins": ["*"], "upstream_token": TOKEN},
        {"format": 1, "hostname": HOST, "allowed_logins": ["owner@example.com"], "upstream_token": "weak"},
    ],
)
def test_invalid_private_configuration_fails_closed(tmp_path, monkeypatch, payload):
    path = tmp_path / "private.json"
    path.write_text(json.dumps(payload))
    monkeypatch.setattr(access, "config_path", lambda: path)
    with pytest.raises(ValueError):
        access.load_config("remote-private")


def test_local_cross_site_get_cannot_trigger_frame_decode_without_origin():
    with TestClient(app, base_url="http://127.0.0.1:8765") as client:
        assert client.get("/api/videos/1/frame", headers={"sec-fetch-site": "cross-site"}).status_code == 403
        assert client.get("/api/teams", headers={"sec-fetch-site": "none"}).status_code == 200
