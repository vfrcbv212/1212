"""Math/validation tests and actual local-model smoke; no fake sport-accuracy claim."""

import hashlib
import importlib.util
import subprocess
from pathlib import Path
from threading import Event

import pytest

from volleyvision import vision
from volleyvision.db import ROOT


def detection(box, confidence=0.8, kind=0):
    return {
        "bbox": box,
        "confidence": confidence,
        "class_id": kind,
        "class_name": vision.CLASS_NAMES[kind],
        "observed": True,
    }


def test_iou_and_nms_do_not_merge_distinct_objects_or_classes():
    assert vision.box_iou([0, 0, 10, 10], [5, 0, 15, 10]) == pytest.approx(1 / 3)
    assert vision.box_iou([0, 0, 0, 0], [0, 0, 0, 0]) == 0
    got = vision.nms(
        [
            detection([0, 0, 10, 10], 0.9),
            detection([1, 0, 11, 10], 0.8),
            detection([0, 0, 10, 10], 0.7, 32),
            detection([30, 0, 40, 10], 0.6),
        ]
    )
    assert len(got) == 3
    assert [d["confidence"] for d in got] == [0.9, 0.7, 0.6]


def test_baseline_track_ids_are_not_player_identities_or_interpolated_observations():
    tracker = vision.IoUTracker(max_gap=1)
    first = tracker.update([detection([0, 0, 10, 10])], 0)
    second = tracker.update([detection([1, 0, 11, 10])], 0.2)
    assert first[0]["track_id"] == second[0]["track_id"]
    assert first[0]["player_id"] is None and first[0]["team_id"] is None
    assert tracker.update([], 0.4) == []
    later = tracker.update([detection([1, 0, 11, 10])], 2)
    assert later[0]["track_id"] != first[0]["track_id"]
    assert later[0]["tracking_method"] == "greedy_iou_baseline"


@pytest.mark.parametrize("model", ["unknown", "../outside", "rf-detr-paid"])
def test_unknown_models_cannot_load_arbitrary_paths(model):
    with pytest.raises(ValueError):
        vision.get_model_manifest(model)


def test_corrupt_weights_are_rejected_before_onnx_load(tmp_path, monkeypatch):
    bad = tmp_path / "bad.onnx"
    bad.write_bytes(b"not-the-approved-model")
    monkeypatch.setattr(
        vision, "get_runtime_info", lambda *args: {"dependencies_installed": True, "provider": "CPUExecutionProvider"}
    )
    with pytest.raises(ValueError, match="Контрольная сумма"):
        vision.YoloXDetector(model_path=bad)


@pytest.mark.parametrize(
    "start,end,fps", [(0, 0, 5), (-1, 5, 5), (0, 61, 5), (0, 3, 0), (0, 3, 100), (float("nan"), 3, 5)]
)
def test_segment_bounds_fail_before_decode(start, end, fps):
    with pytest.raises(ValueError):
        vision.scan_segment("not-opened.mp4", start, end, sample_fps=fps)


def test_installer_rejects_bad_offline_file_and_preserves_previous_model(tmp_path, monkeypatch):
    spec = importlib.util.spec_from_file_location("model_installer", ROOT / "scripts" / "install_models.py")
    installer = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(installer)
    target = tmp_path / "model.onnx"
    target.write_bytes(b"previous-corrupt-file")
    source = tmp_path / "untrusted.onnx"
    source.write_bytes(b"wrong")
    monkeypatch.setattr(installer, "model_path", lambda _: target)
    with pytest.raises(ValueError, match="размер"):
        installer.install("yolox-tiny", source)
    assert target.read_bytes() == b"previous-corrupt-file"
    assert not list(tmp_path.glob("*.part"))


def _actual_detector():
    pytest.importorskip("cv2", reason="optional AI dependencies not installed")
    pytest.importorskip("onnxruntime", reason="optional AI dependencies not installed")
    path = ROOT / "data" / "models" / "yolox_tiny.onnx"
    if not path.is_file():
        pytest.skip("official weights require python scripts/install_models.py")
    return vision.YoloXDetector(device="cpu", model_path=path)


def test_actual_pinned_model_detects_real_public_domain_person():
    detector = _actual_detector()
    import cv2

    fixture = Path(__file__).parent / "fixtures" / "astronaut.png"
    image = cv2.imread(str(fixture))
    observed = detector.detect_frame(image)
    people = [d for d in observed if d["class_name"] == "person"]
    assert len(people) == 1
    assert people[0]["confidence"] > 0.8
    assert people[0]["observed"] and not people[0]["interpolated"]
    assert detector.runtime["active_device"] == "cpu"
    assert detector.runtime["device_verified_by_session"]
    assert not any(d["class_name"] == "sports ball" for d in observed)


def test_actual_frame_pipeline_uses_source_pts_and_cancels(tmp_path):
    detector = _actual_detector()
    fixture = Path(__file__).parent / "fixtures" / "astronaut.png"
    video = tmp_path / "constructed-from-real-public-domain-photo.mp4"
    subprocess.run(
        [
            "ffmpeg",
            "-nostdin",
            "-v",
            "error",
            "-loop",
            "1",
            "-i",
            str(fixture),
            "-t",
            "1",
            "-r",
            "10",
            "-pix_fmt",
            "yuv420p",
            "-c:v",
            "libx264",
            "-threads",
            "2",
            str(video),
        ],
        check=True,
    )
    updates = []
    result = vision.scan_segment(video, 0, 1, sample_fps=2, detector=detector, progress=updates.append)
    assert [f["time"] for f in result["frames"]] == [0, 0.5]
    assert all(any(d["class_name"] == "person" for d in f["detections"]) for f in result["frames"])
    assert all(f["timestamp_source"] == "video_pts" for f in result["frames"])
    assert result["runtime"]["frames_analyzed"] == 2
    assert result["runtime"]["inference_calls"] == 2
    assert result["model"]["verified"] and not result["actions_inferred"]
    assert updates[-1] == 1
    cancelled = Event()
    cancelled.set()
    with pytest.raises(InterruptedError):
        vision.scan_segment(video, 0, 1, detector=detector, cancel_event=cancelled)


def test_reference_fixture_checksum_for_reproducible_pilot():
    path = Path(__file__).parent / "fixtures" / "astronaut.png"
    assert (
        hashlib.sha256(path.read_bytes()).hexdigest()
        == "88431cd9653ccd539741b555fb0a46b61558b301d4110412b5bc28b5e3ea6cb5"
    )


def _installer_module():
    spec = importlib.util.spec_from_file_location("safe_model_installer", ROOT / "scripts" / "install_models.py")
    installer = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(installer)
    return installer


@pytest.mark.parametrize(
    "target",
    [
        "http://release-assets.githubusercontent.com/model.onnx",
        "https://attacker.example/model.onnx",
        "https://github.com:8443/model.onnx",
        "https://user:password@github.com/model.onnx",
    ],
)
def test_installer_rejects_bad_redirect_before_requesting_target(target):
    import httpx
    import io

    installer = _installer_module()
    requested = []

    def handler(request):
        requested.append(str(request.url))
        return httpx.Response(302, headers={"Location": target})

    with httpx.Client(transport=httpx.MockTransport(handler), follow_redirects=True) as client:
        with pytest.raises(ValueError, match="HTTPS"):
            installer._download("https://github.com/approved-model", io.BytesIO(), 10, client)
    assert requested == ["https://github.com/approved-model"]


def test_installer_follows_only_validated_official_https_redirects():
    import httpx
    import io

    installer = _installer_module()
    requested = []

    def handler(request):
        requested.append(request.url.host)
        if request.url.host == "github.com":
            return httpx.Response(
                302, headers={"Location": "https://release-assets.githubusercontent.com/model.onnx?approved=1"}
            )
        return httpx.Response(200, content=b"pinned artifact bytes")

    output = io.BytesIO()
    with httpx.Client(transport=httpx.MockTransport(handler)) as client:
        installer._download("https://github.com/approved-model", output, 100, client)
    assert requested == ["github.com", "release-assets.githubusercontent.com"]
    assert output.getvalue() == b"pinned artifact bytes"


def test_installer_redirect_loop_is_bounded():
    import httpx
    import io

    installer = _installer_module()
    requested = []

    def handler(request):
        requested.append(str(request.url))
        return httpx.Response(302, headers={"Location": "/loop"})

    with httpx.Client(transport=httpx.MockTransport(handler)) as client:
        with pytest.raises(ValueError, match="перенаправлений"):
            installer._download("https://github.com/loop", io.BytesIO(), 100, client)
    assert len(requested) == 6


def test_installer_oversized_response_stops_before_file_can_be_used():
    import httpx
    import io

    installer = _installer_module()
    with httpx.Client(
        transport=httpx.MockTransport(lambda request: httpx.Response(200, content=b"oversized"))
    ) as client:
        with pytest.raises(ValueError, match="Размер"):
            installer._download("https://github.com/approved", io.BytesIO(), 2, client)


def test_telemetry_disabled_before_runtime_initialization():
    import os

    assert os.environ["ORT_DISABLE_TELEMETRY"] == "1"


def _fake_cuda_session_environment(tmp_path, monkeypatch, requested="auto"):
    import types

    ort = pytest.importorskip("onnxruntime", reason="optional AI dependencies not installed")

    model = tmp_path / "approved.onnx"
    model.write_bytes(b"approved")
    sha = hashlib.sha256(b"approved").hexdigest()
    monkeypatch.setattr(vision, "_model_spec", lambda _: {"bytes": 8, "sha256": sha, "input_size": 416})
    monkeypatch.setattr(vision, "get_model_manifest", lambda *_: {"installed": True, "verified": True, "sha256": sha})
    monkeypatch.setattr(
        vision,
        "get_runtime_info",
        lambda *args: {
            "dependencies_installed": True,
            "provider": "CUDAExecutionProvider",
            "requested_device": requested,
        },
    )

    class Session:
        def get_providers(self):
            return ["CPUExecutionProvider"]

        def get_inputs(self):
            return [types.SimpleNamespace(name="input", shape=[1, 3, 416, 416])]

    return model, ort, Session


def test_auto_records_cpu_when_cuda_session_falls_back(tmp_path, monkeypatch):
    model, ort, Session = _fake_cuda_session_environment(tmp_path, monkeypatch)
    monkeypatch.setattr(ort, "preload_dlls", lambda: None)
    monkeypatch.setattr(ort, "InferenceSession", lambda *args, **kwargs: Session())
    detector = vision.YoloXDetector(model_path=model, device="auto")
    assert detector.runtime["active_device"] == "cpu"
    assert detector.runtime["provider_fallback"]
    assert detector.runtime["gpu_operator_placement_verified"] is False


def test_explicit_cuda_never_succeeds_as_cpu(tmp_path, monkeypatch):
    model, ort, Session = _fake_cuda_session_environment(tmp_path, monkeypatch, requested="cuda")
    monkeypatch.setattr(ort, "preload_dlls", lambda: None)
    monkeypatch.setattr(ort, "InferenceSession", lambda *args, **kwargs: Session())
    with pytest.raises(ValueError, match="активировать CUDA"):
        vision.YoloXDetector(model_path=model, device="cuda")


def test_auto_can_recover_if_cuda_initialization_raises_before_ort_fallback(tmp_path, monkeypatch):
    model, ort, Session = _fake_cuda_session_environment(tmp_path, monkeypatch)
    calls = []
    monkeypatch.setattr(ort, "preload_dlls", lambda: None)

    def create(*args, **kwargs):
        calls.append(kwargs["providers"])
        if kwargs["providers"][0] == "CUDAExecutionProvider":
            raise RuntimeError("CUDA DLL unavailable")
        return Session()

    monkeypatch.setattr(ort, "InferenceSession", create)
    detector = vision.YoloXDetector(model_path=model, device="auto")
    assert calls == [["CUDAExecutionProvider", "CPUExecutionProvider"], ["CPUExecutionProvider"]]
    assert detector.runtime["active_device"] == "cpu" and detector.runtime["provider_fallback"]
