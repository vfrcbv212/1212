import os
import subprocess
import sys
import time
from threading import Event
from types import SimpleNamespace

import httpx
import pytest

from volleyvision.db import DATA, ROOT
from volleyvision.media import make_proxy


def test_graceful_stop_restart_preserves_data(tmp_path):
    env = {**os.environ, "VOLLEYVISION_DATA": str(tmp_path / "runtime-data")}
    python = sys.executable

    def start():
        process = subprocess.Popen(
            [python, str(ROOT / "scripts" / "serve.py"), "--no-browser"],
            cwd=ROOT,
            env=env,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        for _ in range(100):
            if process.poll() is not None:
                pytest.fail("Server exited before readiness")
            try:
                if httpx.get("http://127.0.0.1:8765/api/health", timeout=1).status_code == 200:
                    return process
            except httpx.HTTPError:
                pass
            time.sleep(0.05)
        process.terminate()
        process.wait(timeout=10)
        pytest.fail("Server readiness timeout")

    def stop(process):
        subprocess.run(
            [python, str(ROOT / "scripts" / "serve.py"), "--stop"],
            cwd=ROOT,
            env=env,
            check=True,
            capture_output=True,
            timeout=10,
        )
        assert process.wait(timeout=10) == 0
        assert not (tmp_path / "runtime-data" / "server.json").exists()

    process = start()
    try:
        response = httpx.post("http://127.0.0.1:8765/api/teams", json={"name": "Сохраняется после рестарта"})
        assert response.status_code == 201
        stop(process)
        process = start()
        teams = httpx.get("http://127.0.0.1:8765/api/teams").json()
        assert teams[0]["name"] == "Сохраняется после рестарта"
        stop(process)
    finally:
        if process.poll() is None:
            process.terminate()
            process.wait(timeout=10)


def test_proxy_cancellation_removes_partial_output(video_file):
    source = DATA / "originals" / "cancellation.mp4"
    source.write_bytes(video_file.read_bytes())
    cancel = Event()
    cancel.set()
    with pytest.raises(InterruptedError):
        make_proxy(SimpleNamespace(id=999, path=str(source.relative_to(DATA))), cancel)
    assert not (DATA / "derived" / "999-proxy.tmp.mp4").exists()
    assert not (DATA / "derived" / "999-proxy.mp4").exists()
