"""Independent persistence checks for collisions and upgrading a populated v0.1 database."""

import os
import sqlite3
import subprocess
import sys

import pytest
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm.exc import StaleDataError

from volleyvision.db import ROOT, Session
from volleyvision.models import Rally, Video


def test_atomic_rally_correction_cannot_lose_competing_winner(match):
    with Session() as first, Session() as second:
        a, b = first.get(Rally, match.rally), second.get(Rally, match.rally)
        a.winner_team_id, a.revision = match.b, 2
        first.commit()
        b.winner_team_id, b.revision = match.a, 2
        with pytest.raises(StaleDataError):
            second.commit()
        second.rollback()
    with Session() as db:
        assert db.get(Rally, match.rally).winner_team_id == match.b


def test_database_rejects_duplicate_video_even_when_api_checks_race(match):
    with Session() as db:
        video = db.get(Video, match.vid)
        fields = {c.name: getattr(video, c.name) for c in Video.__table__.columns if c.name != "id"}
        db.add(Video(**fields))
        with pytest.raises(IntegrityError):
            db.commit()
        db.rollback()


def test_database_rejects_overlapping_rally_even_when_api_checks_race(match):
    with Session() as db:
        rally = db.get(Rally, match.rally)
        fields = {c.name: getattr(rally, c.name) for c in Rally.__table__.columns if c.name != "id"}
        fields.update(start=1, end=3)
        db.add(Rally(**fields))
        with pytest.raises(IntegrityError):
            db.commit()
        db.rollback()


def test_rally_api_rejects_stale_winner_correction(client, match):
    before = client.get(f"/api/matches/{match.mid}").json()["rallies"][0]
    body = {
        k: before[k]
        for k in ("set_id", "video_id", "start", "end", "serving_team_id", "winner_team_id", "rotation", "revision")
    }
    body["winner_team_id"] = match.b
    first = client.put(f"/api/rallies/{match.rally}", json=body)
    assert first.status_code == 200, first.text
    body["winner_team_id"] = match.a
    second = client.put(f"/api/rallies/{match.rally}", json=body)
    assert second.status_code == 409, second.text
    score = client.get(f"/api/matches/{match.mid}/stats").json()["sets"][0]
    assert (score["home"], score["away"]) == (0, 1)


def test_upgrade_preserves_existing_video_events_and_foreign_keys(tmp_path):
    data = tmp_path / "populated-v01"
    env = {**os.environ, "VOLLEYVISION_DATA": str(data)}
    command = [sys.executable, "-m", "alembic", "-c", str(ROOT / "alembic.ini"), "upgrade"]
    subprocess.run([*command, "fe256e772f1e"], cwd=ROOT, env=env, check=True, capture_output=True)
    database = data / "volleyvision.db"
    with sqlite3.connect(database) as db:
        db.execute("PRAGMA foreign_keys=ON")
        db.executemany("INSERT INTO teams(id,name) VALUES (?,?)", [(1, "Один"), (2, "Два")])
        db.execute("INSERT INTO matches(id,home_id,away_id,date,title) VALUES(1,1,2,'2026-11-15','Исходный матч')")
        db.execute("INSERT INTO sets(id,match_id,number,initial_home,initial_away) VALUES(1,1,1,0,0)")
        db.execute(
            """INSERT INTO videos(id,match_id,name,path,sha256,size,duration,width,height,fps,codec,position)
                      VALUES(1,1,'real.mp4','originals/real.mp4',?,128,20,1920,1080,60,'h264',0)""",
            ("a" * 64,),
        )
        db.execute(
            "INSERT INTO rallies(id,match_id,set_id,video_id,start,end,serving_team_id,winner_team_id,status) VALUES(1,1,1,1,0,10,1,1,'manual')"
        )
        db.execute("""INSERT INTO events(id,match_id,rally_id,video_id,time,kind,team_id,outcome,status,source,deleted,revision,updated_at)
                       VALUES(1,1,1,1,4,'attack',1,'kill','manual','manual',0,3,'2026-11-15')""")
    subprocess.run([*command, "head"], cwd=ROOT, env=env, check=True, capture_output=True)
    # Idempotent refresh must not rewrite user data.
    subprocess.run([*command, "head"], cwd=ROOT, env=env, check=True, capture_output=True)
    with sqlite3.connect(database) as db:
        db.execute("PRAGMA foreign_keys=ON")
        assert db.execute("PRAGMA foreign_key_check").fetchall() == []
        assert db.execute("SELECT name,path,sha256 FROM videos").fetchone() == (
            "real.mp4",
            "originals/real.mp4",
            "a" * 64,
        )
        assert db.execute("SELECT winner_team_id,revision FROM rallies").fetchone() == (1, 1)
        assert db.execute("SELECT outcome,revision FROM events").fetchone() == ("kill", 3)
        assert db.execute("PRAGMA integrity_check").fetchone()[0] == "ok"


def test_event_commit_rechecks_rally_changed_after_validation(match):
    from volleyvision.models import Event

    # Simulate validation before a competing correction commits tighter bounds.
    with Session() as stale, Session() as editor:
        loaded = stale.get(Rally, match.rally)
        assert loaded.start <= 1.5 <= loaded.end
        changed = editor.get(Rally, match.rally)
        changed.end, changed.revision = 1, 2
        editor.commit()
        stale.add(
            Event(
                match_id=match.mid,
                rally_id=match.rally,
                video_id=match.vid,
                time=1.5,
                kind="attack",
                team_id=match.a,
                player_id=match.p,
                outcome="kill",
            )
        )
        with pytest.raises(IntegrityError):
            stale.commit()
        stale.rollback()


def test_rally_commit_rechecks_event_added_after_validation(match):
    from volleyvision.models import Event

    with Session() as editor, Session() as writer:
        loaded = editor.get(Rally, match.rally)
        writer.add(
            Event(
                match_id=match.mid,
                rally_id=match.rally,
                video_id=match.vid,
                time=1.5,
                kind="attack",
                team_id=match.a,
                player_id=match.p,
                outcome="kill",
            )
        )
        writer.commit()
        loaded.end, loaded.revision = 1, 2
        with pytest.raises(IntegrityError):
            editor.commit()
        editor.rollback()
    with Session() as db:
        assert db.get(Rally, match.rally).end == 4


def test_duplicate_legacy_video_blocks_upgrade_before_any_schema_change(tmp_path):
    data = tmp_path / "legacy-duplicates"
    env = {**os.environ, "VOLLEYVISION_DATA": str(data)}
    command = [sys.executable, "-m", "alembic", "-c", str(ROOT / "alembic.ini"), "upgrade"]
    subprocess.run([*command, "fe256e772f1e"], cwd=ROOT, env=env, check=True, capture_output=True)
    database = data / "volleyvision.db"
    with sqlite3.connect(database) as db:
        for ident in (1, 2):
            db.execute(
                """INSERT INTO videos(id,match_id,name,path,sha256,size,duration,width,height,fps,codec,position)
                VALUES(?,1,'duplicate.mp4','originals/same.mp4',?,128,20,1920,1080,60,'h264',0)""",
                (ident, "b" * 64),
            )
    result = subprocess.run([*command, "head"], cwd=ROOT, env=env, capture_output=True, text=True)
    assert result.returncode != 0
    assert "Найдены повторные видео" in result.stderr
    with sqlite3.connect(database) as db:
        assert "revision" not in {row[1] for row in db.execute("PRAGMA table_info(rallies)")}
        assert db.execute("SELECT count(*) FROM videos").fetchone()[0] == 2
        assert db.execute("SELECT version_num FROM alembic_version").fetchone()[0] == "fe256e772f1e"


def test_lifespan_exception_still_stops_worker(monkeypatch):
    import asyncio
    from volleyvision import main

    calls = []
    monkeypatch.setattr(main.jobs, "start", lambda: calls.append("start"))
    monkeypatch.setattr(main.jobs, "stop", lambda: calls.append("stop"))

    async def interrupted_session():
        with pytest.raises(RuntimeError, match="interrupted lifespan"):
            async with main.lifespan(main.app):
                raise RuntimeError("interrupted lifespan")

    asyncio.run(interrupted_session())
    assert calls == ["start", "stop"]
