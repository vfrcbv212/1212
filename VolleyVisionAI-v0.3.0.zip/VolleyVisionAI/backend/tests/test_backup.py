import importlib.util
import json
import sqlite3
import subprocess
import zipfile

import pytest

from volleyvision.db import DATA, ROOT

spec = importlib.util.spec_from_file_location("backup_script", ROOT / "scripts" / "backup.py")
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


def test_backup_restores_database_code_history_and_media(tmp_path, client, match):
    archive = module.backup(tmp_path / "project.zip", include_videos=True, data=DATA)
    dest = module.restore(archive, tmp_path / "restored")
    assert (dest / "README.md").is_file()
    assert (dest / "data" / "originals").is_dir()
    assert len(list((dest / "data" / "originals").iterdir())) >= 1
    with sqlite3.connect(dest / "data" / "volleyvision.db") as db:
        assert db.execute("SELECT count(*) FROM matches").fetchone()[0] == 1
        assert db.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
    assert subprocess.check_output(["git", "-C", str(dest), "rev-parse", "HEAD"]).strip()
    with pytest.raises(ValueError, match="новую"):
        module.restore(archive, dest)


def test_backup_detects_tampering(tmp_path, client):
    archive = module.backup(tmp_path / "good.zip", data=DATA)
    bad = tmp_path / "bad.zip"
    with zipfile.ZipFile(archive) as original, zipfile.ZipFile(bad, "w") as altered:
        for name in original.namelist():
            altered.writestr(name, b"tampered" if name == "code/README.md" else original.read(name))
    with pytest.raises(ValueError, match="Контрольная сумма"):
        module.restore(bad, tmp_path / "dest")
    assert not (tmp_path / "dest").exists()


def test_restore_rejects_path_traversal(tmp_path):
    archive = tmp_path / "unsafe.zip"
    with zipfile.ZipFile(archive, "w") as z:
        z.writestr("manifest.json", json.dumps({"format": 1, "files": {"../escape": "unused"}}))
        z.writestr("../escape", "bad")
    with pytest.raises(ValueError, match="путь"):
        module.restore(archive, tmp_path / "dest")
    assert not (tmp_path / "escape").exists()
