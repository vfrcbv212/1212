"""Regression cases discovered by auditing invalid input and failed persistence paths."""

from types import SimpleNamespace
from uuid import uuid4

import pytest
from sqlalchemy.exc import IntegrityError

from volleyvision import main
from volleyvision.db import DATA, Session
from volleyvision.models import Clip, Video
from test_workflow import event_body, post


@pytest.mark.parametrize("bad_date", ["2026-02-30", "2026-13-01", "2026-00-10", "0000-01-01"])
def test_match_requires_real_calendar_date(client, bad_date):
    a = post(client, "/teams", {"name": "A"})["id"]
    b = post(client, "/teams", {"name": "B"})["id"]
    response = client.post("/api/matches", json={"home_id": a, "away_id": b, "date": bad_date})
    assert response.status_code == 422
    assert client.get("/api/matches").json() == []


@pytest.mark.parametrize("kind", ["reception", "dig", "set"])
@pytest.mark.parametrize("outcome,quality", [("error", 1), ("error", 3), ("continued", 0)])
def test_contradictory_quality_rejected(client, match, kind, outcome, quality):
    response = client.post(
        f"/api/matches/{match.mid}/events", json=event_body(match, kind=kind, outcome=outcome, quality=quality)
    )
    assert response.status_code == 422
    assert client.get(f"/api/matches/{match.mid}/stats").json()["trusted_events"] == 0


@pytest.mark.parametrize("outcome,quality", [(None, 3), ("error", None), ("error", 0), ("continued", 2)])
def test_unknown_or_consistent_quality_allowed(client, match, outcome, quality):
    post(client, f"/matches/{match.mid}/events", event_body(match, kind="reception", outcome=outcome, quality=quality))


def test_rally_overlap_rejected_without_double_counting_and_boundaries_can_touch(client, match):
    detail = client.get(f"/api/matches/{match.mid}").json()
    original = detail["rallies"][0]
    body = {
        k: original[k] for k in ("set_id", "video_id", "start", "end", "serving_team_id", "winner_team_id", "rotation")
    }
    body.update(end=2, revision=original["revision"])
    assert client.put(f"/api/rallies/{match.rally}", json=body).status_code == 200
    body.pop("revision")
    assert client.post(f"/api/matches/{match.mid}/rallies", json=body).status_code == 409
    stats = client.get(f"/api/matches/{match.mid}/stats").json()
    assert stats["sets"][0]["home"] == 1
    second = post(client, f"/matches/{match.mid}/rallies", {**body, "start": 2, "end": 4, "winner_team_id": None})
    response = client.put(
        f"/api/rallies/{second['id']}", json={**body, "start": 1, "end": 4, "revision": second["revision"]}
    )
    assert response.status_code == 409
    final = client.get(f"/api/matches/{match.mid}").json()
    assert len(final["rallies"]) == 2
    assert next(r for r in final["rallies"] if r["id"] == second["id"])["start"] == 2


def test_deleted_proxy_falls_back_to_original_with_range(client, match):
    with Session() as db:
        video = db.get(Video, match.vid)
        video.proxy_path = "derived/does-not-exist.mp4"
        db.commit()
    response = client.get(f"/api/videos/{match.vid}/stream", headers={"Range": "bytes=0-99"})
    assert response.status_code == 206
    assert len(response.content) == 100


def test_missing_clip_returns_actionable_404(client, match):
    with Session() as db:
        clip = Clip(match_id=match.mid, name="Missing", path="exports/not-present/clip.mp4", event_ids=[])
        db.add(clip)
        db.commit()
        cid = clip.id
    response = client.get(f"/api/clips/{cid}/download")
    assert response.status_code == 404
    assert "подборки" in response.json()["detail"]


def test_invalid_video_upload_leaves_no_partial_file(client, match):
    before = set((DATA / "originals").iterdir())
    response = client.post(
        f"/api/matches/{match.mid}/videos", files={"file": ("broken.mp4", b"not a video", "video/mp4")}
    )
    assert response.status_code == 422
    assert set((DATA / "originals").iterdir()) == before
    assert len(client.get(f"/api/matches/{match.mid}").json()["videos"]) == 1


def test_failed_database_registration_removes_unreferenced_video():
    path = DATA / "originals" / f"{uuid4().hex}.mp4"
    path.write_bytes(b"fake already-probed video")
    rolled_back = []

    def fail():
        raise IntegrityError("insert", {}, RuntimeError("disk full"))

    db = SimpleNamespace(
        scalar=lambda _: None, add=lambda _: None, commit=fail, rollback=lambda: rolled_back.append(True)
    )
    metadata = {"duration": 4, "width": 320, "height": 180, "fps": 30, "codec": "h264"}
    with pytest.raises(IntegrityError):
        main.register_video(db, 1, "test.mp4", (path, "a" * 64, 23, metadata))
    assert rolled_back == [True]
    assert not path.exists()


@pytest.mark.parametrize("fmt", ["json", "xlsx"])
def test_export_keeps_events_and_statistics_on_one_snapshot_during_correction(client, match, monkeypatch, fmt):
    import io
    from openpyxl import load_workbook
    from volleyvision.models import Event

    event = post(client, f"/matches/{match.mid}/events", event_body(match))
    original_detail = main.match_detail
    changed = []

    def interleaved_detail(mid, db):
        detail = original_detail(mid, db)
        # WAL permits a real concurrent writer while the read snapshot remains open.
        with Session() as writer:
            record = writer.get(Event, event["id"])
            record.outcome = "error"
            record.revision += 1
            writer.commit()
            changed.append(True)
        return detail

    monkeypatch.setattr(main, "match_detail", interleaved_detail)
    response = client.get(f"/api/matches/{match.mid}/export/{fmt}")
    assert response.status_code == 200
    assert changed == [True]
    if fmt == "json":
        payload = response.json()
        assert payload["match"]["events"][0]["outcome"] == "kill"
        assert payload["statistics"]["teams"][str(match.a)]["attack"]["efficiency"] == 100
    else:
        workbook = load_workbook(io.BytesIO(response.content), data_only=True)
        rows = list(workbook["События"].values)
        assert rows[1][list(rows[0]).index("outcome")] == "kill"
        attack_row = next(
            row
            for row in workbook["Статистика"].values
            if row[0] == str(match.a) and row[1] == "team" and row[2] == "attack"
        )
        assert attack_row[-1] == 100
    # The write really committed: a later request sees the new outcome.
    assert client.get(f"/api/matches/{match.mid}/stats").json()["teams"][str(match.a)]["attack"]["efficiency"] == -100
