"""Actual short syntheticcodec/metadata tests; these are NOT iPhone recordings."""

import hashlib
import subprocess
from types import SimpleNamespace

from volleyvision.db import DATA
from volleyvision.media import export_clip, make_proxy, probe


def ffmpeg(*args):
    return subprocess.run(
        ["ffmpeg", "-nostdin", "-y", "-v", "error", *map(str, args)], check=True, capture_output=True, timeout=90
    )


def test_hevc_4k60_hdr_original_untouched_proxy_sdr_and_clip():
    source = DATA / "originals" / "SYNTHETIC-4k60-hdr.mov"
    ffmpeg(
        "-f",
        "lavfi",
        "-i",
        "color=c=gray:size=3840x2160:rate=60",
        "-t",
        "0.2",
        "-c:v",
        "libx265",
        "-preset",
        "ultrafast",
        "-x265-params",
        "pools=1:frame-threads=1:log-level=error:colorprim=bt2020:transfer=smpte2084:colormatrix=bt2020nc",
        "-threads",
        "2",
        "-pix_fmt",
        "yuv420p10le",
        "-color_primaries",
        "bt2020",
        "-color_trc",
        "smpte2084",
        "-colorspace",
        "bt2020nc",
        source,
    )
    before = hashlib.sha256(source.read_bytes()).hexdigest()
    metadata = probe(source)
    assert (metadata["width"], metadata["height"], metadata["fps"], metadata["codec"]) == (3840, 2160, 60, "hevc")
    assert metadata["metadata_json"]["hdr"] is True
    assert metadata["metadata_json"]["pixel_format"] == "yuv420p10le"
    video = SimpleNamespace(
        id=987654,
        path=str(source.relative_to(DATA)),
        duration=metadata["duration"],
        metadata_json=metadata["metadata_json"],
    )
    proxy = make_proxy(video)
    proxymeta = probe(DATA / proxy)
    assert proxymeta["codec"] == "h264"
    assert proxymeta["metadata_json"]["pixel_format"] == "yuv420p"
    assert proxymeta["metadata_json"]["color_transfer"] == "bt709"
    assert proxymeta["metadata_json"]["hdr"] is False
    assert proxymeta["duration"] >= 0.18
    clip = export_clip([SimpleNamespace(time=0.1, video_id=video.id)], {video.id: video}, 0.1, 0.1)
    assert probe(DATA / clip)["metadata_json"]["hdr"] is False
    assert hashlib.sha256(source.read_bytes()).hexdigest() == before


def test_rotation_metadata_and_real_frame_jpeg(client, match, video_file):
    from volleyvision.db import Session
    from volleyvision.models import Video

    source = DATA / "originals" / "SYNTHETIC-rotated.mp4"
    ffmpeg("-display_rotation", "90", "-i", video_file, "-c", "copy", source)
    metadata = probe(source)
    assert abs(metadata["metadata_json"]["rotation_degrees"]) == 90
    with Session() as db:
        video = db.get(Video, match.vid)
        video.path = str(source.relative_to(DATA))
        video.metadata_json = metadata["metadata_json"]
        db.commit()
    response = client.get(f"/api/videos/{match.vid}/frame?time=1")
    assert response.status_code == 200
    jpeg = DATA / "derived" / "SYNTHETIC-rotation-frame.jpg"
    jpeg.write_bytes(response.content)
    dims = probe_jpeg_dimensions(jpeg)
    assert dims == (180, 320)


def probe_jpeg_dimensions(path):
    import json

    result = subprocess.run(
        [
            "ffprobe",
            "-v",
            "error",
            "-select_streams",
            "v:0",
            "-show_entries",
            "stream=width,height",
            "-of",
            "json",
            str(path),
        ],
        check=True,
        capture_output=True,
        text=True,
    )
    stream = json.loads(result.stdout)["streams"][0]
    return stream["width"], stream["height"]


def test_variable_frame_rate_hint_does_not_claim_fixed_timing(video_file):
    source = DATA / "originals" / "SYNTHETIC-vfr.mp4"
    ffmpeg(
        "-i",
        video_file,
        "-vf",
        "setpts=if(lt(N\\,30)\\,N/30/TB\\,(N-30)/15/TB+1/TB)",
        "-fps_mode",
        "vfr",
        "-c:v",
        "libx264",
        "-threads",
        "2",
        source,
    )
    metadata = probe(source)
    assert metadata["metadata_json"]["variable_frame_rate_suspected"] is True
    assert metadata["metadata_json"]["avg_frame_rate"] != metadata["metadata_json"]["nominal_frame_rate"]
    assert metadata["metadata_json"]["original_unchanged"] is True


def test_legacy_video_reprobes_hdr_instead_of_treating_unknown_as_sdr(monkeypatch):
    from volleyvision import media

    seen = []
    monkeypatch.setattr(media, "probe", lambda path, cancel=None: seen.append(path) or {"metadata_json": {"hdr": True}})
    legacy = SimpleNamespace(path="originals/legacy.mov", metadata_json={})
    assert "tonemap=" in media.display_filter(legacy, "scale=320:-2")
    assert seen == [DATA / "originals/legacy.mov"]
