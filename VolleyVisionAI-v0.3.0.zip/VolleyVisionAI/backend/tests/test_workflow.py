import io
import subprocess
import time
from types import SimpleNamespace

import pytest
from openpyxl import load_workbook

from volleyvision.db import Session
from volleyvision.models import Event, Job
from volleyvision.stats import summarize


@pytest.fixture
def video_file(tmp_path):
    path = tmp_path / "synthetic.mp4"
    subprocess.run(
        [
            "ffmpeg",
            "-nostdin",
            "-v",
            "error",
            "-f",
            "lavfi",
            "-i",
            "testsrc2=size=320x180:rate=30",
            "-t",
            "4",
            "-c:v",
            "libx264",
            "-threads",
            "2",
            str(path),
        ],
        check=True,
    )
    return path


def post(client, path, body):
    r = client.post("/api" + path, json=body)
    assert r.status_code == 201, r.text
    return r.json()


@pytest.fixture
def match(client, video_file):
    a, b = [post(client, "/teams", {"name": name})["id"] for name in ["Тест А", "Тест Б"]]
    p = post(client, "/players", {"name": "Игрок А1", "team_id": a, "number": "7"})["id"]
    p2 = post(client, "/players", {"name": "Игрок А2", "team_id": a, "number": "8"})["id"]
    other = post(client, "/players", {"name": "Игрок Б1", "team_id": b, "number": "7"})["id"]
    m = post(client, "/matches", {"home_id": a, "away_id": b, "date": "2026-11-15"})["id"]
    r = client.post(f"/api/matches/{m}/videos", files={"file": ("synthetic.mp4", video_file.read_bytes(), "video/mp4")})
    assert r.status_code == 201, r.text
    v = r.json()["id"]
    detail = client.get(f"/api/matches/{m}").json()
    rally = post(
        client,
        f"/matches/{m}/rallies",
        {
            "set_id": detail["sets"][0]["id"],
            "video_id": v,
            "start": 0,
            "end": 4,
            "serving_team_id": a,
            "winner_team_id": a,
        },
    )
    return SimpleNamespace(mid=m, a=a, b=b, p=p, p2=p2, other=other, vid=v, rally=rally["id"])


def event_body(m, **kwargs):
    return {
        "rally_id": m.rally,
        "time": 1.5,
        "kind": "attack",
        "team_id": m.a,
        "player_id": m.p,
        "outcome": "kill",
        **kwargs,
    }


def test_roundtrip_correction_and_player_isolation(client, match):
    m = match
    e = post(client, f"/matches/{m.mid}/events", event_body(m))
    post(client, f"/matches/{m.mid}/events", event_body(m, player_id=m.p2, outcome="error"))
    stats = client.get(f"/api/matches/{m.mid}/stats").json()
    assert stats["teams"][str(m.a)]["attack"]["efficiency"] == 0
    assert stats["teams"][str(m.a)]["players"][str(m.p)]["attack"]["efficiency"] == 100
    assert stats["teams"][str(m.a)]["players"][str(m.p2)]["attack"]["efficiency"] == -100
    assert stats["sets"][0]["home"] == 1  # Not one point per event.
    body = event_body(m, outcome="blocked", revision=e["revision"])
    r = client.put(f"/api/events/{e['id']}", json=body)
    assert r.status_code == 200, r.text
    assert r.json()["status"] == "corrected"
    assert client.get(f"/api/matches/{m.mid}/stats").json()["teams"][str(m.a)]["attack"]["efficiency"] == -100
    assert client.put(f"/api/events/{e['id']}", json=body).status_code == 409
    history = client.get(f"/api/events/{e['id']}/history").json()
    assert history[0]["before"]["outcome"] == "kill"
    assert history[0]["after"]["outcome"] == "blocked"
    assert client.delete(f"/api/events/{e['id']}?revision=2").status_code == 200
    assert client.get(f"/api/matches/{m.mid}/stats").json()["trusted_events"] == 1


@pytest.mark.parametrize(
    "override",
    [
        {"player_id": "opponent"},
        {"time": 4.1},
        {"outcome": "ace"},
        {"quality": 4},
        {"zone_to": 7},
        {"confidence": 0.99},
        {"time": -1},
    ],
)
def test_reject_invalid_events(client, match, override):
    override = dict(override)
    if override.get("player_id") == "opponent":
        override["player_id"] = match.other
    r = client.post(f"/api/matches/{match.mid}/events", json=event_body(match, **override))
    assert r.status_code == 422, r.text


def test_unreviewed_predictions_excluded(client, match):
    m = match
    with Session() as db:
        db.add(Event(match_id=m.mid, video_id=m.vid, **event_body(m), status="review", source="ai", confidence=0.5))
        db.commit()
    s = client.get(f"/api/matches/{m.mid}/stats").json()
    assert s["trusted_events"] == 0
    assert s["pending_events"] == 1


def test_unknown_outcomes_and_quality(client, match):
    m = match
    post(client, f"/matches/{m.mid}/events", event_body(m, outcome=None, player_id=None))
    post(client, f"/matches/{m.mid}/events", event_body(m, kind="reception", outcome="continued", quality=3))
    s = client.get(f"/api/matches/{m.mid}/stats").json()["teams"][str(m.a)]
    assert s["attack"]["efficiency"] is None
    assert s["attack"]["unknown_outcomes"] == 1
    assert s["players"]["unknown"]["attack"]["attempts"] == 1
    assert s["reception"]["positive_pct"] == 100
    assert s["reception"]["average"] == 3
    assert s["sideout"]["pct"] is None
    assert s["breakpoint"]["pct"] == 100


def test_media_duplicate_range_proxy_clip_and_exports(client, match, video_file):
    m = match
    duplicate = client.post(
        f"/api/matches/{m.mid}/videos", files={"file": ("same.mp4", video_file.read_bytes(), "video/mp4")}
    )
    assert duplicate.status_code == 409
    response = client.get(f"/api/videos/{m.vid}/stream", headers={"Range": "bytes=0-99"})
    assert response.status_code == 206
    assert len(response.content) == 100
    e = post(client, f"/matches/{m.mid}/events", event_body(m))
    clip = post(client, f"/matches/{m.mid}/clips", {"event_ids": [e["id"]], "before": 1, "after": 1})
    data = client.get(f"/api/clips/{clip['id']}/download")
    assert data.status_code == 200 and len(data.content) > 1000
    for fmt in ("csv", "json", "xlsx"):
        r = client.get(f"/api/matches/{m.mid}/export/{fmt}")
        assert r.status_code == 200
        if fmt == "xlsx":
            wb = load_workbook(io.BytesIO(r.content))
            assert len(list(wb["События"].rows)) == 2
            assert "Статистика" in wb.sheetnames
        elif fmt == "json":
            assert r.json()["statistics"]["trusted_events"] == 1
        else:
            assert "kill" in r.text
    job = post(client, f"/videos/{m.vid}/proxy", {})
    for _ in range(80):
        status = next(x for x in client.get("/api/jobs").json() if x["id"] == job["id"])
        if status["status"] in ("completed", "failed"):
            break
        time.sleep(0.1)
    assert status["status"] == "completed", status
    assert client.get(f"/api/matches/{m.mid}").json()["videos"][0]["proxy_path"]


def test_rally_edit_rejects_excluded_events(client, match):
    m = match
    post(client, f"/matches/{m.mid}/events", event_body(m))
    detail = client.get(f"/api/matches/{m.mid}").json()
    rally = detail["rallies"][0]
    body = {
        k: rally[k]
        for k in ["set_id", "video_id", "start", "end", "serving_team_id", "winner_team_id", "rotation", "revision"]
    }
    body["end"] = 1
    assert client.put(f"/api/rallies/{m.rally}", json=body).status_code == 422
    body["end"] = 4
    body["winner_team_id"] = m.b
    assert client.put(f"/api/rallies/{m.rally}", json=body).status_code == 200
    assert client.get(f"/api/matches/{m.mid}/stats").json()["sets"][0]["away"] == 1


def test_host_origin_security(client):
    assert client.get("/api/teams", headers={"Host": "attacker.example"}).status_code == 403
    assert (
        client.post("/api/teams", json={"name": "Injected"}, headers={"Origin": "https://attacker.example"}).status_code
        == 403
    )
    assert client.post("/api/yandex/list", json={"public_key": "http://127.0.0.1/private"}).status_code == 422
    assert client.get("/api/teams").json() == []


def test_queue_retry_state(client, match):
    with Session() as db:
        job = Job(video_id=match.vid, kind="proxy", status="failed", error="simulated failure")
        db.add(job)
        db.commit()
        jid = job.id
    r = client.post(f"/api/jobs/{jid}/retry")
    assert r.status_code == 200 and r.json()["status"] == "queued"


def test_formula_distinguishes_kill_rate_efficiency():
    events = [
        SimpleNamespace(kind="attack", outcome=o, quality=None)
        for o in ["kill", "kill", "error", "blocked", "continued"]
    ]
    result = summarize(events)["attack"]
    assert result["win_pct"] == 40
    assert result["efficiency"] == 0
    assert summarize([])["serve"]["win_pct"] is None


def test_atomic_concurrent_revision(client, match):
    from sqlalchemy.orm.exc import StaleDataError

    e = post(client, f"/matches/{match.mid}/events", event_body(match))
    with Session() as first, Session() as second:
        a, b = first.get(Event, e["id"]), second.get(Event, e["id"])
        a.outcome, a.revision = "error", 2
        first.commit()
        b.outcome, b.revision = "blocked", 2
        with pytest.raises(StaleDataError):
            second.commit()
        second.rollback()
    assert client.get(f"/api/matches/{match.mid}/stats").json()["teams"][str(match.a)]["attack"]["outcomes"] == {
        "error": 1
    }


def test_multiple_videos_keep_independent_source_times(client, match, video_file, tmp_path):
    second = tmp_path / "second.mp4"
    subprocess.run(
        [
            "ffmpeg",
            "-nostdin",
            "-v",
            "error",
            "-i",
            str(video_file),
            "-t",
            "2",
            "-vf",
            "hflip",
            "-c:v",
            "libx264",
            "-threads",
            "2",
            str(second),
        ],
        check=True,
    )
    r = client.post(
        f"/api/matches/{match.mid}/videos", files={"file": ("second.mp4", second.read_bytes(), "video/mp4")}
    )
    assert r.status_code == 201, r.text
    v = r.json()
    assert v["id"] != match.vid
    assert v["offset"] is None  # Do not assume continuity between files.
    assert v["duration"] == 2
    detail = client.get(f"/api/matches/{match.mid}").json()
    rally = post(
        client,
        f"/matches/{match.mid}/rallies",
        {"set_id": detail["sets"][0]["id"], "video_id": v["id"], "start": 0, "end": 2},
    )
    event = post(client, f"/matches/{match.mid}/events", event_body(match, rally_id=rally["id"], time=0.5))
    assert event["video_id"] == v["id"]
    assert event["time"] == 0.5
    assert len(client.get(f"/api/matches/{match.mid}").json()["videos"]) == 2
