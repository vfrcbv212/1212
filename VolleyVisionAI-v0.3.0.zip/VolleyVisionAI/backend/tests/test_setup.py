import pytest

from volleyvision.setup import evaluate_calibration


def test_setup_frame_and_revision_preserve_manual_events(client, match):
    frame = client.get(f"/api/videos/{match.vid}/frame?time=1")
    assert frame.status_code == 200 and frame.content.startswith(b"\xff\xd8")
    assert frame.headers["content-type"] == "image/jpeg"
    assert client.get(f"/api/videos/{match.vid}/frame?time=4").status_code == 422
    before = client.get(f"/api/videos/{match.vid}/setup").json()
    assert before["revision"] == 0 and before["cards"] == []
    body = {
        "revision": 0,
        "calibration": {"mode": "image", "frame_time": 1, "visibility_polygon": [[0.1, 0.1], [0.9, 0.1], [0.9, 0.9]]},
        "cards": [
            {
                "player_id": match.p,
                "team_id": match.a,
                "number": "7",
                "confirmed": True,
                "samples": [{"time": 1, "bbox": [0.1, 0.1, 0.3, 0.8]}],
            }
        ],
    }
    saved = client.put(f"/api/videos/{match.vid}/setup", json=body)
    assert saved.status_code == 200, saved.text
    assert saved.json()["revision"] == 1
    assert saved.json()["config_sha256"] != before["config_sha256"]
    assert saved.json()["cards"][0]["confirmed"]
    assert client.put(f"/api/videos/{match.vid}/setup", json=body).status_code == 409
    assert client.get(f"/api/matches/{match.mid}").json()["events"] == []


@pytest.mark.parametrize(
    "card",
    [
        {"confirmed": True, "samples": []},
        {"confirmed": True, "samples": [{"time": 4, "bbox": [0, 0, 1, 1]}]},
        {"confirmed": False, "samples": [{"time": 1, "bbox": [0.7, 0.2, 0.2, 0.9]}]},
        {"confirmed": False, "samples": [{"time": 1, "bbox": [-0.1, 0, 1, 1]}]},
    ],
)
def test_invalid_cards_cannot_confirm_all_observations(client, match, card):
    body = {"revision": 0, "cards": [{"player_id": match.p, "team_id": match.a, **card}]}
    assert client.put(f"/api/videos/{match.vid}/setup", json=body).status_code == 422


def test_card_cannot_mix_match_teams(client, match):
    body = {"revision": 0, "cards": [{"player_id": match.other, "team_id": match.a, "confirmed": False}]}
    assert client.put(f"/api/videos/{match.vid}/setup", json=body).status_code == 422


def test_four_arbitrary_visible_floor_points_fit_without_requiring_outer_corners():
    pytest.importorskip("numpy", reason="Метрическая калибровка требует optional AI/NumPy")
    # Interior service/attack/net intersections, not four outer court corners.
    calibration = {
        "mode": "court",
        "points": [
            {"image": [0.2, 0.2], "court": [3, 2]},
            {"image": [0.8, 0.2], "court": [9, 2]},
            {"image": [0.8, 0.8], "court": [9, 8]},
            {"image": [0.2, 0.8], "court": [3, 8]},
        ],
        "visibility_polygon": [],
        "frame_time": 0,
        "lens": "uncalibrated_ultrawide",
    }
    result = evaluate_calibration(calibration, 1920, 1080)
    assert result["mode"] == "court"
    h = result["homography"]
    x, y = 0.5, 0.5
    scale = h[2][0] * x + h[2][1] * y + h[2][2]
    assert (h[0][0] * x + h[0][1] * y + h[0][2]) / scale == pytest.approx(6)
    assert (h[1][0] * x + h[1][1] * y + h[1][2]) / scale == pytest.approx(5)
    assert result["projection_scope"] == "floor_only"
    assert result["lens_status"] == "uncorrected"
    assert result["independently_validated"] is False


def test_degenerate_or_insufficient_calibration_falls_back_to_image():
    points = [{"image": [x, x], "court": [18 * x, 9 * x]} for x in (0, 0.25, 0.5, 1)]
    c = {"mode": "court", "points": points, "visibility_polygon": [], "frame_time": 0, "lens": "unknown"}
    result = evaluate_calibration(c, 1920, 1080)
    assert result["mode"] == "image" and result["homography"] is None
    result = evaluate_calibration({**c, "points": points[:3]}, 1920, 1080)
    assert result["mode"] == "image"


def test_inconsistent_redundant_points_do_not_claim_metric_accuracy():
    c = {
        "mode": "court",
        "points": [
            {"image": [0.1, 0.1], "court": [0, 0]},
            {"image": [0.9, 0.1], "court": [18, 0]},
            {"image": [0.9, 0.9], "court": [18, 9]},
            {"image": [0.1, 0.9], "court": [0, 9]},
            {"image": [0.2, 0.2], "court": [9, 4.5]},
        ],
        "visibility_polygon": [],
        "frame_time": 0,
        "lens": "unknown",
    }
    assert evaluate_calibration(c, 1920, 1080)["mode"] == "image"


def test_floor_projection_uses_only_uncropped_person_feet_in_visible_mask():
    from volleyvision.setup import project_person_floor

    calibration = {
        "mode": "court",
        "homography": [[18, 0, 0], [0, 9, 0], [0, 0, 1]],
        "visibility_polygon": [[0, 0], [0.75, 0], [0.75, 1], [0, 1]],
    }
    result = project_person_floor([40, 10, 60, 50], 100, 100, calibration)
    assert result["court"] == [9, 4.5] and result["approximate"]
    assert project_person_floor([80, 10, 90, 50], 100, 100, calibration) is None
    assert project_person_floor([40, 10, 60, 100], 100, 100, calibration) is None
    assert project_person_floor([40, 10, 60, 50], 100, 100, {"mode": "image"}) is None
