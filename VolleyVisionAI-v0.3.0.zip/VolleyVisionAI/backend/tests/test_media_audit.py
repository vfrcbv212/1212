"""Media failure/integrity checks; remote responses are fixtures, not claimed live Yandex access."""

import hashlib
import json
import subprocess
from contextlib import contextmanager
from types import SimpleNamespace
from uuid import uuid4

import pytest

from volleyvision import media
from volleyvision.db import DATA


def test_processing_timeout_is_actionable(monkeypatch):
    def timeout(*args, **kwargs):
        raise subprocess.TimeoutExpired(args[0], 1)

    monkeypatch.setattr(media.subprocess, "run", timeout)
    with pytest.raises(ValueError, match="время обработки"):
        media.run(["ffprobe", "source"], timeout=1)


@pytest.mark.parametrize(
    "payload",
    [
        [],
        {},
        {"streams": "bad"},
        {"streams": [{"codec_type": "video", "width": 0, "height": 20}]},
        {
            "streams": [{"codec_type": "video", "width": 20, "height": 20, "codec_name": "h264"}],
            "format": {"duration": "NaN"},
        },
    ],
)
def test_invalid_probe_metadata_rejected(monkeypatch, payload):
    monkeypatch.setattr(media, "run", lambda *args, **kwargs: json.dumps(payload))
    with pytest.raises(ValueError):
        media.probe("source")


def test_cancellation_propagates_to_metadata_probe(monkeypatch):
    cancel = object()
    seen = []

    def run(args, **kwargs):
        seen.append(kwargs["cancel"])
        return json.dumps(
            {
                "streams": [{"codec_type": "video", "width": 2, "height": 2, "codec_name": "h264"}],
                "format": {"duration": "1"},
            }
        )

    monkeypatch.setattr(media, "run", run)
    media.probe("source", cancel=cancel)
    assert seen == [cancel]


@pytest.mark.parametrize(
    "url",
    [
        "https://disk.yandex.ru:444/d/abc",
        "https://secret@disk.yandex.ru/d/abc",
        "https://disk.yandex.ru.evil.test/d/abc",
        "http://disk.yandex.ru/d/abc",
    ],
)
def test_public_url_restricts_destination(url):
    with pytest.raises(ValueError):
        media.validate_yandex(url)


@pytest.mark.parametrize(
    "href",
    [
        "http://downloader.disk.yandex.ru/file",
        "https://127.0.0.1/file",
        "https://token@downloader.disk.yandex.ru/file",
        "https://downloader.disk.yandex.ru:444/file",
        "https://downloader.disk.yandex.ru.evil.test/file",
    ],
)
def test_remote_download_href_revalidated(monkeypatch, href):
    monkeypatch.setattr(
        media, "yandex_info", lambda *args: {"resource": {"name": "video.mp4", "type": "file", "size": 5}}
    )
    monkeypatch.setattr(
        media.httpx,
        "get",
        lambda *args, **kwargs: SimpleNamespace(raise_for_status=lambda: None, json=lambda: {"href": href}),
    )
    monkeypatch.setattr(
        media.httpx, "stream", lambda *args, **kwargs: pytest.fail("unsafe URL must never be requested")
    )
    with pytest.raises(ValueError):
        media.yandex_download("https://disk.yandex.ru/d/public")


def test_yandex_checks_checksum_and_removes_failed_download(monkeypatch):
    path = DATA / "originals" / f"{uuid4().hex}.mp4"
    path.write_bytes(b"video")
    monkeypatch.setattr(
        media,
        "yandex_info",
        lambda *args: {"resource": {"name": "video.mp4", "type": "file", "size": 5, "sha256": "0" * 64}},
    )
    monkeypatch.setattr(
        media.httpx,
        "get",
        lambda *args, **kwargs: SimpleNamespace(
            raise_for_status=lambda: None, json=lambda: {"href": "https://downloader.disk.yandex.ru/file"}
        ),
    )

    @contextmanager
    def download(*args, **kwargs):
        yield SimpleNamespace(raise_for_status=lambda: None, iter_bytes=lambda _: iter([b"video"]))

    monkeypatch.setattr(media.httpx, "stream", download)
    monkeypatch.setattr(media, "store_stream", lambda chunks, name: (path, hashlib.sha256(b"video").hexdigest(), 5, {}))
    with pytest.raises(ValueError, match="Контрольная сумма"):
        media.yandex_download("https://disk.yandex.ru/d/public")
    assert not path.exists()


def test_yandex_accepts_verified_md5_and_sha256(monkeypatch):
    path = DATA / "originals" / f"{uuid4().hex}.mp4"
    path.write_bytes(b"video")
    digest = hashlib.sha256(b"video").hexdigest()
    md5 = hashlib.md5(b"video", usedforsecurity=False).hexdigest()
    monkeypatch.setattr(
        media,
        "yandex_info",
        lambda *args: {"resource": {"name": "video.mp4", "type": "file", "size": 5, "sha256": digest, "md5": md5}},
    )
    monkeypatch.setattr(
        media.httpx,
        "get",
        lambda *args, **kwargs: SimpleNamespace(
            raise_for_status=lambda: None, json=lambda: {"href": "https://downloader.disk.yandex.ru/file"}
        ),
    )

    @contextmanager
    def download(*args, **kwargs):
        yield SimpleNamespace(raise_for_status=lambda: None, iter_bytes=lambda _: iter([b"video"]))

    monkeypatch.setattr(media.httpx, "stream", download)
    monkeypatch.setattr(media, "store_stream", lambda chunks, name: (path, digest, 5, {}))
    try:
        name, stored = media.yandex_download("https://disk.yandex.ru/d/public")
        assert name == "video.mp4" and stored[0].exists()
    finally:
        path.unlink(missing_ok=True)


def test_phone_like_444_odd_frame_video_produces_browser_compatible_proxy_and_clip():
    ident = int(uuid4().hex[:8], 16)
    source = DATA / "originals" / f"{uuid4().hex}.mp4"
    subprocess.run(
        [
            "ffmpeg",
            "-nostdin",
            "-v",
            "error",
            "-f",
            "lavfi",
            "-i",
            "testsrc=size=321x181:rate=10",
            "-t",
            "1",
            "-c:v",
            "libx264",
            "-pix_fmt",
            "yuv444p",
            "-threads",
            "2",
            str(source),
        ],
        check=True,
    )
    video = SimpleNamespace(id=ident, path=str(source.relative_to(DATA)), duration=1)
    proxy = None
    clip = None
    try:
        proxy = DATA / media.make_proxy(video)
        info = json.loads(
            media.run(
                [
                    "ffprobe",
                    "-v",
                    "error",
                    "-select_streams",
                    "v:0",
                    "-show_entries",
                    "stream=pix_fmt,width,height",
                    "-of",
                    "json",
                    str(proxy),
                ]
            )
        )["streams"][0]
        assert info["pix_fmt"] == "yuv420p"
        assert info["width"] % 2 == 0 and info["height"] % 2 == 0
        clip = DATA / media.export_clip([SimpleNamespace(video_id=ident, time=0.5)], {ident: video}, 0.25, 0.25)
        info = json.loads(
            media.run(
                [
                    "ffprobe",
                    "-v",
                    "error",
                    "-select_streams",
                    "v:0",
                    "-show_entries",
                    "stream=pix_fmt",
                    "-of",
                    "json",
                    str(clip),
                ]
            )
        )["streams"][0]
        assert info["pix_fmt"] == "yuv420p"
    finally:
        source.unlink(missing_ok=True)
        if proxy is not None:
            proxy.unlink(missing_ok=True)
        if clip is not None:
            import shutil

            shutil.rmtree(clip.parent)


def test_media_subprocesses_decode_utf8_independently_of_windows_locale(monkeypatch):
    seen = []
    payload = {
        "streams": [
            {"codec_type": "video", "width": 2, "height": 2, "codec_name": "h264", "tags": {"comment": "Матч 🏐"}}
        ],
        "format": {"duration": "1"},
    }

    def execute(*args, **kwargs):
        seen.append(kwargs)
        return SimpleNamespace(stdout=json.dumps(payload, ensure_ascii=False))

    monkeypatch.setattr(media.subprocess, "run", execute)
    assert media.probe("source")["duration"] == 1
    assert seen[0]["encoding"] == "utf-8" and seen[0]["errors"] == "replace"
