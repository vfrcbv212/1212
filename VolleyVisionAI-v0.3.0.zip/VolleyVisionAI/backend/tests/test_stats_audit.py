"""Independent known-answer fixtures; no calls to the engine to construct expected values."""

from types import SimpleNamespace

import pytest

from volleyvision.stats import calculate, summarize


def event(
    ident, *, team=10, player=101, rally=1, kind="attack", outcome="kill", quality=None, status="manual", deleted=False
):
    return SimpleNamespace(
        id=ident,
        kind=kind,
        team_id=team,
        player_id=player,
        rally_id=rally,
        outcome=outcome,
        quality=quality,
        status=status,
        deleted=deleted,
    )


def rally(ident, *, party=1, serving=10, winner=10, status="manual", video=1, start=None, end=None):
    return SimpleNamespace(
        id=ident,
        set_id=party,
        serving_team_id=serving,
        winner_team_id=winner,
        status=status,
        video_id=video,
        start=(ident - 1) * 10 if start is None else start,
        end=ident * 10 if end is None else end,
    )


def match_stats(events, rallies=(), sets=None):
    sets = sets if sets is not None else [SimpleNamespace(id=1, number=1, initial_home=0, initial_away=0)]
    return calculate(events, rallies, SimpleNamespace(home_id=10, away_id=20), sets)


def test_attack_and_serve_known_answers_are_different_metrics():
    attacks = [
        event(i, outcome=outcome)
        for i, outcome in enumerate(
            ["kill", "kill", "kill", "error", "blocked", "continued", "continued", "continued"], 1
        )
    ]
    serves = [
        event(100 + i, kind="serve", outcome=outcome)
        for i, outcome in enumerate(["ace", "ace", "error", "in_play", "in_play"])
    ]
    got = summarize(attacks + serves)
    assert got["attack"]["attempts"] == 8
    assert got["attack"]["wins"] == 3
    assert got["attack"]["errors"] == 1
    assert got["attack"]["losses"] == 2
    assert got["attack"]["win_pct"] == 37.5
    assert got["attack"]["efficiency"] == 12.5  # (3 - 1 - 1) / 8.
    assert got["serve"]["attempts"] == 5
    assert got["serve"]["win_pct"] == 40
    assert got["serve"]["error_pct"] == 20
    assert got["serve"]["efficiency"] == 20  # (2 - 1) / 5.


def test_unknown_and_invalid_outcomes_cannot_improve_full_attempt_percentages():
    got = summarize([event(1), event(2, outcome=None), event(3, outcome="ace")])["attack"]
    assert got["attempts"] == 3
    assert got["known_outcomes"] == 1
    assert got["unknown_outcomes"] == 2
    assert got["invalid_outcomes"] == 1
    assert got["outcome_coverage_pct"] == 33.33
    assert got["win_pct"] is None
    assert got["error_pct"] is None
    assert got["efficiency"] is None
    assert got["known_win_pct"] == 100  # Explicitly restricted to the one known action.
    assert got["known_efficiency"] == 100
    assert "ace" not in got["outcomes"]


@pytest.mark.parametrize("kind", ["reception", "dig", "set"])
def test_quality_distribution_coverage_and_legacy_conflicts(kind):
    events = [
        event(1, kind=kind, outcome="continued", quality=3),
        event(2, kind=kind, outcome="continued", quality=2),
        event(3, kind=kind, outcome="continued", quality=1),
        event(4, kind=kind, outcome="error", quality=0),
        event(5, kind=kind, outcome="continued", quality=None),
        event(6, kind=kind, outcome="error", quality=3),
        event(7, kind=kind, outcome="continued", quality=0),
        event(8, kind=kind, outcome=None, quality=9),
    ]
    got = summarize(events)[kind]
    assert got["attempts"] == 8
    assert got["graded"] == 4
    assert got["unknown_quality"] == 1
    assert got["conflicting_quality"] == 2
    assert got["invalid_quality"] == 1
    assert got["grade_coverage_pct"] == 50
    assert got["quality_counts"] == {"0": 1, "1": 1, "2": 1, "3": 1}
    assert got["average"] == 1.5
    assert got["perfect_pct"] == 25
    assert got["positive_pct"] == 50  # The positive rate includes quality 3.
    assert events[5].quality == 3 and events[6].quality == 0  # No silent data repair.


def test_unknown_outcome_may_have_a_known_grade_without_inference():
    got = summarize([event(1, kind="reception", outcome=None, quality=3)])["reception"]
    assert got["graded"] == 1
    assert got["unknown_outcomes"] == 1
    assert got["outcomes"] == {}
    assert got["perfect_pct"] == 100


def test_two_teams_players_unknown_identity_and_trust_independently():
    events = [
        event(1),
        event(2, player=102, outcome="error"),
        event(3, team=20, player=201, outcome="blocked"),
        event(4, player=None, outcome="continued"),
        event(5, player=101, status="review"),
        event(6, player=102, status="auto"),
        event(7, player=101, deleted=True),
        event(8, team=999, player=101),
    ]
    got = match_stats(events)
    a, b = got["teams"]["10"], got["teams"]["20"]
    assert got["trusted_events"] == 4
    assert got["pending_events"] == 2
    assert got["data_quality"]["foreign_team_event_count"] == 1
    assert a["attack"]["attempts"] == 3
    assert a["attack"]["efficiency"] == 0
    assert a["players"]["101"]["attack"]["efficiency"] == 100
    assert a["players"]["102"]["attack"]["efficiency"] == -100
    assert a["players"]["unknown"]["attack"]["efficiency"] == 0
    assert b["players"]["201"]["attack"]["efficiency"] == -100
    assert "201" not in a["players"] and "101" not in b["players"]
    assert sum(p["events"] for p in a["players"].values()) == a["events"]


def test_score_sideout_and_breakpoint_use_rallies_once_with_explicit_coverage():
    rallies = [
        rally(1),
        rally(2, winner=20),
        rally(3, serving=20),
        rally(4, serving=20, winner=20),
        rally(5, winner=None),
        rally(6, serving=None),
        rally(7, status="review"),
        rally(8, serving=999),
        rally(9, winner=999),
        rally(10, party=2, serving=20, winner=20),
    ]
    parties = [
        SimpleNamespace(id=1, number=1, initial_home=7, initial_away=5),
        SimpleNamespace(id=2, number=2, initial_home=0, initial_away=0),
    ]
    # Multiple terminal descriptions of the same point must not add multiple points.
    events = [
        event(1, rally=1, kind="serve", outcome="ace"),
        event(2, rally=1, team=20, kind="reception", outcome="error", quality=0),
    ]
    got = match_stats(events, rallies, parties)
    assert got["sets"][0]["home"] == 11  # r1/r3/r6/r8; winner known even when server unknown.
    assert got["sets"][0]["away"] == 7  # r2/r4.
    assert got["sets"][0]["observed_rallies"] == 9
    assert got["sets"][0]["decided_rallies"] == 6
    assert got["sets"][0]["pending_rallies"] == 1
    assert got["sets"][0]["unknown_rallies"] == 3  # Missing, unreviewed and invalid winner.
    assert got["sets"][1]["home"] == 0
    assert got["sets"][1]["away"] == 1
    assert got["sets"][0]["complete_match_score"] is False
    a, b = got["teams"]["10"], got["teams"]["20"]
    assert a["breakpoint"]["won"] == 1
    assert a["breakpoint"]["total"] == 2
    assert a["breakpoint"]["pct"] == 50
    assert a["breakpoint"]["observed"] == 4
    assert a["breakpoint"]["unknown_outcomes"] == 2
    assert a["breakpoint"]["outcome_coverage_pct"] == 50
    assert a["sideout"]["won"] == 1
    assert a["sideout"]["total"] == 3
    assert a["sideout"]["pct"] == 33.33
    assert b["sideout"]["won"] == 1 and b["sideout"]["pct"] == 50
    assert b["breakpoint"]["won"] == 2 and b["breakpoint"]["pct"] == 66.67
    assert got["data_quality"]["unknown_serving_rallies"] == 2
    assert got["data_quality"]["invalid_winner_rallies"] == 1
    assert got["data_quality"]["pending_rallies"] == 1


def test_pending_rally_with_predicted_winner_remains_an_unresolved_score():
    got = match_stats([], [rally(1, status="auto"), rally(2, status="review")])
    assert got["sets"][0]["home"] == 0
    assert got["sets"][0]["unknown_rallies"] == 2
    assert got["sets"][0]["pending_rallies"] == 2
    assert got["teams"]["10"]["breakpoint"]["pct"] is None


def test_action_outcome_score_conflicts_are_reported_without_silently_changing_score():
    events = [
        event(1, kind="serve", outcome="ace"),
        event(2, kind="reception", outcome="error", quality=3),
        event(3, team=20, kind="attack", outcome="kill"),
    ]
    got = match_stats(events, [rally(1)])
    assert got["sets"][0]["home"] == 1 and got["sets"][0]["away"] == 0
    assert got["data_quality"]["grade_conflict_count"] == 1
    assert got["data_quality"]["grade_conflict_event_ids"] == [2]
    assert got["data_quality"]["terminal_conflict_count"] == 2
    assert got["data_quality"]["terminal_conflict_event_ids"] == [2, 3]
    assert got["data_quality"]["contradictory_terminal_rally_ids"] == [1]


def test_zero_observations_are_distinct_from_zero_percent():
    got = match_stats([])
    for team in got["teams"].values():
        assert team["attack"]["attempts"] == 0
        assert team["attack"]["win_pct"] is None
        assert team["attack"]["known_efficiency"] is None
        assert team["reception"]["graded"] == 0
        assert team["reception"]["average"] is None
        assert team["reception"]["positive_pct"] is None
        assert team["reception"]["grade_coverage_pct"] is None
        assert team["sideout"]["pct"] is None
        assert team["sideout"]["outcome_coverage_pct"] is None
    observed_loss = summarize([event(1, outcome="error")])["attack"]
    assert observed_loss["win_pct"] == 0
    assert observed_loss["efficiency"] == -100


def test_legacy_overlapping_rallies_flagged_without_silently_changing_observed_score():
    observations = [
        rally(1, start=0, end=10),
        rally(2, start=5, end=15),
        rally(3, start=15, end=20, winner=20),  # Touching is allowed.
        rally(4, video=2, start=0, end=10, winner=20),  # Different source.
        rally(5, start=20, end=30),
        rally(6, start=6, end=7, winner=None),  # Nested interval.
        rally(7, video=2, start=10, end=20, winner=None),
    ]
    got = match_stats([], reversed(observations))  # Independent of query order.
    assert got["data_quality"]["overlapping_rally_ids"] == [1, 2, 6]
    assert got["sets"][0]["home"] == 3
    assert got["sets"][0]["away"] == 2
    assert got["sets"][0]["observed_rallies"] == 7
    assert len(observations) == 7  # No repair or deletion of legacy data.


def test_pending_legacy_overlap_is_a_warning_but_does_not_contribute_to_score():
    got = match_stats([], [rally(1, start=0, end=10), rally(2, start=2, end=4, status="review")])
    assert got["data_quality"]["overlapping_rally_ids"] == [1, 2]
    assert got["sets"][0]["home"] == 1
    assert got["sets"][0]["unknown_rallies"] == 1
    assert got["sets"][0]["pending_rallies"] == 1
