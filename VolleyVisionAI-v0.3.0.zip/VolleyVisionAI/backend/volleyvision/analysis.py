"""Durable local detector jobs, segmented observation cache and honest match reports.

This module never manufactures volleyball actions from COCO detections. Model
observations are stored separately; existing manually scored events remain intact.
"""

import csv
import hashlib
import html
import io
import json
import math
import os
import shutil
import tempfile
import threading
import time
from pathlib import Path
from typing import Literal

from fastapi import APIRouter, Depends, HTTPException, Request, Query
from fastapi.responses import HTMLResponse, JSONResponse, Response
from openpyxl import Workbook
from pydantic import BaseModel, ConfigDict, Field, model_validator
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session as DBSession

from .analysis_models import AnalysisRun
from .db import DATA, Session, session
from .models import Job, Match, Video, Team, Player, now

router = APIRouter(prefix="/api", tags=["local-analysis"])
SCHEMA_VERSION = 2
PROCESSOR_VERSION = "object-observations-v2"
enqueue_lock = threading.Lock()
LIMITATIONS = [
    "Работает локальная детекция людей и объектов класса sports ball. Это не распознавание всех волейбольных действий.",
    "Мяч на любительском видео может быть пропущен или перепутан с другим круглым объектом; точность на вашем матче ещё не измерена.",
    "Личности, номера, касания, подачи, атаки, блок-очки и победители розыгрышей автоматически не устанавливаются этим детектором.",
    "Координаты карты — наблюдения в изображении. Полёт мяча и руки не проецируются в метры на полу.",
    "Карточки игроков сохранены и подтверждены вручную, но этот модуль ещё не выполняет OCR или назначение личности трекам.",
    "Карта ног на полу, когда доступна, является приблизительной проекцией нижней границы рамки человека; дисторсия объектива не исправлена.",
    "Ноль автоматически принятых игровых действий не означает, что матч полностью распознан. Статистика ниже основана на доверенных событиях редактора.",
]


class AnalysisIn(BaseModel):
    model_config = ConfigDict(extra="forbid", allow_inf_nan=False)
    sample_fps: float = Field(default=2, ge=0.25, le=30)
    strategy: Literal["fullframe", "tiles"] = "fullframe"
    device: Literal["auto", "cpu", "cuda"] = "auto"
    model_id: Literal["yolox-tiny", "yolox-small"] = "yolox-tiny"
    segment_seconds: float = Field(default=30, ge=2, le=60)
    start: float = Field(default=0, ge=0)
    end: float | None = Field(default=None, gt=0)

    @model_validator(mode="after")
    def interval(self):
        if self.end is not None and self.end <= self.start:
            raise ValueError("Конец анализа должен быть позже начала")
        return self


def _vision():
    try:
        from . import vision

        return vision
    except ImportError as exc:
        raise ValueError(
            "Модуль AI не установлен. Выполните установку requirements-ai.lock и scripts/install_models.py"
        ) from exc


def _setup(video_id):
    from .setup import get_setup

    return get_setup(video_id)


def _digest(value):
    return hashlib.sha256(
        json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()
    ).hexdigest()


def _get(db, cls, ident):
    value = db.get(cls, ident)
    if value is None:
        raise HTTPException(404, "Запись не найдена")
    return value


def _run_view(db, run):
    job = _get(db, Job, run.job_id)
    return {
        "id": run.id,
        "video_id": run.video_id,
        "match_id": run.match_id,
        "job_id": job.id,
        "fingerprint": run.fingerprint,
        "status": job.status,
        "progress": job.progress,
        "error": job.error,
        "checkpoint": job.checkpoint,
        "summary": run.summary,
        "created_at": run.created_at,
        "updated_at": run.updated_at,
        "config": run.config,
        "setup_sha256": run.config.get("setup", {}).get("config_sha256"),
        "strategy": run.config["params"]["strategy"],
        "sample_fps": run.config["params"]["sample_fps"],
        "device": run.config["params"]["device"],
        "report_url": f"/api/matches/{run.match_id}/report.html?run_id={run.id}",
    }


@router.get("/analysis/runtime")
def analysis_runtime():
    try:
        vision = _vision()
        runtime = vision.get_runtime_info()
        return {
            "installed": bool(vision.get_model_manifest("yolox-tiny").get("installed")),
            **runtime,
            "model": vision.get_model_manifest("yolox-tiny"),
            "event_recognition": False,
            "limitations": LIMITATIONS,
        }
    except (ValueError, RuntimeError) as exc:
        return {"installed": False, "error": str(exc), "event_recognition": False, "limitations": LIMITATIONS}


@router.post("/videos/{vid}/analysis", status_code=201)
def enqueue_analysis(vid: int, body: AnalysisIn, db: DBSession = Depends(session)):
    video = _get(db, Video, vid)
    end = video.duration if body.end is None else body.end
    if not body.start < end <= video.duration + 0.001:
        raise HTTPException(422, "Интервал анализа выходит за границы видео")
    if (end - body.start) * body.sample_fps > 180000:
        raise HTTPException(422, "Слишком много кадров за один запуск: уменьшите частоту анализа или интервал")
    source = (DATA / video.path).resolve()
    if not source.is_relative_to(DATA) or not source.is_file():
        raise HTTPException(404, "Исходное видео отсутствует; восстановите его перед анализом")
    vision = _vision()
    manifest = vision.get_model_manifest(body.model_id)
    model_key = {key: manifest.get(key) for key in ("model_id", "version", "sha256", "input_size")}
    if not model_key.get("sha256"):
        raise HTTPException(503, "Контрольная сумма выбранной модели неизвестна; установка не подтверждена")
    runtime = vision.get_runtime_info(body.model_id, body.device)
    if runtime.get("dependencies_installed") is False:
        raise HTTPException(503, "Установите AI-зависимости: python -m pip install -r requirements-ai.lock")
    if body.device == "cuda" and runtime.get("active_device") != "cuda":
        raise HTTPException(503, "CUDA provider недоступен; выберите CPU или установите совместимый ONNX Runtime CUDA")
    params = {**body.model_dump(), "end": end}
    setup = _setup(vid)
    config = {
        "schema_version": SCHEMA_VERSION,
        "processor_version": PROCESSOR_VERSION,
        "source_sha256": video.sha256,
        "source_size": video.size,
        "video_id": vid,
        "match_id": video.match_id,
        "params": params,
        "setup": setup,
        "model": model_key,
        "execution": {
            "requested_device": body.device,
            "available_provider": runtime.get("provider"),
            "runtime_versions": runtime.get("versions", {}),
        },
    }
    fingerprint = _digest(config)
    with enqueue_lock:
        existing = db.scalar(select(AnalysisRun).where(AnalysisRun.fingerprint == fingerprint))
        if existing:
            job = _get(db, Job, existing.job_id)
            if job.status in {"failed", "interrupted"}:
                if not manifest.get("installed") or not manifest.get("verified"):
                    raise HTTPException(503, "Установите и проверьте веса модели перед возобновлением")
                job.status, job.error = "queued", None
                db.commit()
            return _run_view(db, existing)
        if not manifest.get("installed") or not manifest.get("verified"):
            raise HTTPException(
                503, "Веса модели не установлены или не прошли проверку SHA256. Запустите scripts/install_models.py"
            )
        job = Job(video_id=vid, kind="analysis", checkpoint={"schema_version": SCHEMA_VERSION, "segments_done": []})
        db.add(job)
        db.flush()
        run = AnalysisRun(video_id=vid, match_id=video.match_id, job_id=job.id, fingerprint=fingerprint, config=config)
        db.add(run)
        try:
            db.commit()
        except IntegrityError:
            db.rollback()
            run = db.scalar(select(AnalysisRun).where(AnalysisRun.fingerprint == fingerprint))
            if run is None:
                raise
        return _run_view(db, run)


@router.get("/videos/{vid}/analysis/latest")
def latest_analysis(vid: int, db: DBSession = Depends(session)):
    _get(db, Video, vid)
    run = db.scalar(select(AnalysisRun).where(AnalysisRun.video_id == vid).order_by(AnalysisRun.id.desc()))
    if run is None:
        raise HTTPException(404, "Анализ этого видео ещё не запускался")
    return _run_view(db, run)


@router.get("/analysis/{run_id}")
def get_analysis(run_id: int, db: DBSession = Depends(session)):
    return _run_view(db, _get(db, AnalysisRun, run_id))


def _folder(run):
    return DATA / "analysis" / run.fingerprint


def _write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, name = tempfile.mkstemp(prefix=path.stem, suffix=".tmp", dir=path.parent)
    temporary = Path(name)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8") as out:
            json.dump(value, out, ensure_ascii=False, allow_nan=False)
            out.flush()
            os.fsync(out.fileno())
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def _segment_cache(path, run, index, start, end):
    try:
        envelope = json.loads(path.read_text(encoding="utf-8"))
        payload = envelope["payload"]
        if not isinstance(payload, dict) or not isinstance(payload.get("frames"), list):
            return None
        if (
            envelope.get("schema_version") == run.config.get("schema_version")
            and envelope["fingerprint"] == run.fingerprint
            and envelope["index"] == index
            and envelope["start"] == start
            and envelope["end"] == end
            and envelope["sha256"] == _digest(payload)
        ):
            return payload
    except (OSError, ValueError, KeyError, TypeError):
        pass
    return None


def _source_signature(info):
    return (info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns, info.st_ctime_ns)


def _assert_source_unchanged(source, signature):
    try:
        unchanged = not source.is_symlink() and _source_signature(source.stat()) == signature
    except OSError as exc:
        raise ValueError("Исходное видео исчезло во время анализа; результаты этого запуска не опубликованы") from exc
    if not unchanged:
        raise ValueError(
            "Исходное видео изменилось во время анализа; восстановите исходник или импортируйте новый файл"
        )


def _verify_source(source, expected_sha256, expected_size, cancel_event):
    """Check original bytes before trusting any segment cache, without buffering the file."""
    started = time.monotonic()
    if cancel_event.is_set():
        raise InterruptedError("Проверка исходного видео прервана; контрольные точки сохранены")
    digest = hashlib.sha256()
    size = 0
    try:
        with source.open("rb") as stream:
            signature = _source_signature(os.fstat(stream.fileno()))
            if signature[2] != expected_size:
                raise ValueError("Размер исходного видео изменился; старые сегменты нельзя использовать")
            while True:
                if cancel_event.is_set():
                    raise InterruptedError("Проверка исходного видео прервана; контрольные точки сохранены")
                chunk = stream.read(1024 * 1024)
                if not chunk:
                    break
                digest.update(chunk)
                size += len(chunk)
            if _source_signature(os.fstat(stream.fileno())) != signature:
                raise ValueError("Исходное видео изменилось во время проверки; анализ не запущен")
    except InterruptedError:
        raise
    except OSError as exc:
        raise ValueError("Не удалось прочитать исходное видео; проверьте файл и доступ к диску") from exc
    _assert_source_unchanged(source, signature)
    if size != expected_size or digest.hexdigest() != expected_sha256:
        raise ValueError(
            "SHA256 исходного видео не совпал; восстановите исходник или импортируйте изменённый файл заново"
        )
    return signature, {
        "sha256": digest.hexdigest(),
        "bytes": size,
        "seconds": round(time.monotonic() - started, 6),
        "method": "streamed_sha256_before_cache_reuse",
    }


def _scope_segment(payload, run, index):
    """A local tracker ID is never a player ID or a cross-segment identity."""
    scope = f"run:{run.fingerprint}:segment:{index}"
    for frame in payload["frames"]:
        frame["segment_index"] = index
        frame["track_scope"] = scope
        for detection in frame.get("detections", []):
            detection["segment_index"] = index
            if detection.get("track_id") is not None:
                detection["track_uid"] = f"{scope}:track:{detection['track_id']}"
    return payload


def _progress(job_id, progress, checkpoint=None):
    with Session() as db:
        job = _get(db, Job, job_id)
        job.progress = min(1, max(0, progress))
        if checkpoint is not None:
            job.checkpoint = checkpoint
        db.commit()


def process_analysis(job_id, cancel_event):
    """Run bounded original-video segments; committed files can be reused after restart."""
    job_started = time.monotonic()
    with Session() as db:
        run = db.scalar(select(AnalysisRun).where(AnalysisRun.job_id == job_id))
        if run is None:
            raise ValueError("Для задачи отсутствует конфигурация анализа")
        video = _get(db, Video, run.video_id)
        db.expunge(run)
        db.expunge(video)
    params = run.config["params"]
    if run.config.get("schema_version") != SCHEMA_VERSION or run.config.get("processor_version") != PROCESSOR_VERSION:
        raise ValueError("Версия конвейера изменилась; запустите новый анализ, чтобы не смешивать контрольные точки")
    vision = _vision()
    current_model = vision.get_model_manifest(params["model_id"])
    if not current_model.get("verified") or current_model.get("sha256") != run.config["model"]["sha256"]:
        raise ValueError("Вес модели изменился или не проверен; старый запуск не будет смешан с другой версией")
    current_runtime = vision.get_runtime_info(params["model_id"], params["device"])
    expected_provider = run.config.get("execution", {}).get("available_provider")
    if expected_provider is not None and current_runtime.get("provider") != expected_provider:
        raise ValueError("Исполнитель модели изменился; создайте новый запуск, чтобы не смешивать CPU/GPU сегменты")
    if current_runtime.get("versions", {}) != run.config.get("execution", {}).get("runtime_versions", {}):
        raise ValueError("Версии библиотек исполнителя изменились; создайте новый запуск")
    source = (DATA / video.path).resolve()
    if not source.is_relative_to(DATA) or not source.is_file():
        raise ValueError("Исходное видео не найдено")
    source_signature, verification = _verify_source(
        source, run.config["source_sha256"], run.config["source_size"], cancel_event
    )
    start, end, size = params["start"], params["end"], params["segment_seconds"]
    total = max(1, math.ceil((end - start) / size))
    completed, summaries, detector = [], [], None
    reused_segments = []
    actual_provider = None
    folder = _folder(run)
    folder.mkdir(parents=True, exist_ok=True)
    for index in range(total):
        if cancel_event.is_set():
            raise InterruptedError("Анализ прерван; завершённые сегменты сохранены для возобновления")
        _assert_source_unchanged(source, source_signature)
        left, right = start + index * size, min(end, start + (index + 1) * size)
        cache = folder / f"segment-{index:06d}.json"
        payload = _segment_cache(cache, run, index, left, right)
        if payload is not None:
            reused_segments.append(index)
        if payload is None:
            if shutil.disk_usage(DATA).free < 256 * 1024**2:
                raise ValueError("Недостаточно места для наблюдений; освободите диск и возобновите задачу")
            if detector is None:
                detector = vision.YoloXDetector(
                    model_id=params["model_id"], device=params["device"], strategy=params["strategy"]
                )
            loaded_provider = getattr(detector, "runtime", {}).get("provider")
            if actual_provider is not None and loaded_provider is not None and loaded_provider != actual_provider:
                raise ValueError("Фактический исполнитель изменился; выберите CPU/CUDA явно и создайте новый запуск")
            last_saved = [0.0]

            def on_progress(value):
                current = time.monotonic()
                if current - last_saved[0] > 1:
                    if cancel_event.is_set():
                        raise InterruptedError("Анализ прерван")
                    _progress(job_id, (index + float(value)) / total)
                    last_saved[0] = current

            payload = vision.scan_segment(
                str(source),
                left,
                right,
                sample_fps=params["sample_fps"],
                strategy=params["strategy"],
                device=params["device"],
                cancel_event=cancel_event,
                progress=on_progress,
                detector=detector,
                model_id=params["model_id"],
            )
            # Segment intervals are half-open. A frame exactly at the boundary is
            # owned by the next segment; observations are never counted twice.
            payload["frames"] = [f for f in payload.get("frames", []) if left <= float(f["time"]) < right]
            _assert_source_unchanged(source, source_signature)
            _scope_segment(payload, run, index)
            segment_provider = payload.get("runtime", {}).get("provider")
            if actual_provider is not None and segment_provider != actual_provider:
                raise ValueError("Фактические CPU/GPU результаты нельзя смешивать в одном запуске")
            envelope = {
                "schema_version": SCHEMA_VERSION,
                "fingerprint": run.fingerprint,
                "index": index,
                "start": left,
                "end": right,
                "payload": payload,
                "sha256": _digest(payload),
            }
            _write_json(cache, envelope)
        segment_provider = payload.get("runtime", {}).get("provider")
        if actual_provider is not None and segment_provider != actual_provider:
            raise ValueError("В контрольных точках различаются фактические CPU/GPU исполнители; создайте новый запуск")
        actual_provider = segment_provider
        completed.append(index)
        summaries.append(_summarize_segment(payload))
        _progress(
            job_id,
            (index + 1) / total,
            {
                "schema_version": SCHEMA_VERSION,
                "fingerprint": run.fingerprint,
                "segments_done": list(completed),
                "total_segments": total,
            },
        )
    _assert_source_unchanged(source, source_signature)
    if cancel_event.is_set():
        raise InterruptedError("Анализ прерван; завершённые сегменты сохранены для возобновления")
    result = _combine_summary(summaries)
    result.update(
        {
            "start": start,
            "end": end,
            "elapsed_this_attempt_seconds": round(time.monotonic() - job_started, 3),
            "timing_scope": "attempt_including_source_verification_before_final_summary_write",
            "accepted_events": 0,
            "source_verification": verification,
            "reused_segments": reused_segments,
            "recomputed_segments": [i for i in range(total) if i not in reused_segments],
            "model_loaded_this_attempt": detector is not None,
            "inference_seconds_this_attempt": sum(
                s["runtime"].get("inference_seconds", 0) for i, s in enumerate(summaries) if i not in reused_segments
            ),
            "decode_seconds_this_attempt": sum(
                s["runtime"].get("decode_seconds", 0) for i, s in enumerate(summaries) if i not in reused_segments
            ),
            "model_load_seconds": (getattr(detector, "runtime", {}).get("load_seconds") if detector is not None else 0),
            "event_recognition_status": "not_implemented",
            "scope": "object_observations_only",
            "limitations": LIMITATIONS,
        }
    )
    _write_json(folder / "summary.json", result)
    with Session() as db:
        saved = _get(db, AnalysisRun, run.id)
        saved.summary, saved.updated_at = result, now()
        db.commit()
    return result


@router.get("/analysis/{run_id}/observations")
def get_observations(
    run_id: int,
    offset: int = Query(default=0, ge=0),
    limit: int = Query(default=500, ge=1, le=1000),
    db: DBSession = Depends(session),
):
    """Bounded export of exact verified detector frames; these are not accepted actions."""
    run = _get(db, AnalysisRun, run_id)
    video = _get(db, Video, run.video_id)
    params = run.config["params"]
    segments = max(1, math.ceil((params["end"] - params["start"]) / params["segment_seconds"]))
    selected, total, missing = [], 0, []
    for index in range(segments):
        left = params["start"] + index * params["segment_seconds"]
        right = min(params["end"], left + params["segment_seconds"])
        payload = _segment_cache(_folder(run) / f"segment-{index:06d}.json", run, index, left, right)
        if payload is None:
            missing.append(index)
            continue
        _scope_segment(payload, run, index)
        for frame in payload["frames"]:
            if offset <= total < offset + limit:
                selected.append({**frame, "video_id": video.id})
            total += 1
    return {
        "schema_version": run.config["schema_version"],
        "run_id": run.id,
        "fingerprint": run.fingerprint,
        "video_id": video.id,
        "source_sha256": run.config["source_sha256"],
        "model": run.config["model"],
        "coordinate_system": "video_pixels",
        "actions_inferred": False,
        "offset": offset,
        "limit": limit,
        "total_frames": total,
        "next_offset": offset + len(selected) if offset + len(selected) < total else None,
        "missing_or_invalid_segments": missing,
        "frames": selected,
    }


def _summarize_segment(payload):
    frames = payload.get("frames", [])
    people, balls, first, last = 0, 0, None, None
    for frame in frames:
        first = frame["time"] if first is None else min(first, frame["time"])
        last = frame["time"] if last is None else max(last, frame["time"])
        for detection in frame.get("detections", []):
            people += detection.get("class_name") == "person"
            balls += detection.get("class_name") == "sports ball"
    return {
        "sampled_frames": len(frames),
        "person_observations": people,
        "ball_observations": balls,
        "first_timestamp": first,
        "last_timestamp": last,
        "runtime": payload.get("runtime", {}),
    }


def _combine_summary(segments):
    result = {
        key: sum(s[key] for s in segments) for key in ("sampled_frames", "person_observations", "ball_observations")
    }
    result["segments"] = len(segments)
    result["runtimes"] = [s["runtime"] for s in segments]
    elapsed = sum(s["runtime"].get("elapsed_seconds", 0) for s in segments)
    result["original_processing_seconds"] = elapsed
    result["metrics_scope"] = "original_segment_measurements_including_reused"
    result["inference_seconds"] = sum(s["runtime"].get("inference_seconds", 0) for s in segments)
    result["decode_seconds"] = sum(s["runtime"].get("decode_seconds", 0) for s in segments)
    result["sampled_processing_fps"] = round(result["sampled_frames"] / elapsed, 3) if elapsed else None
    result["active_providers"] = sorted({s["runtime"].get("provider", "unknown") for s in segments})
    return result


def _observations(run, video):
    timeline, feet, balls, floor_feet = [], [], [], []
    if run is None:
        return timeline, feet, balls, floor_feet
    from .setup import project_person_floor

    calibration = run.config.get("setup", {}).get("calibration", {})
    params = run.config["params"]
    total = max(1, math.ceil((params["end"] - params["start"]) / params["segment_seconds"]))
    for index in range(total):
        left = params["start"] + index * params["segment_seconds"]
        right = min(params["end"], left + params["segment_seconds"])
        payload = _segment_cache(_folder(run) / f"segment-{index:06d}.json", run, index, left, right)
        if payload is None:
            continue
        for frame in payload.get("frames", []):
            people_count = ball_count = 0
            for detection in frame.get("detections", []):
                bbox = detection.get("bbox", [])
                if len(bbox) != 4:
                    continue
                x1, y1, x2, y2 = bbox
                if detection.get("class_name") == "person":
                    people_count += 1
                    if len(feet) < 20000:
                        feet.append(
                            [
                                round((x1 + x2) / 2 / (frame.get("width") or video.width), 5),
                                round(y2 / (frame.get("height") or video.height), 5),
                            ]
                        )
                    projection = project_person_floor(
                        bbox, frame.get("width") or video.width, frame.get("height") or video.height, calibration
                    )
                    if projection is not None and len(floor_feet) < 20000:
                        floor_feet.append(
                            {**projection, "time": frame["time"], "video_id": video.id, "segment_index": index}
                        )
                elif detection.get("class_name") == "sports ball":
                    ball_count += 1
                    if len(balls) < 20000:
                        balls.append(
                            [
                                round((x1 + x2) / 2 / (frame.get("width") or video.width), 5),
                                round((y1 + y2) / 2 / (frame.get("height") or video.height), 5),
                            ]
                        )
            timeline.append(
                {
                    "time": frame["time"],
                    "video_id": video.id,
                    "people": people_count,
                    "balls": ball_count,
                    "segment_index": index,
                    "track_scope": frame.get("track_scope"),
                }
            )
    return timeline, feet, balls, floor_feet


@router.get("/matches/{mid}/report")
def match_report(mid: int, run_id: int | None = None, db: DBSession = Depends(session)):
    from .main import begin_read_snapshot, match_detail, match_stats

    begin_read_snapshot(db)
    match = _get(db, Match, mid)
    run = (
        db.get(AnalysisRun, run_id)
        if run_id is not None
        else db.scalar(select(AnalysisRun).where(AnalysisRun.match_id == mid).order_by(AnalysisRun.id.desc()))
    )
    if run_id is not None and (run is None or run.match_id != mid):
        raise HTTPException(404, "Этот запуск не относится к матчу")
    detail, statistics = match_detail(mid, db), match_stats(db, mid)
    events = detail["events"]
    teams = [{"id": tid, "name": _get(db, Team, tid).name} for tid in (match.home_id, match.away_id)]
    players = [{**roster, "name": _get(db, Player, roster["player_id"]).name} for roster in detail["roster"]]
    if run:
        video = _get(db, Video, run.video_id)
        timeline, feet, balls, floor_feet = _observations(run, video)
        source = {
            key: getattr(video, key) for key in ("id", "name", "duration", "width", "height", "fps", "metadata_json")
        }
        run_view = _run_view(db, run)
        coverage = {
            "start": run.config["params"]["start"],
            "end": run.config["params"]["end"],
            "sampled_frames": len(timeline),
            "person_observations": sum(f["people"] for f in timeline),
            "ball_observations": sum(f["balls"] for f in timeline),
            "accepted_events": 0,
        }
    else:
        timeline, feet, balls, floor_feet, source, run_view = [], [], [], [], None, None
        coverage = {"accepted_events": 0, "sampled_frames": 0}
    version_key = _digest(
        {
            "events": events,
            "teams": teams,
            "players": players,
            "rallies": detail["rallies"],
            "statistics": statistics,
            "source": source,
            "run": run.fingerprint if run else None,
            "run_summary": run.summary if run else {},
            "run_status": run_view["status"] if run_view else None,
            "timeline": timeline,
            "person_footpoints": feet,
            "ball_centers": balls,
            "floor_person_feet": floor_feet,
        }
    )
    return {
        "schema_version": SCHEMA_VERSION,
        "match_id": match.id,
        "teams": teams,
        "players": players,
        "data_version": version_key,
        "run": run_view,
        "source": source,
        "coverage": coverage,
        "statistics": statistics,
        "events": events,
        "timeline": timeline,
        "maps": {
            "coordinate_system": "normalized_image",
            "person_footpoints": feet,
            "ball_centers": balls,
            "floor_person_feet": floor_feet,
            "floor_projection": {
                "coordinate_system": "court_metres",
                "approximate": True,
                "source": "person_bbox_bottom",
                "scope": "floor_assumption_only",
                "lens_status": "uncorrected",
                "reason": "Нужны достаточные опорные точки и область наблюдения; мяч и обрезанные ноги не проецируются",
            },
            "truncated_at_points": 20000,
        },
        "metrics": run.summary if run else {},
        "limitations": [
            *LIMITATIONS,
            *(
                [
                    "HDR-вход: преобразование цветов OpenCV для детекции не проверено на настоящей записи iPhone; SDR-прокси не подтверждает точность модели на HDR."
                ]
                if source and source.get("metadata_json", {}).get("hdr")
                else []
            ),
        ],
    }


def _safe_cell(value):
    return "'" + value if isinstance(value, str) and value[:1] in {"=", "+", "-", "@"} else value


@router.get("/matches/{mid}/report/export/{fmt}")
def report_export(
    mid: int,
    fmt: Literal["json", "csv", "xlsx"],
    data_version: str = Query(min_length=64, max_length=64, pattern=r"^[0-9a-f]{64}$"),
    run_id: int | None = None,
    db: DBSession = Depends(session),
):
    """Export the viewed report version, never silently a newer manual snapshot."""
    report = match_report(mid, run_id, db)
    if report["data_version"] != data_version:
        raise HTTPException(409, "Данные изменились после открытия отчёта. Обновите отчёт перед скачиванием.")
    headers = {
        "Content-Disposition": f'attachment; filename="report-{mid}-{data_version[:12]}.{fmt}"',
        "ETag": f'"{data_version}"',
        "Cache-Control": "no-store",
    }
    if fmt == "json":
        return JSONResponse(report, headers=headers)
    fields = [
        "id",
        "video_id",
        "rally_id",
        "time",
        "kind",
        "team_id",
        "player_id",
        "outcome",
        "quality",
        "status",
        "source",
        "revision",
    ]
    rows = [[_safe_cell(e.get(key)) for key in fields] for e in report["events"]]
    if fmt == "csv":
        output = io.StringIO(newline="")
        writer = csv.writer(output)
        writer.writerow(["data_version", *fields])
        writer.writerows([[data_version, *row] for row in rows])
        return Response(("\ufeff" + output.getvalue()).encode("utf-8"), media_type="text/csv", headers=headers)
    workbook = Workbook()
    sheet = workbook.active
    sheet.title = "События"
    sheet.append(["data_version", *fields])
    for row in rows:
        sheet.append([data_version, *row])
    sheet = workbook.create_sheet("Статистика")
    sheet.append(
        ["Команда ID", "Игрок ID", "Действие", "Попытки", "Неизвестные исходы", "% выигрыша", "Эффективность %"]
    )
    for team_id, team in report["statistics"]["teams"].items():
        for player_id, group in {"team": team, **team["players"]}.items():
            for kind in ("serve", "attack", "reception", "block", "dig", "set"):
                stats = group[kind]
                sheet.append(
                    [
                        team_id,
                        player_id,
                        kind,
                        stats["attempts"],
                        stats["unknown_outcomes"],
                        stats.get("win_pct"),
                        stats.get("efficiency"),
                    ]
                )
    sheet = workbook.create_sheet("Версия и ограничения")
    sheet.append(["data_version", data_version])
    sheet.append(
        ["analysis_run_id", run_id if run_id is not None else (report["run"]["id"] if report["run"] else None)]
    )
    sheet.append(["Автоматически принятые действия", report["coverage"]["accepted_events"]])
    for limitation in report["limitations"]:
        sheet.append(["Ограничение", _safe_cell(limitation)])
    sheet.append(["Методика", _safe_cell(report["statistics"]["methodology"])])
    output = io.BytesIO()
    workbook.save(output)
    return Response(
        output.getvalue(),
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers=headers,
    )


def _html_report(report, base_url=None):
    base = f'<base href="{html.escape(base_url, quote=True)}/">' if base_url else ""

    def esc(text):
        return html.escape(str(text), quote=True)

    run, source = report["run"], report["source"]
    coverage = report["coverage"]

    def points(values, color):
        return "".join(
            f'<circle cx="{min(1, max(0, x)) * 900:.2f}" cy="{min(1, max(0, y)) * 500:.2f}" r="3" fill="{color}" opacity=".35"/>'
            for x, y in values
        )

    svg = '<svg viewBox="0 0 900 500" role="img" aria-label="Наблюдения в координатах изображения"><rect width="900" height="500" fill="#0c1118"/>'
    svg += (
        points(report["maps"]["person_footpoints"], "#8feaaf")
        + points(report["maps"]["ball_centers"], "#ffc66d")
        + "</svg>"
    )
    floor_points = report["maps"].get("floor_person_feet", [])
    if floor_points:
        floor_svg = '<svg viewBox="0 0 900 450" role="img" aria-label="Приблизительные точки ног на площадке"><rect width="900" height="450" fill="#0c1118" stroke="#8feaaf"/><path d="M450 0V450 M300 0V450 M600 0V450" stroke="#8feaaf" opacity=".5"/>'
        floor_svg += (
            "".join(
                f'<circle cx="{point["court"][0] / 18 * 900:.2f}" cy="{point["court"][1] / 9 * 450:.2f}" r="4" fill="#8feaaf" opacity=".35"/>'
                for point in floor_points
            )
            + "</svg>"
        )
        floor_section = (
            "<section><h2>Приблизительные точки ног на полу</h2><p>Оценка по нижней границе рамки человека и видимым ориентирам. Это не физическое измерение; дисторсия не исправлена. Мяч и обрезанные ноги не проецируются.</p>"
            + floor_svg
            + "</section>"
        )
    else:
        floor_section = "<section><h2>Проекция на площадку: нет данных</h2><p>Не хватает устойчивой калибровки или наблюдаемых точек ног. Карта выше остаётся в координатах изображения.</p></section>"
    team_names = {str(team["id"]): team["name"] for team in report.get("teams", [])}
    player_names = {str(player["player_id"]): player["name"] for player in report.get("players", [])}
    action_names = {
        "serve": "Подача",
        "reception": "Приём",
        "set": "Передача",
        "attack": "Атака",
        "block": "Блок",
        "dig": "Защита",
        "cover": "Подстраховка",
        "freeball": "Свободный мяч",
        "error": "Ошибка",
    }
    quality = report["statistics"].get("data_quality", {})
    conflicts = bool(
        quality.get("grade_conflict_count")
        or quality.get("terminal_conflict_count")
        or quality.get("overlapping_rally_ids")
        or quality.get("invalid_outcome_count")
    )
    quality_warning = (
        '<section class="notice"><h2>Нужна проверка исходных данных</h2><p>В ручной разметке есть противоречия исходов, оценок или пересекающиеся розыгрыши. Счёт и статистику нельзя считать проверенным итогом до исправления. Подробнее — data_quality в JSON отчёта.</p></section>'
        if conflicts
        else ""
    )
    player_rows = []
    for tid, team_stats in report["statistics"]["teams"].items():
        for pid, player_stats in team_stats.get("players", {}).items():
            player_label = player_names.get(pid, "Игрок не определён" if pid == "unknown" else "Игрок #" + pid)
            attack = player_stats["attack"]
            player_rows.append(
                f"<tr><td>{esc(team_names.get(tid, tid))}</td><td>{esc(player_label)}</td><td>{attack['attempts']}</td><td>{esc(attack.get('efficiency') if attack.get('efficiency') is not None else 'Нет данных')}</td><td>{player_stats['serve']['attempts']}</td><td>{player_stats['reception']['attempts']}</td><td>{player_stats['dig']['attempts']}</td></tr>"
            )
    player_section = (
        "<section><h2>Игроки — доверенная ручная разметка</h2><p>Подтверждённая карточка не подтверждает действия модели. Ниже только события редактора.</p><table><tr><th>Команда</th><th>Игрок</th><th>Атаки</th><th>Эффективность %</th><th>Подачи</th><th>Приём</th><th>Защита</th></tr>"
        + "".join(player_rows)
        + "</table>"
        + ("<p>Нет размеченных действий игроков.</p>" if not player_rows else "")
        + "</section>"
    )
    rows = "".join(
        f'<tr><td><a href="/api/videos/{e["video_id"]}/stream#t={e["time"]}">{e["time"]:.3f} с</a></td><td>{esc(action_names.get(e["kind"], e["kind"]))}</td><td>{esc(player_names.get(str(e["player_id"]), e["player_id"]) if e["player_id"] is not None else "Неизвестен")}</td><td>{esc(e["outcome"] or "Нет данных")}</td><td>{esc(e["status"])}</td></tr>'
        for e in report["events"]
    )
    stats_rows = "".join(
        f"<tr><td>{esc(team_names.get(tid, 'Команда ' + tid))}</td><td>{t['attack']['attempts']}</td><td>{esc(t['attack'].get('win_pct') if t['attack'].get('win_pct') is not None else 'Нет данных')}</td><td>{esc(t['attack'].get('efficiency') if t['attack'].get('efficiency') is not None else 'Нет данных')}</td><td>{t['serve']['attempts']}</td></tr>"
        for tid, t in report["statistics"]["teams"].items()
    )
    limitations = "".join("<li>" + esc(item) + "</li>" for item in report["limitations"])
    source_text = (
        f"{esc(source['name'])} · {source['width']}×{source['height']} · {source['fps']:.2f} FPS"
        if source
        else "Автоматический анализ не запускался"
    )
    status = esc(run["status"]) if run else "не запущен"
    query = f"data_version={report['data_version']}" + (f"&run_id={run['id']}" if run else "")
    export_base = f"/api/matches/{report['match_id']}/report/export/"
    json_url = esc(export_base + "json?" + query)
    excel_url = esc(export_base + "xlsx?" + query)
    csv_url = esc(export_base + "csv?" + query)
    return f'''<!doctype html><html lang="ru"><meta charset="utf-8">{base}<meta name="viewport" content="width=device-width,initial-scale=1"><title>VolleyVision · отчёт матча {report["match_id"]}</title><style>body{{font:15px system-ui;background:#0c1118;color:#e8edf4;max-width:1100px;margin:32px auto;padding:20px;line-height:1.6}}section{{background:#121923;border:1px solid #263140;border-radius:12px;padding:24px;margin:20px 0}}h1,h2{{line-height:1.25}}small,li{{color:#a8b5c7}}a{{color:#8feaaf}}table{{border-collapse:collapse;width:100%;font-size:13px}}th,td{{text-align:left;padding:10px;border-bottom:1px solid #263140}}svg{{width:100%}}.notice{{border-color:#e5b862}}@media print{{body{{background:white;color:black}}section{{background:white}}li{{color:black}}}}</style><h1>Отчёт матча #{report["match_id"]}</h1><p>{source_text}</p><small>Версия данных: {esc(report["data_version"])}</small><section class="notice"><h2>Объектные наблюдения, не полное распознавание матча</h2><p>Статус: {status}. Проверенные моделью кадры: {esc(coverage.get("sampled_frames") or 0)}. Наблюдения людей: {esc(coverage.get("person_observations") or 0)}. Наблюдения мяча: {esc(coverage.get("ball_observations") or 0)}.</p><p>Автоматически принятых волейбольных действий: 0. Касания и результаты этим модулем не устанавливаются.</p><ul>{limitations}</ul></section><section><h2>Карта наблюдений в изображении</h2><p>Зелёный — нижняя точка рамки человека; жёлтый — центр рамки мяча. Не метры на полу и не траектория.</p>{svg}</section>{floor_section}<section><h2>Статистика доверенных событий редактора</h2><table><tr><th>Команда</th><th>Атаки</th><th>Выигрыш %</th><th>Эффективность %</th><th>Подачи</th></tr>{stats_rows}</table></section>{quality_warning}{player_section}<section><h2>Исходные события и эпизоды</h2><table><tr><th>Время</th><th>Действие</th><th>Игрок ID</th><th>Исход</th><th>Статус</th></tr>{rows}</table></section><p>Подробные данные: <a href="{json_url}">JSON отчёта</a> · <a href="{excel_url}">Excel</a> · <a href="{csv_url}">CSV событий</a></p></html>'''


@router.get("/matches/{mid}/report.html", response_class=HTMLResponse)
def report_html(mid: int, request: Request, run_id: int | None = None, db: DBSession = Depends(session)):
    return HTMLResponse(
        _html_report(match_report(mid, run_id, db), str(request.base_url).rstrip("/")),
        headers={"Cache-Control": "no-store"},
    )
