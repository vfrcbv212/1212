import hashlib
import json
import os
import math
import re
import shutil
import subprocess
import uuid
import time
from fractions import Fraction
from pathlib import Path
from urllib.parse import urlparse

import httpx

from .db import DATA


def run(args, timeout=120, cancel=None):
    try:
        if cancel is None:
            return subprocess.run(
                args, check=True, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=timeout
            ).stdout
        with subprocess.Popen(
            args, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, encoding="utf-8", errors="replace"
        ) as process:
            started = time.monotonic()
            while True:
                if cancel.is_set() or time.monotonic() - started > timeout:
                    process.terminate()
                    try:
                        process.communicate(timeout=5)
                    except subprocess.TimeoutExpired:
                        process.kill()
                        process.communicate()
                    if cancel.is_set():
                        raise InterruptedError("Обработка прервана при остановке; можно запустить повторно")
                    raise ValueError("Превышено время обработки видео")
                try:
                    stdout, stderr = process.communicate(timeout=0.25)
                    if process.returncode:
                        raise ValueError("Ошибка обработки видео: " + stderr[-700:])
                    return stdout
                except subprocess.TimeoutExpired:
                    continue
    except subprocess.TimeoutExpired as exc:
        raise ValueError("Превышено время обработки видео; исходный файл сохранён") from exc
    except FileNotFoundError as exc:
        raise ValueError("Установите FFmpeg и ffprobe и добавьте их в PATH") from exc
    except subprocess.CalledProcessError as exc:
        raise ValueError("Ошибка обработки видео: " + exc.stderr[-700:]) from exc


def probe(path, cancel=None):
    try:
        result = json.loads(
            run(["ffprobe", "-v", "error", "-show_streams", "-show_format", "-of", "json", str(path)], cancel=cancel)
        )
    except (json.JSONDecodeError, UnicodeError) as exc:
        raise ValueError("Не удалось прочитать метаданные видео") from exc
    if not isinstance(result, dict) or not isinstance(result.get("streams"), list):
        raise ValueError("Не удалось прочитать видеопотоки")
    stream = next((s for s in result["streams"] if isinstance(s, dict) and s.get("codec_type") == "video"), None)
    if stream is None:
        raise ValueError("Файл не содержит видеопотока")
    try:
        duration = float((result.get("format") or {}).get("duration") or stream.get("duration") or 0)
        width, height = int(stream.get("width", 0)), int(stream.get("height", 0))
    except (ValueError, TypeError, OverflowError, AttributeError) as exc:
        raise ValueError("Некорректные метаданные видео") from exc
    if width <= 0 or height <= 0 or not isinstance(stream.get("codec_name"), str):
        raise ValueError("Не удалось определить размер кадра или видеокодек")
    if not 0 < duration < 24 * 3600:
        raise ValueError("Не удалось определить допустимую длительность видео (до 24 часов)")
    try:
        fps = float(Fraction(stream.get("avg_frame_rate", "0/1")))
    except (ValueError, TypeError, ZeroDivisionError, OverflowError):
        fps = 0
    if not math.isfinite(fps) or fps < 0:
        fps = 0
    tags = stream.get("tags") if isinstance(stream.get("tags"), dict) else {}
    sides = stream.get("side_data_list") if isinstance(stream.get("side_data_list"), list) else []
    rotation = next(
        (side.get("rotation") for side in sides if isinstance(side, dict) and side.get("rotation") is not None),
        tags.get("rotate", 0),
    )
    try:
        rotation = float(rotation)
        if not math.isfinite(rotation):
            rotation = None
    except (ValueError, TypeError):
        rotation = None
    transfer = stream.get("color_transfer")
    metadata_json = {
        "rotation_degrees": rotation,
        "pixel_format": stream.get("pix_fmt"),
        "color_transfer": transfer,
        "color_primaries": stream.get("color_primaries"),
        "color_space": stream.get("color_space"),
        "hdr": transfer in {"smpte2084", "arib-std-b67"},
        "avg_frame_rate": stream.get("avg_frame_rate"),
        "nominal_frame_rate": stream.get("r_frame_rate"),
        "variable_frame_rate_suspected": bool(
            stream.get("r_frame_rate")
            and stream.get("avg_frame_rate")
            and stream["r_frame_rate"] != stream["avg_frame_rate"]
        ),
        "timestamp_start": (result.get("format") or {}).get("start_time"),
        "original_unchanged": True,
    }
    return {
        "duration": duration,
        "width": width,
        "height": height,
        "fps": fps,
        "codec": stream["codec_name"],
        "metadata_json": metadata_json,
    }


def store_stream(stream, name):
    suffix = Path(name).suffix.lower()
    if suffix not in {".mp4", ".mov", ".mkv", ".avi", ".webm", ".m4v"}:
        raise ValueError("Поддерживаются MP4, MOV, MKV, AVI, WebM, M4V")
    target = DATA / "originals" / (uuid.uuid4().hex + suffix)
    temp = target.with_suffix(".part")
    digest, size = hashlib.sha256(), 0
    try:
        with temp.open("xb") as out:
            for chunk in stream:
                size += len(chunk)
                if size > 20 * 1024**3:
                    raise ValueError("Лимит одного файла — 20 ГБ")
                if shutil.disk_usage(DATA).free < len(chunk) + 256 * 1024**2:
                    raise ValueError("Недостаточно свободного места")
                out.write(chunk)
                digest.update(chunk)
        metadata = probe(temp)
        os.replace(temp, target)
        return target, digest.hexdigest(), size, metadata
    except BaseException:
        temp.unlink(missing_ok=True)
        raise


def validate_yandex(key):
    parsed = urlparse(key)
    if parsed.scheme != "https" or parsed.hostname not in {"disk.yandex.ru", "yadi.sk", "disk.yandex.com"}:
        raise ValueError("Используйте публичную HTTPS-ссылку Яндекс Диска")
    if parsed.port not in (None, 443):
        raise ValueError("Используйте стандартный HTTPS-адрес Яндекс Диска")
    if parsed.username or parsed.password:
        raise ValueError("Не указывайте учётные данные в ссылке")


def yandex_info(key, path=None):
    validate_yandex(key)
    params = {"public_key": key, "limit": 100}
    if path:
        params["path"] = path
    response = httpx.get("https://cloud-api.yandex.net/v1/disk/public/resources", params=params, timeout=30)
    response.raise_for_status()
    d = response.json()
    if not isinstance(d, dict) or d.get("type") not in {"file", "dir"} or not isinstance(d.get("name"), str):
        raise ValueError("Яндекс Диск вернул некорректные метаданные")
    embedded = d.get("_embedded", {})
    if not isinstance(embedded, dict) or not isinstance(embedded.get("items", []), list):
        raise ValueError("Яндекс Диск вернул некорректный список файлов")
    fields = ("name", "type", "size", "mime_type", "path", "md5", "sha256")
    return {
        "resource": {k: d.get(k) for k in fields},
        "items": [{k: x.get(k) for k in fields} for x in embedded.get("items", []) if isinstance(x, dict)],
        "total": embedded.get("total", 0),
    }


def yandex_download(key, path=None):
    info = yandex_info(key, path)["resource"]
    if info["type"] != "file":
        raise ValueError("Выберите конкретный видеофайл из папки")
    size = info.get("size")
    if size is not None and (not isinstance(size, int) or isinstance(size, bool) or size < 0):
        raise ValueError("Яндекс Диск вернул некорректный размер файла")
    if (size or 0) > 20 * 1024**3:
        raise ValueError("Файл больше лимита 20 ГБ")
    params = {"public_key": key}
    if path:
        params["path"] = path
    response = httpx.get("https://cloud-api.yandex.net/v1/disk/public/resources/download", params=params, timeout=30)
    response.raise_for_status()
    download = response.json()
    href = download.get("href") if isinstance(download, dict) else None
    if not isinstance(href, str):
        raise ValueError("Яндекс Диск не вернул ссылку на скачивание")
    # Do not follow arbitrary URLs/redirects from remote metadata.
    parsed = urlparse(href)
    host = parsed.hostname or ""
    if (
        parsed.scheme != "https"
        or parsed.username
        or parsed.password
        or parsed.port not in (None, 443)
        or not (host.endswith(".yandex.net") or host.endswith(".yandex.ru"))
    ):
        raise ValueError("API вернул неподдерживаемый адрес загрузки")
    with httpx.stream("GET", href, timeout=120, follow_redirects=False) as r:
        r.raise_for_status()
        stored = store_stream(r.iter_bytes(1024 * 1024), info["name"])
    try:
        if size is not None and stored[2] != size:
            raise ValueError("Размер загруженного файла не совпадает с метаданными")
        for algorithm in ("sha256", "md5"):
            expected = info.get(algorithm)
            if expected is None:
                continue
            length = 64 if algorithm == "sha256" else 32
            if not isinstance(expected, str) or not re.fullmatch(f"[0-9a-fA-F]{{{length}}}", expected):
                raise ValueError("Яндекс Диск вернул некорректную контрольную сумму")
            if algorithm == "sha256":
                actual = stored[1]
            else:
                digest = hashlib.md5(usedforsecurity=False)
                with stored[0].open("rb") as source:
                    for chunk in iter(lambda: source.read(1024 * 1024), b""):
                        digest.update(chunk)
                actual = digest.hexdigest()
            if actual.lower() != expected.lower():
                raise ValueError("Контрольная сумма загруженного файла не совпадает с метаданными")
    except Exception:
        stored[0].unlink(missing_ok=True)
        raise
    return info["name"], stored


def display_filter(video, base, cancel=None):
    """HDR is explicitly tone-mapped to SDR for derived/browser images only."""
    info = getattr(video, "metadata_json", None) or {}
    if "hdr" not in info:
        info = probe(DATA / video.path, cancel=cancel).get("metadata_json", {})
    if info.get("hdr"):
        return (
            "zscale=t=linear:npl=100,format=gbrpf32le,zscale=p=bt709,"
            "tonemap=tonemap=hable:desat=0,zscale=t=bt709:m=bt709:r=tv," + base + ",format=yuv420p"
        )
    return base


def make_proxy(video, cancel=None):
    final = DATA / "derived" / f"{video.id}-proxy.mp4"
    temp = final.with_name(final.stem + ".tmp.mp4")
    try:
        run(
            [
                "ffmpeg",
                "-nostdin",
                "-y",
                "-v",
                "error",
                "-i",
                str(DATA / video.path),
                "-vf",
                display_filter(video, r"scale=trunc(min(1280\,iw)/2)*2:-2,setsar=1", cancel),
                "-c:v",
                "libx264",
                "-pix_fmt",
                "yuv420p",
                "-preset",
                "veryfast",
                "-crf",
                "24",
                "-threads",
                "2",
                "-c:a",
                "aac",
                "-movflags",
                "+faststart",
                str(temp),
            ],
            timeout=7200,
            cancel=cancel,
        )
        probe(temp, cancel=cancel)
        os.replace(temp, final)
        return str(final.relative_to(DATA))
    finally:
        temp.unlink(missing_ok=True)


def export_clip(events, videos, before, after):
    folder = DATA / "exports" / uuid.uuid4().hex
    folder.mkdir()
    parts = []
    try:
        for i, event in enumerate(events):
            video = videos[event.video_id]
            start = max(0, event.time - before)
            duration = min(video.duration, event.time + after) - start
            part = folder / f"{i}.mp4"
            run(
                [
                    "ffmpeg",
                    "-nostdin",
                    "-y",
                    "-v",
                    "error",
                    "-ss",
                    str(start),
                    "-i",
                    str(DATA / video.path),
                    "-t",
                    str(duration),
                    "-an",
                    "-vf",
                    display_filter(
                        video,
                        "scale=1280:720:force_original_aspect_ratio=decrease,pad=1280:720:(ow-iw)/2:(oh-ih)/2,fps=30,setsar=1",
                    ),
                    "-c:v",
                    "libx264",
                    "-pix_fmt",
                    "yuv420p",
                    "-preset",
                    "veryfast",
                    "-threads",
                    "2",
                    str(part),
                ],
                timeout=300,
            )
            parts.append(part)
        listing = folder / "list.txt"
        listing.write_text("\n".join(f"file '{p.name}'" for p in parts), encoding="utf-8")
        final = folder / "clip.mp4"
        run(
            [
                "ffmpeg",
                "-nostdin",
                "-y",
                "-v",
                "error",
                "-f",
                "concat",
                "-safe",
                "1",
                "-i",
                str(listing),
                "-c",
                "copy",
                "-movflags",
                "+faststart",
                str(final),
            ],
            timeout=300,
        )
        probe(final)
        for part in parts:
            part.unlink()
        listing.unlink()
        return str(final.relative_to(DATA))
    except BaseException:
        shutil.rmtree(folder)
        raise
