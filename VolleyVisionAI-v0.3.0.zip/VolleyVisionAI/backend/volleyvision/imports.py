"""Durable bounded uploads and explicitly allowlisted server-side imports.

Session manifests/chunks survive browser disconnects and server restarts. Final
assembly uses at most 1 MiB per read; already accepted chunks are never resent.
The application is single-process; per-session locks serialize commit/finalize.
"""

import errno
import hashlib
import json
import math
import os
import re
import shutil
import tempfile
import threading
import uuid
from contextlib import contextmanager
from pathlib import Path

import anyio
from starlette.requests import ClientDisconnect
from fastapi import APIRouter, Depends, HTTPException, Query, Request
from pydantic import BaseModel, ConfigDict, Field, field_validator
from sqlalchemy import select
from sqlalchemy.orm import Session as DBSession

from . import media
from .db import DATA, session
from .models import Match, Video

router = APIRouter(prefix="/api", tags=["imports"])
UPLOAD_ROOT = DATA / "uploads"
MAX_SIZE = 20 * 1024**3
DEFAULT_CHUNK_SIZE = 8 * 1024**2
RESERVE = 256 * 1024**2
EXTENSIONS = {".mp4", ".mov", ".mkv", ".avi", ".webm", ".m4v"}
SHA = re.compile(r"^[0-9a-f]{64}$")
SESSION_ID = re.compile(r"^[0-9a-f]{32}$")
_locks_guard = threading.Lock()
_locks = {}
_create_lock = threading.RLock()


class UploadIn(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)
    name: str = Field(min_length=1, max_length=255)
    size: int = Field(gt=0, le=MAX_SIZE)
    sha256: str = Field(pattern=r"^[0-9a-fA-F]{64}$")
    chunk_size: int = Field(default=DEFAULT_CHUNK_SIZE, ge=64 * 1024, le=16 * 1024**2)

    @field_validator("sha256")
    @classmethod
    def lower_hash(cls, value):
        return value.lower()

    @field_validator("name")
    @classmethod
    def safe_name(cls, value):
        # The original basename is display-only; storage always uses a UUID.
        if "/" in value or "\\" in value or any(ord(ch) < 32 for ch in value) or value in {".", ".."}:
            raise ValueError("Укажите только безопасное имя видеофайла без папок")
        if Path(value).suffix.lower() not in EXTENSIONS:
            raise ValueError("Поддерживаются MP4, MOV, MKV, AVI, WebM, M4V")
        return value


class LocalIn(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)
    path: str = Field(min_length=1, max_length=2000)
    sha256: str | None = Field(default=None, pattern=r"^[0-9a-fA-F]{64}$")


def _lock(ident):
    if not SESSION_ID.fullmatch(ident):
        raise HTTPException(404, "Загрузка не найдена")
    with _locks_guard:
        return _locks.setdefault(ident, threading.RLock())


def _folder(ident):
    if not SESSION_ID.fullmatch(ident):
        raise HTTPException(404, "Загрузка не найдена")
    return UPLOAD_ROOT / ident


def _read(ident):
    folder = _folder(ident)
    try:
        manifest = json.loads((folder / "manifest.json").read_text(encoding="utf-8"))
    except FileNotFoundError:
        raise HTTPException(404, "Загрузка не найдена") from None
    except (OSError, ValueError) as exc:
        raise HTTPException(409, "Сведения о загрузке повреждены. Создайте новую загрузку.") from exc
    try:
        if not isinstance(manifest, dict) or manifest.get("id") != ident:
            raise ValueError("invalid manifest identity")
        UploadIn.model_validate({k: manifest[k] for k in ("name", "size", "sha256", "chunk_size")})
        if (
            not isinstance(manifest.get("match_id"), int)
            or isinstance(manifest["match_id"], bool)
            or manifest["match_id"] <= 0
            or manifest["status"] not in {"uploading", "completed"}
            or not isinstance(manifest["total_chunks"], int)
            or isinstance(manifest["total_chunks"], bool)
            or manifest["total_chunks"] != math.ceil(manifest["size"] / manifest["chunk_size"])
            or not re.fullmatch(r"[0-9a-f]{32}\.(mp4|mov|mkv|avi|webm|m4v)", manifest["target_name"])
            or not isinstance(manifest["chunks"], dict)
        ):
            raise ValueError("invalid manifest metadata")
        for key, info in manifest["chunks"].items():
            if not re.fullmatch(r"0|[1-9][0-9]*", key) or not isinstance(info, dict):
                raise ValueError("invalid chunk record")
            index = int(key)
            if (
                not 0 <= index < manifest["total_chunks"]
                or not isinstance(info["size"], int)
                or isinstance(info["size"], bool)
                or info["size"] != _size_for(manifest, index)
                or not SHA.fullmatch(info["sha256"])
            ):
                raise ValueError("invalid chunk metadata")
        if manifest["status"] == "completed" and (
            not isinstance(manifest["video_id"], int) or manifest["video_id"] <= 0
        ):
            raise ValueError("invalid result")
    except (ValueError, KeyError, TypeError, AttributeError) as exc:
        raise HTTPException(409, "Некорректные сведения о загрузке. Создайте новую загрузку.") from exc
    return manifest


def _save(manifest):
    folder = _folder(manifest["id"])
    descriptor, name = tempfile.mkstemp(prefix="manifest-", suffix=".tmp", dir=folder)
    temporary = Path(name)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8") as target:
            json.dump(manifest, target, ensure_ascii=False)
            target.flush()
            os.fsync(target.fileno())
        os.replace(temporary, folder / "manifest.json")
    finally:
        temporary.unlink(missing_ok=True)


def _match(db, mid):
    match = db.get(Match, mid)
    if match is None:
        raise HTTPException(404, "Матч не найден")
    return match


def _video_dict(video):
    return {c.name: getattr(video, c.name) for c in video.__table__.columns}


def _existing(db, mid, digest):
    return db.scalar(select(Video).where(Video.match_id == mid, Video.sha256 == digest))


def _size_for(manifest, index):
    if not 0 <= index < manifest["total_chunks"]:
        raise HTTPException(422, "Номер части выходит за пределы файла")
    return min(manifest["chunk_size"], manifest["size"] - index * manifest["chunk_size"])


def _available(manifest):
    folder = _folder(manifest["id"])
    # Files and manifest are both checked. A chunk interrupted before the atomic
    # rename is not accepted; an accepted file missing after disk damage is resent.
    received = []
    for key, info in manifest.get("chunks", {}).items():
        index = int(key)
        path = folder / f"{index}.chunk"
        if path.is_file() and path.stat().st_size == info["size"]:
            received.append(index)
    return sorted(received)


def _status(db, manifest):
    _match(db, manifest["match_id"])
    received = _available(manifest)
    result = {
        k: manifest[k] for k in ("id", "match_id", "name", "size", "sha256", "chunk_size", "total_chunks", "status")
    }
    if manifest["status"] == "completed":
        video = db.get(Video, manifest.get("video_id"))
        if video is None or video.match_id != manifest["match_id"] or video.sha256 != manifest["sha256"]:
            raise HTTPException(409, "Результат загрузки отсутствует. Создайте новую загрузку.")
        result.update(
            video=_video_dict(video), received=list(range(manifest["total_chunks"])), received_bytes=manifest["size"]
        )
    else:
        result.update(received=received, received_bytes=sum(_size_for(manifest, i) for i in received))
    return result


@contextmanager
def _storage_errors():
    try:
        yield
    except OSError as exc:
        if exc.errno in {errno.ENOSPC, getattr(errno, "EDQUOT", errno.ENOSPC)}:
            raise HTTPException(507, "Недостаточно места на диске. Уже принятые части сохранены.") from exc
        raise HTTPException(409, "Файл или папка временно недоступны. Проверьте права и повторите операцию.") from exc


def _space(required):
    if shutil.disk_usage(DATA).free < required + RESERVE:
        raise HTTPException(507, "Недостаточно свободного места для видео и его временной копии")


@router.post("/matches/{mid}/uploads", status_code=201)
def create_upload(mid: int, body: UploadIn, db: DBSession = Depends(session)):
    _match(db, mid)
    UPLOAD_ROOT.mkdir(parents=True, exist_ok=True)
    with _create_lock, _storage_errors():
        active = 0
        for candidate in UPLOAD_ROOT.glob("*/manifest.json"):
            try:
                old = _read(candidate.parent.name)
            except HTTPException:
                continue
            if old["status"] != "completed":
                active += 1
            if old["match_id"] == mid and old["sha256"] == body.sha256 and old["size"] == body.size:
                with _lock(old["id"]):
                    try:
                        return _status(db, _read(old["id"]))
                    except HTTPException as exc:
                        if exc.status_code != 409:
                            raise
        previous_video = _existing(db, mid, body.sha256)
        if previous_video is not None and previous_video.size != body.size:
            raise HTTPException(409, "Указанный размер не совпадает с уже сохранённым файлом этой SHA-256")
        if previous_video is None:
            if active >= 32:
                raise HTTPException(429, "Слишком много незавершённых загрузок. Завершите или отмените предыдущие.")
            _space(body.size * 2)
        ident = uuid.uuid4().hex
        folder = _folder(ident)
        folder.mkdir()
        manifest = {
            "id": ident,
            "match_id": mid,
            **body.model_dump(),
            "total_chunks": math.ceil(body.size / body.chunk_size),
            "chunks": {},
            "status": "uploading",
            "target_name": uuid.uuid4().hex + Path(body.name).suffix.lower(),
        }
        if previous_video is not None:
            manifest.update(status="completed", video_id=previous_video.id)
        _save(manifest)
        return _status(db, manifest)


@router.get("/uploads/{ident}")
def upload_status(ident: str, db: DBSession = Depends(session)):
    with _lock(ident):
        return _status(db, _read(ident))


def _commit_chunk(ident, index, checksum, temporary, actual_size):
    with _lock(ident):
        manifest = _read(ident)
        expected_size = _size_for(manifest, index)
        if expected_size != actual_size:
            raise HTTPException(422, "Размер части не совпадает с ожидаемым")
        if manifest["status"] == "completed":
            return manifest
        folder = _folder(ident)
        previous = manifest["chunks"].get(str(index))
        if previous is not None and (folder / f"{index}.chunk").is_file():
            if previous["sha256"] != checksum:
                raise HTTPException(409, "Эта часть уже загружена с другими данными")
            if (folder / f"{index}.chunk").stat().st_size == expected_size:
                return manifest
        _space(actual_size)
        os.replace(temporary, folder / f"{index}.chunk")
        manifest["chunks"][str(index)] = {"size": actual_size, "sha256": checksum}
        _save(manifest)
        return manifest


@router.put("/uploads/{ident}/chunks/{index}")
async def upload_chunk(
    ident: str,
    index: int,
    request: Request,
    sha256: str = Query(pattern=r"^[0-9a-fA-F]{64}$"),
    db: DBSession = Depends(session),
):
    with _lock(ident):
        manifest = _read(ident)
        _match(db, manifest["match_id"])
        expected_size = _size_for(manifest, index)
    content_length = request.headers.get("content-length")
    if content_length is not None:
        try:
            if int(content_length) != expected_size:
                raise HTTPException(413, "Размер тела запроса не совпадает с размером части")
        except ValueError:
            raise HTTPException(422, "Некорректный Content-Length") from None
    UPLOAD_ROOT.mkdir(parents=True, exist_ok=True)
    descriptor, name = tempfile.mkstemp(prefix="incoming-", suffix=".part", dir=UPLOAD_ROOT)
    temporary = Path(name)
    actual_size, digest = 0, hashlib.sha256()
    try:
        with os.fdopen(descriptor, "wb") as target:
            async for chunk in request.stream():
                actual_size += len(chunk)
                if actual_size > expected_size:
                    raise HTTPException(413, "Часть превышает ожидаемый размер")
                _space(len(chunk))
                digest.update(chunk)
                await anyio.to_thread.run_sync(target.write, chunk)
            await anyio.to_thread.run_sync(target.flush)
            await anyio.to_thread.run_sync(os.fsync, target.fileno())
        if actual_size != expected_size or digest.hexdigest() != sha256.lower():
            raise HTTPException(422, "Размер или SHA-256 части не совпадает; повторите только эту часть")
        manifest = await anyio.to_thread.run_sync(
            _commit_chunk, ident, index, digest.hexdigest(), temporary, actual_size
        )
        return _status(db, manifest)
    except ClientDisconnect:
        raise HTTPException(499, "Передача прервана. Принятые части сохранены; повторите только недостающие.") from None
    except OSError as exc:
        with _storage_errors():
            raise exc
    finally:
        temporary.unlink(missing_ok=True)


def _digest_file(path):
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _register(db, mid, name, stored):
    from .main import register_video

    previous = _existing(db, mid, stored[1])
    if previous is not None:
        if stored[0] != DATA / previous.path:
            stored[0].unlink(missing_ok=True)
        return _video_dict(previous)
    try:
        return register_video(db, mid, name, stored)
    except Exception:
        db.rollback()
        # Another path may have registered the same checksum during assembly.
        previous = _existing(db, mid, stored[1])
        if previous is not None:
            return _video_dict(previous)
        raise


def _complete(db, manifest, video):
    manifest.update(status="completed", video_id=video["id"])
    _save(manifest)
    for part in _folder(manifest["id"]).glob("*.chunk"):
        part.unlink(missing_ok=True)
    return video


@router.post("/uploads/{ident}/finalize")
def finalize_upload(ident: str, db: DBSession = Depends(session)):
    with _lock(ident), _storage_errors():
        manifest = _read(ident)
        _match(db, manifest["match_id"])
        if manifest["status"] == "completed":
            return _status(db, manifest)["video"]
        previous = _existing(db, manifest["match_id"], manifest["sha256"])
        if previous is not None:
            candidate = DATA / "originals" / manifest["target_name"]
            referenced = db.scalar(select(Video.id).where(Video.path == str(candidate.relative_to(DATA))))
            if referenced is None:
                candidate.unlink(missing_ok=True)
                candidate.with_suffix(".part").unlink(missing_ok=True)
            return _complete(db, manifest, _video_dict(previous))
        if len(_available(manifest)) != manifest["total_chunks"]:
            raise HTTPException(409, "Файл загружен не полностью. Продолжите недостающие части.")
        target = DATA / "originals" / manifest["target_name"]
        temporary = target.with_suffix(".part")
        folder = _folder(ident)
        try:
            if (
                target.is_file()
                and target.stat().st_size == manifest["size"]
                and _digest_file(target) == manifest["sha256"]
            ):
                metadata = media.probe(target)
            else:
                _space(manifest["size"])
                digest = hashlib.sha256()
                with temporary.open("wb") as out:
                    for index in range(manifest["total_chunks"]):
                        part_digest = hashlib.sha256()
                        with (folder / f"{index}.chunk").open("rb") as part:
                            for chunk in iter(lambda: part.read(1024 * 1024), b""):
                                _space(len(chunk))
                                out.write(chunk)
                                digest.update(chunk)
                                part_digest.update(chunk)
                        if part_digest.hexdigest() != manifest["chunks"][str(index)]["sha256"]:
                            (folder / f"{index}.chunk").unlink(missing_ok=True)
                            raise HTTPException(422, f"Часть {index} повреждена на диске. Загрузите её повторно.")
                    out.flush()
                    os.fsync(out.fileno())
                if digest.hexdigest() != manifest["sha256"]:
                    raise HTTPException(
                        422, "Полная SHA-256 не совпадает. Проверьте исходный файл и создайте новую загрузку."
                    )
                metadata = media.probe(temporary)
                os.replace(temporary, target)
            video = _register(
                db, manifest["match_id"], manifest["name"], (target, manifest["sha256"], manifest["size"], metadata)
            )
            return _complete(db, manifest, video)
        finally:
            temporary.unlink(missing_ok=True)


@router.delete("/uploads/{ident}")
def cancel_upload(ident: str, db: DBSession = Depends(session)):
    with _lock(ident):
        manifest = _read(ident)
        _match(db, manifest["match_id"])
        if manifest["status"] == "completed":
            raise HTTPException(409, "Завершённая загрузка уже является видео матча и не удаляется через отмену")
        target = DATA / "originals" / manifest["target_name"]
        referenced = db.scalar(select(Video.id).where(Video.path == str(target.relative_to(DATA))))
        if referenced is None:
            target.unlink(missing_ok=True)
            target.with_suffix(".part").unlink(missing_ok=True)
        shutil.rmtree(_folder(ident))
        return {"ok": True}


def _local_path(relative, directory=False):
    configured = os.environ.get("VOLLEYVISION_IMPORT_ROOT")
    if not configured:
        raise HTTPException(403, "Локальный импорт не настроен: укажите VOLLEYVISION_IMPORT_ROOT на сервере")
    root = Path(configured).expanduser().resolve()
    if not root.is_dir():
        raise HTTPException(409, "Разрешённая папка импорта не существует")
    if "\\" in relative or ":" in relative or Path(relative).is_absolute() or ".." in Path(relative).parts:
        raise HTTPException(422, "Используйте относительный путь внутри разрешённой папки")
    target = (root / relative).resolve()
    if not target.is_relative_to(root):
        raise HTTPException(403, "Путь выходит за пределы разрешённой папки импорта")
    if not target.exists() or (directory and not target.is_dir()) or (not directory and not target.is_file()):
        raise HTTPException(404, "Файл или папка импорта не найдены")
    if not directory and target.suffix.lower() not in EXTENSIONS:
        raise HTTPException(422, "Выберите поддерживаемый видеофайл")
    return root, target


@router.get("/local-import/files")
def local_files(path: str = Query(default="", max_length=2000)):
    if not os.environ.get("VOLLEYVISION_IMPORT_ROOT"):
        return {"configured": False, "path": "", "files": []}
    root, target = _local_path(path, directory=True)
    files = []
    for item in sorted(target.iterdir(), key=lambda item: (not item.is_dir(), item.name.casefold())):
        # Resolve links before listing them: no names/metadata outside allowlist.
        resolved = item.resolve()
        if not resolved.is_relative_to(root):
            continue
        if resolved.is_dir() or (resolved.is_file() and resolved.suffix.lower() in EXTENSIONS):
            files.append(
                {
                    "path": item.relative_to(root).as_posix(),
                    "name": item.name,
                    "type": "directory" if resolved.is_dir() else "file",
                    "size": resolved.stat().st_size if resolved.is_file() else None,
                }
            )
        if len(files) >= 200:
            break
    return {"configured": True, "path": target.relative_to(root).as_posix() if target != root else "", "files": files}


@router.post("/matches/{mid}/local-import", status_code=201)
def local_import(mid: int, body: LocalIn, db: DBSession = Depends(session)):
    _match(db, mid)
    _, source = _local_path(body.path)
    with _storage_errors():
        before = source.stat()
        size = before.st_size
        if not 0 < size <= MAX_SIZE:
            raise HTTPException(413, "Размер видео должен быть больше нуля и не превышать 20 ГБ")
        _space(size)

        def fingerprint(stat):
            return stat.st_dev, stat.st_ino, stat.st_size, stat.st_mtime_ns

        with source.open("rb") as file:
            if fingerprint(before) != fingerprint(os.fstat(file.fileno())):
                raise HTTPException(409, "Исходный файл изменился перед импортом; выберите готовую запись")
            stored = media.store_stream(iter(lambda: file.read(1024 * 1024), b""), source.name)
            unchanged = fingerprint(before) == fingerprint(os.fstat(file.fileno()))
        if not unchanged or stored[2] != size or (body.sha256 is not None and stored[1] != body.sha256.lower()):
            stored[0].unlink(missing_ok=True)
            raise HTTPException(422, "Файл изменился во время импорта или полная SHA-256 не совпадает")
        return _register(db, mid, source.name, stored)
