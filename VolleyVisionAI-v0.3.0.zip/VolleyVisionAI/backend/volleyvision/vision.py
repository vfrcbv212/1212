"""Real YOLOX ONNX inference; observations are never volleyball actions or player identities.

The official release artifacts are checksum-pinned. Inference uses local CPU/CUDA
providers only; no cloud API or automatic weight download is performed here.
"""

from __future__ import annotations

import hashlib
import importlib.metadata
import importlib.util
import math
import os
import time
from functools import lru_cache
from pathlib import Path

# The runtime API may run after a minimal initialization event. Disable the
# uploader and persistent telemetry identifier before importing ONNX Runtime.
os.environ["ORT_DISABLE_TELEMETRY"] = "1"

from .db import DATA

MODEL_RELEASE = "0.1.1rc0"
MODELS = {
    "yolox-tiny": {
        "filename": "yolox_tiny.onnx",
        "input_size": 416,
        "bytes": 20219662,
        "sha256": "427cc366d34e27ff7a03e2899b5e3671425c262ea2291f88bb942bc1cc70b0f7",
    },
    "yolox-small": {
        "filename": "yolox_s.onnx",
        "input_size": 640,
        "bytes": 35858002,
        "sha256": "c5c2d13e59ae883e6af3b45daea64af4833a4951c92d116ec270d9ddbe998063",
    },
}
RELEASE_BASE = "https://github.com/Megvii-BaseDetection/YOLOX/releases/download/" + MODEL_RELEASE
CODE_LICENSE = "Apache-2.0 (official repository; no separate release weight terms found)"
CODE_SOURCE = "https://github.com/Megvii-BaseDetection/YOLOX"
CLASS_NAMES = {0: "person", 32: "sports ball"}
MAX_SEGMENT_SECONDS = 60.0


def _model_spec(model_id):
    if model_id not in MODELS:
        raise ValueError("Неизвестная модель. Доступны yolox-tiny и yolox-small")
    return MODELS[model_id]


def model_path(model_id="yolox-tiny"):
    return (
        Path(os.environ.get("VOLLEYVISION_MODELS_DIR", DATA / "models")).resolve() / _model_spec(model_id)["filename"]
    )


def file_sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


@lru_cache(maxsize=8)
def _cached_sha(path, size, modified):
    return file_sha256(path)


def get_model_manifest(model_id="yolox-tiny"):
    spec = _model_spec(model_id)
    path = model_path(model_id)
    exists, verified = path.is_file(), False
    if exists:
        info = path.stat()
        verified = (
            info.st_size == spec["bytes"] and _cached_sha(str(path), info.st_size, info.st_mtime_ns) == spec["sha256"]
        )
    return {
        "model_id": model_id,
        "version": MODEL_RELEASE,
        "sha256": spec["sha256"],
        "bytes": spec["bytes"],
        "input_size": spec["input_size"],
        "installed": exists,
        "verified": verified,
        "source_url": RELEASE_BASE + "/" + spec["filename"],
        "code_license": CODE_LICENSE,
        "license_url": CODE_SOURCE + "/blob/0.1.1rc0/LICENSE",
        "weight_license_evidence": "Official release linked by the Apache-2.0 repository; separate artifact license not published.",
        "training_dataset": "COCO2017; image licenses vary, no training images redistributed",
    }


def _dependencies():
    return all(importlib.util.find_spec(name) is not None for name in ("numpy", "cv2", "onnxruntime"))


def get_runtime_info(model_id="yolox-tiny", device="auto"):
    if device not in {"auto", "cpu", "cuda"}:
        raise ValueError("Устройство должно быть auto, cpu или cuda")
    manifest = get_model_manifest(model_id)
    providers = []
    dependencies = _dependencies()
    versions = {}
    runtime_error = None
    if dependencies:
        try:
            import onnxruntime as ort

            ort.disable_telemetry_events()
            providers = ort.get_available_providers()
        except (ImportError, OSError, RuntimeError):
            dependencies = False
            runtime_error = "Нативный ONNX Runtime не загрузился; проверьте Visual C++ Runtime/совместимость пакета"
        for name in ("onnxruntime", "onnxruntime-gpu", "numpy", "opencv-python-headless"):
            try:
                versions[name] = importlib.metadata.version(name)
            except importlib.metadata.PackageNotFoundError:
                pass
    provider = (
        "CUDAExecutionProvider"
        if device != "cpu" and "CUDAExecutionProvider" in providers
        else "CPUExecutionProvider"
        if "CPUExecutionProvider" in providers and device != "cuda"
        else None
    )
    installed = manifest["verified"] and dependencies
    return {
        "installed": installed,
        "verified": manifest["verified"],
        "model_id": model_id,
        "model_version": MODEL_RELEASE,
        "model_sha256": manifest["sha256"],
        "available_providers": providers,
        "provider": provider,
        "active_device": "cuda" if provider == "CUDAExecutionProvider" else "cpu" if provider else "unavailable",
        "requested_device": device,
        "device_verified_by_session": False,
        "dependencies_installed": dependencies,
        "versions": versions,
        "runtime_error": runtime_error,
        "source_url": manifest["source_url"],
        "code_license": CODE_LICENSE,
        "limitations": [
            "No volleyball event classifier",
            "No jersey OCR or player identity",
            "COCO sports-ball class is not validated on this match",
            "No court metric projection without calibration",
        ],
    }


def nms(detections, threshold=0.45):
    """Class-specific greedy suppression; deterministic on equal confidence."""
    pending = sorted(detections, key=lambda d: (-d["confidence"], d["class_id"], tuple(d["bbox"])))
    chosen = []
    while pending:
        best, *rest = pending
        chosen.append(best)
        pending = [
            candidate
            for candidate in rest
            if candidate["class_id"] != best["class_id"] or box_iou(candidate["bbox"], best["bbox"]) <= threshold
        ]
    return chosen


def box_iou(a, b):
    area_a = max(0, a[2] - a[0]) * max(0, a[3] - a[1])
    area_b = max(0, b[2] - b[0]) * max(0, b[3] - b[1])
    intersection = max(0, min(a[2], b[2]) - max(a[0], b[0])) * max(0, min(a[3], b[3]) - max(a[1], b[1]))
    union = area_a + area_b - intersection
    return intersection / union if union else 0.0


class IoUTracker:
    """Small baseline association, not ByteTrack, re-identification or jersey identity.

    Gaps expire and detections always remain observations. No interpolated ball
    positions or contacts are generated.
    """

    def __init__(self, max_gap=1.0, threshold=0.2):
        self.max_gap, self.threshold = max_gap, threshold
        self.tracks, self.next_id = {}, 1

    def update(self, detections, timestamp):
        self.tracks = {
            ident: track for ident, track in self.tracks.items() if timestamp - track["time"] <= self.max_gap
        }
        used, result = set(), []
        for detection in sorted(detections, key=lambda d: -d["confidence"]):
            candidates = [
                (box_iou(detection["bbox"], t["bbox"]), ident)
                for ident, t in self.tracks.items()
                if ident not in used and t["class_id"] == detection["class_id"]
            ]
            overlap, ident = max(candidates, default=(0, 0))
            if overlap < self.threshold or not ident:
                ident = self.next_id
                self.next_id += 1
            used.add(ident)
            self.tracks[ident] = {**detection, "time": timestamp}
            result.append(
                {
                    **detection,
                    "track_id": ident,
                    "player_id": None,
                    "team_id": None,
                    "identity_status": "unknown",
                    "tracking_method": "greedy_iou_baseline",
                }
            )
        return result


class YoloXDetector:
    def __init__(
        self,
        model_id="yolox-tiny",
        device="auto",
        strategy="fullframe",
        model_path=None,
        person_threshold=0.4,
        ball_threshold=0.2,
    ):
        if strategy not in {"fullframe", "tiles"}:
            raise ValueError("Стратегия должна быть fullframe или tiles")
        if not 0 < person_threshold <= 1 or not 0 < ball_threshold <= 1:
            raise ValueError("Порог confidence должен находиться в (0,1]")
        info = get_runtime_info(model_id, device)
        if not info["dependencies_installed"]:
            raise ValueError("Установите AI-зависимости: python -m pip install -r requirements-ai.lock")
        spec = _model_spec(model_id)
        path = Path(model_path) if model_path is not None else globals()["model_path"](model_id)
        if not path.is_file():
            raise ValueError("Веса не установлены. Запустите python scripts/install_models.py --model " + model_id)
        # Verify the actual file again before loading; an ONNX artifact never executes pickle.
        if path.stat().st_size != spec["bytes"] or file_sha256(path) != spec["sha256"]:
            raise ValueError(
                "Контрольная сумма весов не совпала. Не используйте файл; переустановите официальную модель"
            )
        import onnxruntime as ort

        ort.disable_telemetry_events()
        if device == "cuda" and info["provider"] != "CUDAExecutionProvider":
            raise ValueError("CUDA provider недоступен. Установите совместимый onnxruntime-gpu или выберите CPU")
        providers = [info["provider"]] if info["provider"] else ["CPUExecutionProvider"]
        preload_note = None
        if providers[0] == "CUDAExecutionProvider":
            providers.append("CPUExecutionProvider")
            # Supported ORT API searches installed NVIDIA/PyTorch/system DLLs.
            # Do not install drivers or import arbitrary paths during inference.
            preload = getattr(ort, "preload_dlls", None)
            if callable(preload):
                try:
                    preload()
                except (OSError, RuntimeError) as exc:
                    preload_note = type(exc).__name__
        options = ort.SessionOptions()
        options.intra_op_num_threads = 2
        options.inter_op_num_threads = 1
        options.log_severity_level = 3
        started = time.perf_counter()
        try:
            self.session = ort.InferenceSession(str(path), sess_options=options, providers=providers)
        except Exception as exc:
            if device == "auto" and providers[0] == "CUDAExecutionProvider":
                # ORT may fail before its own fallback can activate. The actual
                # provider below still records CPU, never a pretend CUDA run.
                try:
                    self.session = ort.InferenceSession(
                        str(path), sess_options=options, providers=["CPUExecutionProvider"]
                    )
                except Exception as cpu_exc:
                    raise ValueError(
                        "Не удалось запустить ONNX Runtime ни на CUDA, ни на CPU; проверьте установку AI"
                    ) from cpu_exc
            else:
                raise ValueError(
                    "Не удалось запустить выбранный исполнитель ONNX Runtime; для CUDA проверьте совместимые драйвер/CUDA/cuDNN или выберите CPU"
                ) from exc
        active = self.session.get_providers()[0]
        if device == "cuda" and active != "CUDAExecutionProvider":
            raise ValueError(
                "ONNX Runtime не смог активировать CUDA. Используйте CPU или проверьте совместимость CUDA/cuDNN"
            )
        self.model_id, self.strategy, self.size = model_id, strategy, spec["input_size"]
        self.person_threshold, self.ball_threshold = person_threshold, ball_threshold
        self.input_name = self.session.get_inputs()[0].name
        if self.session.get_inputs()[0].shape != [1, 3, self.size, self.size]:
            raise ValueError("Форма входа официальной модели не совпала с реестром")
        self.manifest = {**get_model_manifest(model_id), "installed": True, "verified": True}
        self.runtime = {
            **info,
            "provider": active,
            "active_device": "cuda" if active == "CUDAExecutionProvider" else "cpu",
            "device_verified_by_session": True,
            "provider_fallback": active != info["provider"],
            "provider_note": (
                "CUDA activation fell back to CPU; performance is reduced" if active != info["provider"] else None
            ),
            "gpu_operator_placement_verified": False,
            "dll_preload_note": preload_note,
            "installed": True,
            "verified": True,
            "load_seconds": time.perf_counter() - started,
        }
        self.inference_seconds = 0.0
        self.inference_calls = 0
        self._grids = None

    def _predict(self, frame, offset=(0, 0), only_ball=False):
        import cv2
        import numpy as np

        height, width = frame.shape[:2]
        ratio = min(self.size / height, self.size / width)
        scaled = cv2.resize(frame, (max(1, int(width * ratio)), max(1, int(height * ratio))))
        image = np.full((self.size, self.size, 3), 114, dtype=np.uint8)
        image[: scaled.shape[0], : scaled.shape[1]] = scaled
        tensor = np.ascontiguousarray(image.transpose(2, 0, 1), dtype=np.float32)[None]
        started = time.perf_counter()
        raw = self.session.run(None, {self.input_name: tensor})[0]
        self.inference_seconds += time.perf_counter() - started
        self.inference_calls += 1
        predictions = raw[0].copy()
        if self._grids is None:
            positions, strides = [], []
            for stride in (8, 16, 32):
                grid_y, grid_x = np.mgrid[: self.size // stride, : self.size // stride]
                grid = np.column_stack((grid_x.ravel(), grid_y.ravel()))
                positions.append(grid)
                strides.append(np.full((len(grid), 1), stride))
            self._grids = (np.concatenate(positions), np.concatenate(strides))
        grids, strides = self._grids
        if predictions.shape != (len(grids), 85):
            raise ValueError("Неожиданная форма выхода YOLOX")
        centers = (predictions[:, :2] + grids) * strides
        sizes = np.exp(np.clip(predictions[:, 2:4], -20, 20)) * strides
        classes = predictions[:, 5:].argmax(axis=1)
        confidences = predictions[:, 4] * predictions[np.arange(len(predictions)), classes + 5]
        detections = []
        for class_id in (32,) if only_ball else (0, 32):
            threshold = self.ball_threshold if class_id == 32 else self.person_threshold
            for index in np.flatnonzero((classes == class_id) & (confidences >= threshold)):
                center, extent = centers[index] / ratio, sizes[index] / ratio
                x1, y1 = np.maximum(center - extent / 2, 0)
                x2, y2 = np.minimum(center + extent / 2, (width, height))
                if not all(math.isfinite(float(v)) for v in (x1, y1, x2, y2)) or x2 <= x1 or y2 <= y1:
                    continue
                detections.append(
                    {
                        "class_id": class_id,
                        "class_name": CLASS_NAMES[class_id],
                        "confidence": round(float(confidences[index]), 6),
                        "bbox": [
                            round(float(x1 + offset[0]), 3),
                            round(float(y1 + offset[1]), 3),
                            round(float(x2 + offset[0]), 3),
                            round(float(y2 + offset[1]), 3),
                        ],
                        "observed": True,
                        "interpolated": False,
                    }
                )
        return detections

    def detect_frame(self, frame):
        if frame is None or len(frame.shape) != 3 or frame.shape[2] != 3 or min(frame.shape[:2]) <= 0:
            raise ValueError("Нужен непустой BGR-кадр с тремя каналами")
        detections = self._predict(frame)
        if self.strategy == "tiles":
            height, width = frame.shape[:2]
            # Overlapping high-detail views retain the sky/air area: no floor mask.
            for y0 in (0, int(height * 0.4)):
                for x0 in (0, int(width * 0.4)):
                    tile = frame[
                        y0 : min(height, y0 + math.ceil(height * 0.6)), x0 : min(width, x0 + math.ceil(width * 0.6))
                    ]
                    detections.extend(self._predict(tile, (x0, y0), only_ball=True))
        return nms(detections)


def _peak_rss_mib():
    try:
        import resource
        import sys

        value = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
        return round(value / (1024 * 1024 if sys.platform == "darwin" else 1024), 3)
    except (ImportError, OSError):
        return None


def scan_segment(
    video_path,
    start,
    end,
    sample_fps=5.0,
    strategy="fullframe",
    device="auto",
    cancel_event=None,
    progress=None,
    detector=None,
    model_id="yolox-tiny",
):
    """Bounded real inference over [start,end); PTS belongs to the original file.

    No event type, outcome, team, player identity or metric court coordinate is
    inferred. Each segment's IoU IDs are intentionally scoped to that segment.
    """
    if not all(math.isfinite(float(v)) for v in (start, end, sample_fps)):
        raise ValueError("Диапазон и частота анализа должны быть конечными числами")
    if start < 0 or end <= start or end - start > MAX_SEGMENT_SECONDS or not 0.1 <= sample_fps <= 60:
        raise ValueError("Анализируйте сегменты до 60 секунд, с частотой от 0.1 до 60 FPS")
    import cv2
    from .media import probe

    metadata = probe(video_path, cancel=cancel_event)
    if start >= metadata["duration"] or end > metadata["duration"] + 0.01:
        raise ValueError("Сегмент выходит за границы исходного видео")
    detector = detector or YoloXDetector(model_id=model_id, device=device, strategy=strategy)
    tracker = IoUTracker()
    frames, source_fps, decoding_seconds = [], metadata["fps"], 0.0
    capture = cv2.VideoCapture(str(video_path))
    if not capture.isOpened():
        capture.release()
        raise ValueError("OpenCV не открыл видео. Проверьте кодек FFmpeg или создайте H.264-прокси")
    started = time.perf_counter()
    initial_inference = detector.inference_seconds
    initial_calls = detector.inference_calls
    next_sample, previous_pts = float(start), -1.0
    try:
        if start:
            capture.set(cv2.CAP_PROP_POS_MSEC, start * 1000)
        while True:
            if cancel_event is not None and cancel_event.is_set():
                raise InterruptedError("Анализ сегмента прерван; предыдущие контрольные точки сохранены")
            tick = time.perf_counter()
            grabbed = capture.grab()
            pts = capture.get(cv2.CAP_PROP_POS_MSEC) / 1000 if grabbed else 0
            decoding_seconds += time.perf_counter() - tick
            if not grabbed:
                break
            timestamp_source = "video_pts"
            if not math.isfinite(pts) or pts <= previous_pts:
                if not source_fps:
                    raise ValueError("Источник не предоставляет упорядоченные таймкоды")
                pts = (capture.get(cv2.CAP_PROP_POS_FRAMES) - 1) / source_fps
                timestamp_source = "estimated_frame_index"
            previous_pts = pts
            if pts >= end - 1e-7:
                break
            if pts + 1e-7 < next_sample:
                continue
            tick = time.perf_counter()
            ok, frame = capture.retrieve()
            decoding_seconds += time.perf_counter() - tick
            if not ok:
                raise ValueError("Ошибка декодирования выбранного кадра")
            detections = tracker.update(detector.detect_frame(frame), pts)
            frames.append(
                {
                    "time": round(pts, 6),
                    "timestamp_source": timestamp_source,
                    "width": int(frame.shape[1]),
                    "height": int(frame.shape[0]),
                    "track_scope": f"segment:{start:.6f}:{end:.6f}",
                    "detections": detections,
                }
            )
            next_sample = pts + 1 / sample_fps
            if progress:
                progress(min(1.0, max(0.0, (pts - start) / (end - start))))
        if not frames:
            raise ValueError("В сегменте не удалось получить ни одного кадра")
    finally:
        capture.release()
    elapsed = time.perf_counter() - started
    if progress:
        progress(1.0)
    return {
        "frames": frames,
        "model": detector.manifest,
        "coordinate_system": "video_pixels",
        "actions_inferred": False,
        "runtime": {
            **detector.runtime,
            "strategy": detector.strategy,
            "sample_fps": sample_fps,
            "frames_analyzed": len(frames),
            "elapsed_seconds": round(elapsed, 6),
            "inference_seconds": round(detector.inference_seconds - initial_inference, 6),
            "inference_calls": detector.inference_calls - initial_calls,
            "decode_seconds": round(decoding_seconds, 6),
            "peak_process_rss_mib": _peak_rss_mib(),
            "effective_processing_fps": round(len(frames) / elapsed, 3) if elapsed else None,
        },
    }
