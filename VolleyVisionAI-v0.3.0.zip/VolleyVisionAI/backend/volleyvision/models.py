from datetime import datetime, timezone

from sqlalchemy import JSON, Boolean, Float, ForeignKey, Index, Integer, String, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from .db import Base


def now():
    return datetime.now(timezone.utc).isoformat()


class Team(Base):
    __tablename__ = "teams"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(120))


class Player(Base):
    __tablename__ = "players"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(120))
    role: Mapped[str] = mapped_column(default="Не указано")


class Membership(Base):
    __tablename__ = "memberships"
    id: Mapped[int] = mapped_column(primary_key=True)
    player_id: Mapped[int] = mapped_column(ForeignKey("players.id"))
    team_id: Mapped[int] = mapped_column(ForeignKey("teams.id"))
    number: Mapped[str | None] = mapped_column(nullable=True)
    since: Mapped[str | None] = mapped_column(nullable=True)
    until: Mapped[str | None] = mapped_column(nullable=True)


class Match(Base):
    __tablename__ = "matches"
    id: Mapped[int] = mapped_column(primary_key=True)
    home_id: Mapped[int] = mapped_column(ForeignKey("teams.id"))
    away_id: Mapped[int] = mapped_column(ForeignKey("teams.id"))
    date: Mapped[str] = mapped_column(String(30))
    title: Mapped[str] = mapped_column(String(180), default="")


class Roster(Base):
    __tablename__ = "rosters"
    __table_args__ = (UniqueConstraint("match_id", "player_id"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    match_id: Mapped[int] = mapped_column(ForeignKey("matches.id"))
    team_id: Mapped[int] = mapped_column(ForeignKey("teams.id"))
    player_id: Mapped[int] = mapped_column(ForeignKey("players.id"))
    number: Mapped[str | None] = mapped_column(nullable=True)
    libero: Mapped[bool] = mapped_column(Boolean, default=False)


class Set(Base):
    __tablename__ = "sets"
    __table_args__ = (UniqueConstraint("match_id", "number"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    match_id: Mapped[int] = mapped_column(ForeignKey("matches.id"))
    number: Mapped[int] = mapped_column(Integer)
    initial_home: Mapped[int] = mapped_column(default=0)
    initial_away: Mapped[int] = mapped_column(default=0)


class Video(Base):
    __tablename__ = "videos"
    __table_args__ = (Index("uq_video_match_sha256", "match_id", "sha256", unique=True),)
    id: Mapped[int] = mapped_column(primary_key=True)
    match_id: Mapped[int] = mapped_column(ForeignKey("matches.id"))
    name: Mapped[str] = mapped_column(String(255))
    path: Mapped[str] = mapped_column(String(255))
    sha256: Mapped[str] = mapped_column(String(64))
    size: Mapped[int] = mapped_column(Integer)
    duration: Mapped[float] = mapped_column(Float)
    width: Mapped[int] = mapped_column(Integer)
    height: Mapped[int] = mapped_column(Integer)
    fps: Mapped[float] = mapped_column(Float)
    codec: Mapped[str] = mapped_column(String(50))
    offset: Mapped[float | None] = mapped_column(Float, nullable=True)
    position: Mapped[int] = mapped_column(default=0)
    proxy_path: Mapped[str | None] = mapped_column(nullable=True)
    metadata_json: Mapped[dict] = mapped_column(JSON, default=dict, server_default="{}")


class Rally(Base):
    __tablename__ = "rallies"
    id: Mapped[int] = mapped_column(primary_key=True)
    match_id: Mapped[int] = mapped_column(ForeignKey("matches.id"))
    set_id: Mapped[int] = mapped_column(ForeignKey("sets.id"))
    video_id: Mapped[int] = mapped_column(ForeignKey("videos.id"))
    start: Mapped[float] = mapped_column(Float)
    end: Mapped[float] = mapped_column(Float)
    serving_team_id: Mapped[int | None] = mapped_column(ForeignKey("teams.id"), nullable=True)
    winner_team_id: Mapped[int | None] = mapped_column(ForeignKey("teams.id"), nullable=True)
    rotation: Mapped[int | None] = mapped_column(nullable=True)
    status: Mapped[str] = mapped_column(default="manual")
    revision: Mapped[int] = mapped_column(default=1, server_default="1")
    __mapper_args__ = {"version_id_col": revision, "version_id_generator": False}


class Event(Base):
    __tablename__ = "events"
    id: Mapped[int] = mapped_column(primary_key=True)
    match_id: Mapped[int] = mapped_column(ForeignKey("matches.id"))
    rally_id: Mapped[int] = mapped_column(ForeignKey("rallies.id"))
    video_id: Mapped[int] = mapped_column(ForeignKey("videos.id"))
    time: Mapped[float] = mapped_column(Float)
    kind: Mapped[str] = mapped_column(String(40))
    subtype: Mapped[str | None] = mapped_column(nullable=True)
    team_id: Mapped[int] = mapped_column(ForeignKey("teams.id"))
    player_id: Mapped[int | None] = mapped_column(ForeignKey("players.id"), nullable=True)
    quality: Mapped[int | None] = mapped_column(nullable=True)
    outcome: Mapped[str | None] = mapped_column(nullable=True)
    zone_from: Mapped[int | None] = mapped_column(nullable=True)
    zone_to: Mapped[int | None] = mapped_column(nullable=True)
    rotation: Mapped[int | None] = mapped_column(nullable=True)
    status: Mapped[str] = mapped_column(default="manual")
    source: Mapped[str] = mapped_column(default="manual")
    confidence: Mapped[float | None] = mapped_column(Float, nullable=True)
    prediction: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    model_version: Mapped[str | None] = mapped_column(nullable=True)
    deleted: Mapped[bool] = mapped_column(default=False)
    revision: Mapped[int] = mapped_column(default=1)
    # SQLAlchemy includes the previous revision in UPDATE predicates.
    __mapper_args__ = {"version_id_col": revision, "version_id_generator": False}
    updated_at: Mapped[str] = mapped_column(default=now)


class Correction(Base):
    __tablename__ = "corrections"
    id: Mapped[int] = mapped_column(primary_key=True)
    entity: Mapped[str] = mapped_column()
    entity_id: Mapped[int] = mapped_column()
    before: Mapped[dict] = mapped_column(JSON)
    after: Mapped[dict] = mapped_column(JSON)
    created_at: Mapped[str] = mapped_column(default=now)


class Job(Base):
    __tablename__ = "jobs"
    id: Mapped[int] = mapped_column(primary_key=True)
    video_id: Mapped[int] = mapped_column(ForeignKey("videos.id"))
    kind: Mapped[str] = mapped_column()
    status: Mapped[str] = mapped_column(default="queued")
    progress: Mapped[float] = mapped_column(Float, default=0)
    checkpoint: Mapped[dict] = mapped_column(JSON, default=dict)
    error: Mapped[str | None] = mapped_column(nullable=True)
    created_at: Mapped[str] = mapped_column(default=now)


class Clip(Base):
    __tablename__ = "clips"
    id: Mapped[int] = mapped_column(primary_key=True)
    match_id: Mapped[int] = mapped_column(ForeignKey("matches.id"))
    name: Mapped[str] = mapped_column()
    path: Mapped[str] = mapped_column()
    event_ids: Mapped[list] = mapped_column(JSON)
