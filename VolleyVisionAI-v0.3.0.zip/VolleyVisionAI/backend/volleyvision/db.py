import os
from pathlib import Path

from sqlalchemy import create_engine, event
from sqlalchemy.orm import DeclarativeBase, sessionmaker

ROOT = Path(__file__).resolve().parents[2]
DATA = Path(os.environ.get("VOLLEYVISION_DATA", ROOT / "data")).resolve()
DATA.mkdir(parents=True, exist_ok=True)
for folder in ("originals", "derived", "exports"):
    (DATA / folder).mkdir(exist_ok=True)
engine = create_engine(f"sqlite:///{DATA / 'volleyvision.db'}", connect_args={"check_same_thread": False})


@event.listens_for(engine, "connect")
def setup_sqlite(connection, _):
    connection.execute("PRAGMA foreign_keys=ON")
    connection.execute("PRAGMA journal_mode=WAL")
    connection.execute("PRAGMA busy_timeout=10000")


class Base(DeclarativeBase):
    pass


Session = sessionmaker(engine, expire_on_commit=False)


def session():
    with Session() as db:
        yield db
