import csv
import io
import shutil
from contextlib import asynccontextmanager

import httpx
from fastapi import Depends, FastAPI, File, HTTPException, UploadFile
from fastapi.responses import FileResponse, JSONResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from openpyxl import Workbook
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session as DBSession
from sqlalchemy.orm.exc import StaleDataError

from . import jobs, media, schemas as s
from .db import DATA, ROOT, session
from .access import AccessMiddleware
from .models import Clip, Correction, Event, Job, Match, Membership, Player, Rally, Roster, Set, Team, Video, now
from .stats import calculate


def serialize(obj):
    return {c.name: getattr(obj, c.name) for c in obj.__table__.columns}


def begin_read_snapshot(db):
    # Python sqlite's legacy transaction mode does not BEGIN for SELECT.
    # Explicitly pin every multi-query response to one WAL snapshot.
    connection = db.connection()
    if not connection.connection.driver_connection.in_transaction:
        connection.exec_driver_sql("BEGIN")


def get(db, cls, ident):
    obj = db.get(cls, ident)
    if obj is None:
        raise HTTPException(404, "Запись не найдена")
    return obj


def team_in(match, tid):
    if tid is not None and tid not in (match.home_id, match.away_id):
        raise HTTPException(422, "Команда не участвует в матче")


def add(db, cls, **fields):
    obj = cls(**fields)
    db.add(obj)
    db.commit()
    db.refresh(obj)
    return serialize(obj)


@asynccontextmanager
async def lifespan(app):
    jobs.start()
    try:
        yield
    finally:
        jobs.stop()


app = FastAPI(title="VolleyVision AI", version="0.3.0", lifespan=lifespan)


app.add_middleware(AccessMiddleware)


@app.exception_handler(ValueError)
async def invalid(request, exc):
    return JSONResponse({"detail": str(exc)}, status_code=422)


@app.exception_handler(IntegrityError)
async def integrity(request, exc):
    return JSONResponse({"detail": "Конфликт данных: проверьте уникальность и связи"}, status_code=409)


@app.exception_handler(StaleDataError)
async def concurrent_edit(request, exc):
    return JSONResponse({"detail": "Событие изменено другим запросом. Обновите данные."}, status_code=409)


@app.exception_handler(httpx.HTTPError)
async def network_error(request, exc):
    return JSONResponse(
        {"detail": "Яндекс Диск недоступен. Проверьте ссылку и доступ к сети или загрузите видео с компьютера."},
        status_code=502,
    )


@app.get("/api/health")
def health(db: DBSession = Depends(session)):
    db.execute(select(Team).limit(1))
    return {
        "status": "ok",
        "ffmpeg": bool(shutil.which("ffmpeg")),
        "ffprobe": bool(shutil.which("ffprobe")),
        "ai": "not_installed",
        "version": "0.3.0",
    }


@app.get("/api/teams")
def teams(db: DBSession = Depends(session)):
    return [serialize(t) for t in db.scalars(select(Team).order_by(Team.id))]


@app.post("/api/teams", status_code=201)
def create_team(body: s.TeamIn, db: DBSession = Depends(session)):
    return add(db, Team, **body.model_dump())


@app.get("/api/players")
def players(db: DBSession = Depends(session)):
    return [
        dict(
            serialize(p),
            memberships=[serialize(m) for m in db.scalars(select(Membership).where(Membership.player_id == p.id))],
        )
        for p in db.scalars(select(Player))
    ]


@app.post("/api/players", status_code=201)
def create_player(body: s.PlayerIn, db: DBSession = Depends(session)):
    get(db, Team, body.team_id)
    p = Player(name=body.name, role=body.role)
    db.add(p)
    db.flush()
    db.add(Membership(player_id=p.id, team_id=body.team_id, number=body.number))
    db.commit()
    return serialize(p)


@app.get("/api/matches")
def matches(db: DBSession = Depends(session)):
    return [serialize(m) for m in db.scalars(select(Match).order_by(Match.id.desc()))]


@app.post("/api/matches", status_code=201)
def create_match(body: s.MatchIn, db: DBSession = Depends(session)):
    get(db, Team, body.home_id)
    get(db, Team, body.away_id)
    m = Match(**body.model_dump())
    db.add(m)
    db.flush()
    for member in db.scalars(
        select(Membership).where(Membership.team_id.in_([m.home_id, m.away_id]), Membership.until.is_(None))
    ):
        db.add(Roster(match_id=m.id, team_id=member.team_id, player_id=member.player_id, number=member.number))
    db.add(Set(match_id=m.id, number=1))
    db.commit()
    return serialize(m)


@app.get("/api/matches/{mid}")
def match_detail(mid: int, db: DBSession = Depends(session)):
    begin_read_snapshot(db)
    m = get(db, Match, mid)
    result = serialize(m)
    for key, cls in [("videos", Video), ("sets", Set), ("rallies", Rally), ("roster", Roster), ("clips", Clip)]:
        result[key] = [serialize(x) for x in db.scalars(select(cls).where(cls.match_id == mid))]
    result["events"] = [
        serialize(e)
        for e in db.scalars(
            select(Event).where(Event.match_id == mid, Event.deleted.is_(False)).order_by(Event.video_id, Event.time)
        )
    ]
    return result


@app.post("/api/matches/{mid}/roster", status_code=201)
def create_roster(mid: int, body: s.RosterIn, db: DBSession = Depends(session)):
    team_in(get(db, Match, mid), body.team_id)
    get(db, Player, body.player_id)
    return add(db, Roster, match_id=mid, **body.model_dump())


@app.post("/api/matches/{mid}/sets", status_code=201)
def create_set(mid: int, body: s.SetIn, db: DBSession = Depends(session)):
    get(db, Match, mid)
    return add(db, Set, match_id=mid, **body.model_dump())


def validate_rally(db, mid, body, exclude_id=None):
    match = get(db, Match, mid)
    video = get(db, Video, body.video_id)
    if video.match_id != mid or get(db, Set, body.set_id).match_id != mid:
        raise HTTPException(422, "Видео и партия должны принадлежать матчу")
    if body.end > video.duration + 0.001:
        raise HTTPException(422, "Розыгрыш выходит за пределы видео")
    team_in(match, body.serving_team_id)
    team_in(match, body.winner_team_id)
    overlapping = select(Rally.id).where(
        Rally.video_id == body.video_id, Rally.start < body.end, Rally.end > body.start
    )
    if exclude_id is not None:
        overlapping = overlapping.where(Rally.id != exclude_id)
    if db.scalar(overlapping.limit(1)) is not None:
        raise HTTPException(409, "Этот интервал пересекается с существующим розыгрышем. Измените его границы.")


@app.post("/api/matches/{mid}/rallies", status_code=201)
def create_rally(mid: int, body: s.RallyIn, db: DBSession = Depends(session)):
    validate_rally(db, mid, body)
    return add(db, Rally, match_id=mid, **body.model_dump())


@app.put("/api/rallies/{rid}")
def edit_rally(rid: int, body: s.RallyEdit, db: DBSession = Depends(session)):
    rally = get(db, Rally, rid)
    if rally.revision != body.revision:
        raise HTTPException(409, "Розыгрыш уже изменён. Обновите данные.")
    validate_rally(db, rally.match_id, body, exclude_id=rid)
    events = list(db.scalars(select(Event).where(Event.rally_id == rid, Event.deleted.is_(False))))
    if any(e.video_id != body.video_id or not body.start <= e.time <= body.end for e in events):
        raise HTTPException(422, "Существующие события выходят за новые границы розыгрыша")
    before = serialize(rally)
    for k, v in body.model_dump(exclude={"revision"}).items():
        setattr(rally, k, v)
    rally.revision += 1
    db.add(Correction(entity="rally", entity_id=rid, before=before, after=serialize(rally)))
    db.commit()
    return serialize(rally)


def validate_event(db, mid, body):
    match = get(db, Match, mid)
    rally = get(db, Rally, body.rally_id)
    if rally.match_id != mid or not rally.start <= body.time <= rally.end:
        raise HTTPException(422, "Таймкод должен входить в розыгрыш этого матча")
    team_in(match, body.team_id)
    if body.player_id is not None:
        roster = db.scalar(
            select(Roster).where(
                Roster.match_id == mid, Roster.player_id == body.player_id, Roster.team_id == body.team_id
            )
        )
        if roster is None:
            raise HTTPException(422, "Игрок отсутствует в составе этой команды на матч")
    return rally


@app.post("/api/matches/{mid}/events", status_code=201)
def create_event(mid: int, body: s.EventIn, db: DBSession = Depends(session)):
    rally = validate_event(db, mid, body)
    return add(db, Event, match_id=mid, video_id=rally.video_id, **body.model_dump())


@app.put("/api/events/{eid}")
def edit_event(eid: int, body: s.EventEdit, db: DBSession = Depends(session)):
    e = get(db, Event, eid)
    if e.deleted or e.revision != body.revision:
        raise HTTPException(409, "Событие уже изменено. Обновите данные.")
    rally = validate_event(db, e.match_id, body)
    before = serialize(e)
    for key, val in body.model_dump(exclude={"revision"}).items():
        setattr(e, key, val)
    e.video_id = rally.video_id
    e.status, e.source, e.updated_at = "corrected", "manual", now()
    e.revision += 1
    db.add(Correction(entity="event", entity_id=e.id, before=before, after=serialize(e)))
    db.commit()
    return serialize(e)


@app.delete("/api/events/{eid}")
def delete_event(eid: int, revision: int, db: DBSession = Depends(session)):
    e = get(db, Event, eid)
    if e.revision != revision or e.deleted:
        raise HTTPException(409, "Событие уже изменено")
    before = serialize(e)
    e.deleted, e.updated_at = True, now()
    e.revision += 1
    db.add(Correction(entity="event", entity_id=e.id, before=before, after=serialize(e)))
    db.commit()
    return {"ok": True}


@app.get("/api/events/{eid}/history")
def history(eid: int, db: DBSession = Depends(session)):
    get(db, Event, eid)
    return [
        serialize(x)
        for x in db.scalars(
            select(Correction).where(Correction.entity == "event", Correction.entity_id == eid).order_by(Correction.id)
        )
    ]


def match_stats(db, mid):
    begin_read_snapshot(db)
    m = get(db, Match, mid)
    events = list(db.scalars(select(Event).where(Event.match_id == mid)))
    rallies = list(db.scalars(select(Rally).where(Rally.match_id == mid)))
    sets = list(db.scalars(select(Set).where(Set.match_id == mid).order_by(Set.number)))
    return calculate(events, rallies, m, sets)


@app.get("/api/matches/{mid}/stats")
def stats(mid: int, db: DBSession = Depends(session)):
    return match_stats(db, mid)


def register_video(db, mid, name, stored):
    target, digest, size, metadata = stored
    existing = db.scalar(select(Video).where(Video.match_id == mid, Video.sha256 == digest))
    if existing:
        target.unlink(missing_ok=True)
        raise HTTPException(409, "Этот видеофайл уже добавлен к матчу")
    video = Video(
        match_id=mid, name=name[:255], path=str(target.relative_to(DATA)), sha256=digest, size=size, **metadata
    )
    try:
        db.add(video)
        db.commit()
    except Exception:
        db.rollback()
        target.unlink(missing_ok=True)
        raise
    return serialize(video)


@app.post("/api/matches/{mid}/videos", status_code=201)
def upload(mid: int, file: UploadFile = File(...), db: DBSession = Depends(session)):
    get(db, Match, mid)
    chunks = iter(lambda: file.file.read(1024 * 1024), b"")
    return register_video(
        db, mid, file.filename or "video.mp4", media.store_stream(chunks, file.filename or "video.mp4")
    )


@app.put("/api/videos/{vid}")
def edit_video(vid: int, body: s.VideoEdit, db: DBSession = Depends(session)):
    video = get(db, Video, vid)
    video.position, video.offset = body.position, body.offset
    db.commit()
    return serialize(video)


@app.get("/api/videos/{vid}/stream")
def stream_video(vid: int, original: bool = False, db: DBSession = Depends(session)):
    video = get(db, Video, vid)
    path = DATA / video.path
    if not original and video.proxy_path and (DATA / video.proxy_path).is_file():
        path = DATA / video.proxy_path
    if not path.is_file():
        raise HTTPException(404, "Видеофайл отсутствует. Восстановите исходники из резервной копии.")
    return FileResponse(path)


@app.post("/api/yandex/list")
def list_yandex(body: s.YandexIn):
    return media.yandex_info(body.public_key, body.path)


@app.post("/api/matches/{mid}/yandex", status_code=201)
def import_yandex(mid: int, body: s.YandexIn, db: DBSession = Depends(session)):
    get(db, Match, mid)
    name, stored = media.yandex_download(body.public_key, body.path)
    return register_video(db, mid, name, stored)


@app.get("/api/jobs")
def list_jobs(db: DBSession = Depends(session)):
    return [serialize(x) for x in db.scalars(select(Job).order_by(Job.id.desc()))]


@app.post("/api/videos/{vid}/proxy", status_code=201)
def proxy(vid: int, db: DBSession = Depends(session)):
    get(db, Video, vid)
    existing = db.scalar(select(Job).where(Job.video_id == vid, Job.status.in_(["queued", "running"])))
    if existing:
        return serialize(existing)
    return add(db, Job, video_id=vid, kind="proxy")


@app.post("/api/jobs/{jid}/retry")
def retry(jid: int, db: DBSession = Depends(session)):
    job = get(db, Job, jid)
    if job.status not in {"failed", "interrupted"}:
        raise HTTPException(409, "Эта задача не требует повторного запуска")
    job.status, job.error = "queued", None
    db.commit()
    return serialize(job)


@app.post("/api/matches/{mid}/clips", status_code=201)
def create_clip(mid: int, body: s.ClipIn, db: DBSession = Depends(session)):
    get(db, Match, mid)
    events = [get(db, Event, eid) for eid in dict.fromkeys(body.event_ids)]
    if any(e.match_id != mid or e.deleted for e in events):
        raise HTTPException(422, "Выберите существующие события этого матча")
    videos = {e.video_id: get(db, Video, e.video_id) for e in events}
    path = media.export_clip(events, videos, body.before, body.after)
    clip = Clip(match_id=mid, name=body.name, path=path, event_ids=[e.id for e in events])
    try:
        db.add(clip)
        db.commit()
    except Exception:
        db.rollback()
        shutil.rmtree((DATA / path).parent, ignore_errors=True)
        raise
    return serialize(clip)


@app.get("/api/clips/{cid}/download")
def download_clip(cid: int, db: DBSession = Depends(session)):
    clip = get(db, Clip, cid)
    path = DATA / clip.path
    if not path.is_file():
        raise HTTPException(404, "Файл подборки отсутствует. Создайте её заново или восстановите из резервной копии.")
    return FileResponse(path, media_type="video/mp4", filename=f"clip-{cid}.mp4")


EXPORT_FIELDS = [
    "id",
    "video_id",
    "rally_id",
    "time",
    "kind",
    "team_id",
    "player_id",
    "outcome",
    "quality",
    "zone_from",
    "zone_to",
    "rotation",
    "status",
    "source",
    "confidence",
]


def safe_cell(value):
    if isinstance(value, str) and value[:1] in ("=", "+", "-", "@"):
        return "'" + value
    return value


@app.get("/api/matches/{mid}/export/{fmt}")
def export(mid: int, fmt: str, db: DBSession = Depends(session)):
    detail = match_detail(mid, db)
    statistics = match_stats(db, mid)
    if fmt == "json":
        return JSONResponse(
            {"match": detail, "statistics": statistics},
            headers={"Content-Disposition": f'attachment; filename="match-{mid}.json"'},
        )
    rows = [[safe_cell(e[k]) for k in EXPORT_FIELDS] for e in detail["events"]]
    if fmt == "csv":
        out = io.StringIO(newline="")
        writer = csv.writer(out)
        writer.writerow(EXPORT_FIELDS)
        writer.writerows(rows)
        return StreamingResponse(
            iter([("\ufeff" + out.getvalue()).encode("utf-8")]),
            media_type="text/csv",
            headers={"Content-Disposition": f'attachment; filename="events-{mid}.csv"'},
        )
    if fmt == "xlsx":
        wb = Workbook()
        ws = wb.active
        ws.title = "События"
        ws.append(EXPORT_FIELDS)
        for row in rows:
            ws.append(row)
        ws = wb.create_sheet("Статистика")
        ws.append(
            ["Команда ID", "Игрок ID", "Действие", "Попытки", "Неизвестных исходов", "% выигрыша", "Эффективность %"]
        )
        for tid, team in statistics["teams"].items():
            for pid, stats in {"team": team, **team["players"]}.items():
                for kind in ("serve", "attack", "reception", "block", "dig", "set"):
                    v = stats[kind]
                    ws.append(
                        [tid, pid, kind, v["attempts"], v["unknown_outcomes"], v.get("win_pct"), v.get("efficiency")]
                    )
        wb.create_sheet("Методика").append(
            [
                "См. METRICS.md: VolleyVision v1.1. Основная статистика исключает неподтверждённые события; null означает недостаток данных."
            ]
        )
        out = io.BytesIO()
        wb.save(out)
        return StreamingResponse(
            iter([out.getvalue()]),
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={"Content-Disposition": f'attachment; filename="match-{mid}.xlsx"'},
        )
    raise HTTPException(404, "Поддерживаются json, csv, xlsx")


# Routers must precede the catch-all frontend mount.
from . import imports, setup, analysis_models, analysis  # noqa: E402,F401

app.include_router(imports.router)
app.include_router(setup.router)
app.include_router(analysis.router)

frontend = ROOT / "frontend" / "dist"
if frontend.is_dir():
    app.mount("/", StaticFiles(directory=frontend, html=True), name="frontend")
