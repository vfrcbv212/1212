"""Fail-closed access profiles for local use and a configured private Tailscale proxy.

The remote upstream path is a server-side capability, never an application URL.
Serve strips/replaces identity headers; the secret path also prevents a caller
from impersonating Serve merely by sending its headers directly to localhost.
"""

import ipaddress
import json
import os
import re
import secrets
from dataclasses import dataclass
from pathlib import Path

from starlette.responses import JSONResponse

LOCAL_HOSTS = {"127.0.0.1", "localhost", "[::1]", "testserver"}
PROXY_PREFIX = "/__vv_upstream_"
PROTECTED_HEADERS = {
    "host",
    "origin",
    "x-forwarded-host",
    "x-forwarded-proto",
    "tailscale-user-login",
    "tailscale-funnel-request",
}


def validate_hostname(value):
    if not isinstance(value, str):
        raise ValueError("Hostname должен быть строкой")
    hostname = value.strip().lower()
    labels = hostname.split(".")
    if len(labels) < 3 or not hostname.endswith(".ts.net") or len(hostname) > 253:
        raise ValueError("Нужен полный HTTPS-hostname устройства Tailscale вида pc.tailnet.ts.net, без схемы и порта")
    if any(re.fullmatch(r"[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?", label) is None for label in labels):
        raise ValueError("Недопустимое имя устройства Tailscale")
    return hostname


def validate_login(value):
    if not isinstance(value, str):
        raise ValueError("Tailscale User-Login должен быть строкой")
    login = value.strip().casefold()
    if not login or len(login) > 320 or any(ord(char) < 33 or ord(char) > 126 or char in ",*" for char in login):
        raise ValueError("Укажите точный Tailscale User-Login без пробелов, wildcard и управляющих символов")
    return login


@dataclass(frozen=True)
class AccessConfig:
    profile: str = "local"
    hostname: str | None = None
    allowed_logins: frozenset[str] = frozenset()
    upstream_token: str | None = None

    @property
    def public_origin(self):
        return f"https://{self.hostname}" if self.profile == "remote-private" else "http://localhost:8765"

    @property
    def upstream_prefix(self):
        return f"{PROXY_PREFIX}{self.upstream_token}"


def config_path():
    from .db import DATA

    return DATA / "remote-private.json"


def load_config(profile=None):
    profile = profile or os.environ.get("VOLLEYVISION_PROFILE", "local")
    if profile == "local":
        return AccessConfig()
    if profile != "remote-private":
        raise ValueError("Профиль должен быть local или remote-private")
    path = config_path()
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, ValueError) as exc:
        raise ValueError("Приватный профиль не настроен. См. docs/REMOTE_PRIVATE.md и remote-private.ps1") from exc
    if not isinstance(payload, dict) or payload.get("format") != 1:
        raise ValueError("Неподдерживаемая конфигурация приватного доступа")
    hostname = validate_hostname(payload.get("hostname", ""))
    logins = payload.get("allowed_logins")
    if not isinstance(logins, list) or not logins or any(not isinstance(login, str) for login in logins):
        raise ValueError("Приватный профиль требует непустой список allowed_logins")
    allowed = frozenset(validate_login(login) for login in logins)
    token = payload.get("upstream_token", "")
    if not isinstance(token, str) or re.fullmatch("[0-9a-f]{64}", token) is None:
        raise ValueError("Приватный профиль требует серверный upstream token; повторите настройку")
    return AccessConfig(profile, hostname, allowed, token)


def configure(hostname, allowed_logins):
    """Persist local setup only; this function never starts or publishes a tunnel."""
    import tempfile

    hostname = validate_hostname(hostname)
    allowed = sorted({validate_login(login) for login in allowed_logins})
    if not allowed:
        raise ValueError("Укажите хотя бы один разрешённый Tailscale User-Login")
    path = config_path()
    token = secrets.token_hex(32)
    if path.exists():
        # Preserve a working capability on restart / allowlist edit. Do not blindly
        # replace an unknown or corrupt file which may contain operator settings.
        previous = load_config("remote-private")
        token = previous.upstream_token
    descriptor, name = tempfile.mkstemp(prefix="remote-private-", suffix=".tmp", dir=path.parent)
    temporary = Path(name)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8") as out:
            json.dump({"format": 1, "hostname": hostname, "allowed_logins": allowed, "upstream_token": token}, out)
            out.flush()
            os.fsync(out.fileno())
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)
    return load_config("remote-private")


def _loopback_peer(scope):
    try:
        return ipaddress.ip_address(scope.get("client", ("", 0))[0]).is_loopback
    except (ValueError, TypeError, IndexError):
        return False


def _headers(scope):
    values = {}
    for key, value in scope.get("headers", []):
        key = key.decode("latin1").lower()
        if key in PROTECTED_HEADERS and key in values:
            return None
        values[key] = value.decode("latin1")
    return values


def _host(value):
    if value.startswith("["):
        end = value.find("]")
        return value[: end + 1].lower() if end >= 0 else ""
    return value.split(":", 1)[0].lower()


class AccessMiddleware:
    def __init__(self, app, config=None):
        self.app = app
        self.config = config or load_config()

    async def __call__(self, scope, receive, send):
        if scope["type"] not in {"http", "websocket"}:
            return await self.app(scope, receive, send)
        headers = _headers(scope)
        error = self.check(scope, headers)
        if self.config.profile == "remote-private":
            prefix = self.config.upstream_prefix
            candidate = scope.get("path", "")[1:].partition("/")[0]
            if candidate.isascii() and secrets.compare_digest(candidate, prefix[1:]):
                # Strip even on denied responses so access logs cannot reveal the
                # upstream capability for an authenticated but disallowed user.
                scope["path"] = scope["path"][len(prefix) :] or "/"
                scope["raw_path"] = scope["path"].encode("utf-8")
        if error:
            if scope["type"] == "websocket":
                return await send({"type": "websocket.close", "code": 1008})
            return await JSONResponse({"detail": error}, status_code=403)(scope, receive, send)
        if self.config.profile == "remote-private":
            scope["scheme"] = "https"
            scope.setdefault("state", {})["authenticated_login"] = headers["tailscale-user-login"].casefold()

        async def secured_send(message):
            if message["type"] == "http.response.start":
                message.setdefault("headers", []).extend(
                    [
                        (b"x-content-type-options", b"nosniff"),
                        (b"referrer-policy", b"same-origin"),
                        (b"cache-control", b"no-store"),
                    ]
                )
            await send(message)

        return await self.app(scope, receive, secured_send)

    def check(self, scope, headers):
        if headers is None:
            return "Повторяющиеся служебные заголовки запрещены"
        host = _host(headers.get("host", ""))
        origin = headers.get("origin")
        if self.config.profile == "local":
            if host not in LOCAL_HOSTS:
                return "Доступ только с localhost"
            if any(key.startswith(("tailscale-", "x-forwarded-")) or key == "forwarded" for key in headers):
                return "Заголовки внешнего прокси не разрешены в локальном профиле"
            if origin and origin not in {
                f"http://{host}:{port}" for host in ("localhost", "127.0.0.1") for port in (8765, 5173)
            }:
                return "Недопустимый Origin"
            if headers.get("sec-fetch-site") == "cross-site" and not origin:
                return "Запрос из постороннего сайта запрещён"
            return None
        prefix = self.config.upstream_prefix
        path = scope.get("path", "")
        path_prefix, _, _ = path[1:].partition("/")
        expected = prefix[1:]
        # The capability remains private to this OS account and tailscaled. It
        # protects the loopback endpoint even against forged identity headers.
        if not _loopback_peer(scope) or not path_prefix.isascii() or not secrets.compare_digest(path_prefix, expected):
            return "Приватный доступ разрешён только через настроенный HTTPS-прокси"
        if (
            headers.get("host", "").lower() not in {self.config.hostname, self.config.hostname + ":443"}
            or headers.get("x-forwarded-host", "").lower() != self.config.hostname
        ):
            return "Недопустимый адрес приватного приложения"
        if headers.get("x-forwarded-proto") != "https" or "tailscale-funnel-request" in headers:
            return "Требуется приватный HTTPS-доступ Tailscale Serve"
        login = headers.get("tailscale-user-login", "").casefold()
        if login not in self.config.allowed_logins:
            return "Пользователю не разрешён доступ к VolleyVision"
        if origin and origin != self.config.public_origin:
            return "Недопустимый Origin"
        if headers.get("sec-fetch-site") in {"cross-site", "same-site"} and not origin:
            return "Запрос из постороннего сайта запрещён"
        return None
