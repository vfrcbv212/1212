"""Event-derived volleyball metrics with explicit coverage and consistency checks.

A grade is not an inferred outcome, and a terminal action is not a second score
source. Raw values remain available for correction; invalid historical values
never silently become credible percentages.
"""

from collections import Counter, defaultdict

TRUSTED = {"manual", "confirmed", "corrected"}
KINDS = ("serve", "reception", "set", "attack", "block", "dig", "cover", "freeball", "error")
GRADED_KINDS = {"reception", "dig", "set"}
VALID_OUTCOMES = {
    "serve": {"ace", "error", "in_play"},
    "reception": {"error", "continued"},
    "set": {"error", "continued"},
    "attack": {"kill", "error", "blocked", "continued"},
    "block": {"point", "touch", "error", "continued"},
    "dig": {"error", "continued"},
    "cover": {"error", "continued"},
    "freeball": {"error", "continued"},
    "error": {"error"},
}


def rate(numerator, denominator):
    return round(numerator / denominator * 100, 2) if denominator else None


def grade_issue(event):
    """Classify old inconsistent data without changing or inferring a value."""
    quality = event.quality
    if quality is None:
        return None
    if isinstance(quality, bool) or not isinstance(quality, int) or not 0 <= quality <= 3:
        return "invalid"
    if (event.outcome == "error" and quality > 0) or (event.outcome == "continued" and quality == 0):
        return "conflict"
    return None


def summarize(events):
    events = list(events)
    counts = Counter(e.kind for e in events)
    result = {"events": len(events), "counts": {k: counts[k] for k in KINDS}}
    for kind in KINDS:
        group = [e for e in events if e.kind == kind]
        outcomes = Counter(e.outcome for e in group if e.outcome in VALID_OUTCOMES[kind])
        known = sum(outcomes.values())
        invalid_outcomes = sum(e.outcome is not None and e.outcome not in VALID_OUTCOMES[kind] for e in group)
        result[kind] = {
            "attempts": len(group),
            "known_outcomes": known,
            "unknown_outcomes": len(group) - known,
            "invalid_outcomes": invalid_outcomes,
            "outcome_coverage_pct": rate(known, len(group)),
            "outcomes": dict(outcomes),
        }
        if kind in {"serve", "attack"}:
            win = outcomes["ace" if kind == "serve" else "kill"]
            loss = outcomes["error"] + (outcomes["blocked"] if kind == "attack" else 0)
            # Known-only rates are explicitly separate from full-attempt rates.
            complete = known == len(group)
            result[kind].update(
                wins=win,
                errors=outcomes["error"],
                losses=loss,
                win_pct=rate(win, known) if complete else None,
                error_pct=rate(outcomes["error"], known) if complete else None,
                efficiency=rate(win - loss, known) if complete else None,
                known_win_pct=rate(win, known),
                known_efficiency=rate(win - loss, known),
            )
        if kind in GRADED_KINDS:
            qualities = [e.quality for e in group if e.quality is not None and grade_issue(e) is None]
            distribution = Counter(qualities)
            result[kind].update(
                graded=len(qualities),
                unknown_quality=sum(e.quality is None for e in group),
                invalid_quality=sum(grade_issue(e) == "invalid" for e in group),
                conflicting_quality=sum(grade_issue(e) == "conflict" for e in group),
                grade_coverage_pct=rate(len(qualities), len(group)),
                quality_counts={str(q): distribution[q] for q in range(4)},
                average=round(sum(qualities) / len(qualities), 3) if qualities else None,
                perfect_pct=rate(distribution[3], len(qualities)),
                positive_pct=rate(distribution[2] + distribution[3], len(qualities)),
            )
    return result


def _rally_rates(rallies, team_id, team_ids, receiving):
    observed = [r for r in rallies if (r.serving_team_id != team_id if receiving else r.serving_team_id == team_id)]
    decided = [r for r in observed if r.winner_team_id in team_ids]
    won = sum(r.winner_team_id == team_id for r in decided)
    return {
        "won": won,
        "total": len(decided),
        "pct": rate(won, len(decided)),
        "observed": len(observed),
        "unknown_outcomes": len(observed) - len(decided),
        "outcome_coverage_pct": rate(len(decided), len(observed)),
    }


def _terminal_winner(event, team_ids):
    if event.outcome == "error" or (event.kind == "attack" and event.outcome == "blocked"):
        return next(tid for tid in team_ids if tid != event.team_id)
    if (event.kind, event.outcome) in {("serve", "ace"), ("attack", "kill"), ("block", "point")}:
        return event.team_id
    return None


def overlapping_rally_ids(rallies):
    """Flag old duplicate/overlapping observations without choosing a winner.

    The database prevents new overlaps, but pre-migration records may contain
    them. A sweep reports every affected ID in O(n log n); touching endpoints
    and independent source videos are not overlaps.
    """
    videos = defaultdict(list)
    for rally in rallies:
        videos[rally.video_id].append(rally)
    overlapping = set()
    for group in videos.values():
        furthest = None
        for rally in sorted(group, key=lambda r: (r.start, r.end, r.id)):
            if furthest is not None and rally.start < furthest.end:
                overlapping.update((furthest.id, rally.id))
            if furthest is None or rally.end > furthest.end:
                furthest = rally
    return sorted(overlapping)


def calculate(events, rallies, match, sets):
    events, rallies, sets = list(events), list(rallies), list(sets)
    team_ids = (match.home_id, match.away_id)
    eligible = [e for e in events if not e.deleted and e.status in TRUSTED and e.team_id in team_ids]
    valid_set_ids = {s.id for s in sets}
    set_rallies = [r for r in rallies if r.set_id in valid_set_ids]
    trusted_rallies = [r for r in set_rallies if r.status in TRUSTED]
    # A foreign/nonexistent team is an unknown value, never a loss for both teams.
    rate_rallies = [r for r in trusted_rallies if r.serving_team_id in team_ids]
    teams = {}
    for tid in team_ids:
        group = [e for e in eligible if e.team_id == tid]
        teams[str(tid)] = summarize(group)
        teams[str(tid)]["players"] = {
            str(pid) if pid is not None else "unknown": summarize([e for e in group if e.player_id == pid])
            for pid in sorted({e.player_id for e in group}, key=lambda pid: (pid is None, pid or 0))
        }
        teams[str(tid)]["sideout"] = _rally_rates(rate_rallies, tid, team_ids, receiving=True)
        teams[str(tid)]["breakpoint"] = _rally_rates(rate_rallies, tid, team_ids, receiving=False)
    scores = []
    for s in sets:
        observed = [r for r in set_rallies if r.set_id == s.id]
        decided = [r for r in observed if r.status in TRUSTED and r.winner_team_id in team_ids]
        scores.append(
            {
                "set_id": s.id,
                "number": s.number,
                "home": s.initial_home + sum(r.winner_team_id == match.home_id for r in decided),
                "away": s.initial_away + sum(r.winner_team_id == match.away_id for r in decided),
                "observed_rallies": len(observed),
                "decided_rallies": len(decided),
                "pending_rallies": sum(r.status not in TRUSTED for r in observed),
                # Includes unreviewed predictions even if they contain a winner.
                "unknown_rallies": len(observed) - len(decided),
                "complete_match_score": False,
            }
        )

    grade_conflicts = [
        getattr(e, "id", None) for e in eligible if e.kind in GRADED_KINDS and grade_issue(e) is not None
    ]
    rally_by_id = {r.id: r for r in trusted_rallies if r.winner_team_id in team_ids}
    terminal_conflicts = []
    terminal_sides = defaultdict(set)
    for e in eligible:
        inferred = _terminal_winner(e, team_ids)
        if inferred is None:
            continue
        terminal_sides[e.rally_id].add(inferred)
        rally = rally_by_id.get(e.rally_id)
        if rally is not None and rally.winner_team_id != inferred:
            terminal_conflicts.append(getattr(e, "id", None))
    return {
        "trusted_events": len(eligible),
        "pending_events": sum(e.status not in TRUSTED for e in events if not e.deleted),
        "teams": teams,
        "sets": scores,
        "data_quality": {
            "overlapping_rally_ids": overlapping_rally_ids(set_rallies),
            "grade_conflict_count": len(grade_conflicts),
            "grade_conflict_event_ids": grade_conflicts,
            "terminal_conflict_count": len(terminal_conflicts),
            "terminal_conflict_event_ids": terminal_conflicts,
            "contradictory_terminal_rally_ids": sorted(rid for rid, sides in terminal_sides.items() if len(sides) > 1),
            "invalid_outcome_count": sum(
                e.outcome is not None and e.outcome not in VALID_OUTCOMES.get(e.kind, set()) for e in eligible
            ),
            "foreign_team_event_count": sum(not e.deleted and e.team_id not in team_ids for e in events),
            "unknown_serving_rallies": sum(r.serving_team_id not in team_ids for r in trusted_rallies),
            "invalid_winner_rallies": sum(
                r.winner_team_id is not None and r.winner_team_id not in team_ids for r in trusted_rallies
            ),
            "pending_rallies": sum(r.status not in TRUSTED for r in set_rallies),
        },
        "methodology": "VolleyVision v1.1; METRICS.md. Только ручные/подтверждённые события. Счёт по размеченным розыгрышам.",
    }
