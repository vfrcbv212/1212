"""Single-worker durable queue for proxies and local detector analysis."""

import logging
import threading

from sqlalchemy import select, update
from sqlalchemy.exc import SQLAlchemyError

from .db import Session
from .media import make_proxy
from .models import Job, Video

logger = logging.getLogger(__name__)
stop_event = threading.Event()
worker = None
lifecycle_lock = threading.Lock()


def _finish(job_id, video_id, status, path=None, error=None):
    # A temporary SQLite lock must not kill the worker or lose a completed result.
    while True:
        try:
            with Session() as db:
                job = db.get(Job, job_id)
                if job is None:
                    return
                job.status, job.error = status, error
                if status == "completed" and job.kind == "proxy":
                    video = db.get(Video, video_id)
                    if video is None:
                        job.status, job.error = "failed", "Исходное видео больше не существует"
                    else:
                        video.proxy_path = path
                        job.checkpoint = {"proxy_complete": True}
                        job.progress = 1
                if status == "completed" and job.kind == "analysis":
                    job.progress = 1
                db.commit()
            return
        except SQLAlchemyError:
            logger.exception("Не удалось сохранить результат задачи %s; повтор после восстановления БД", job_id)
            if stop_event.wait(1):
                return  # running is recovered as interrupted by the next startup.


def process_next():
    with Session() as db:
        job = db.scalar(select(Job).where(Job.status == "queued").order_by(Job.id))
        if job is None:
            return
        claimed = db.execute(
            update(Job).where(Job.id == job.id, Job.status == "queued").values(status="running", error=None)
        )
        if claimed.rowcount != 1:
            db.rollback()
            return
        job_id, video_id, kind = job.id, job.video_id, job.kind
        video = db.get(Video, video_id)
        if video is not None:
            db.expunge(video)
        db.commit()
    try:
        if video is None:
            raise ValueError("Исходное видео не найдено")
        if kind == "analysis":
            from .analysis import process_analysis

            process_analysis(job_id, stop_event)
            path = None
        elif kind == "proxy":
            path = make_proxy(video, stop_event)
        else:
            raise ValueError("Неподдерживаемый тип задачи")
    except InterruptedError as exc:
        _finish(job_id, video_id, "interrupted", error=str(exc)[:1000])
    except Exception as exc:
        _finish(job_id, video_id, "failed", error=str(exc)[:1000])
    else:
        _finish(job_id, video_id, "completed", path=path)


def loop():
    while not stop_event.is_set():
        try:
            process_next()
        except Exception:
            logger.exception("Ошибка очереди; обработчик повторит попытку")
        stop_event.wait(0.5)


def start():
    global worker
    with lifecycle_lock:
        if worker is not None and worker.is_alive():
            return
        with Session() as db:
            db.execute(update(Job).where(Job.status == "running").values(status="interrupted"))
            db.commit()
        stop_event.clear()
        worker = threading.Thread(target=loop, daemon=True, name="video-worker")
        worker.start()


def stop():
    global worker
    # Keep start() serialized until the previous worker has fully exited. Without
    # this lock across join, concurrent startup could return while stop removes
    # the only worker, leaving a running application with an idle queue.
    with lifecycle_lock:
        stop_event.set()
        current = worker
        if current:
            current.join(timeout=15)
            if current.is_alive():
                raise RuntimeError("Обработчик видео не завершился; дождитесь его остановки перед повторным запуском")
        worker = None
