from datetime import date as calendar_date
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator


class Input(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True, allow_inf_nan=False)


class TeamIn(Input):
    name: str = Field(min_length=1, max_length=120)


class PlayerIn(TeamIn):
    team_id: int
    number: str | None = Field(default=None, max_length=8)
    role: str = Field(default="Не указано", max_length=60)


class MatchIn(Input):
    home_id: int
    away_id: int
    date: str = Field(pattern=r"^\d{4}-\d{2}-\d{2}$")
    title: str = Field(default="", max_length=180)

    @model_validator(mode="after")
    def different(self):
        try:
            calendar_date.fromisoformat(self.date)
        except ValueError as exc:
            raise ValueError("Укажите существующую календарную дату") from exc
        if self.home_id == self.away_id:
            raise ValueError("Выберите две разные команды")
        return self


class RosterIn(Input):
    team_id: int
    player_id: int
    number: str | None = Field(default=None, max_length=8)
    libero: bool = False


class SetIn(Input):
    number: int = Field(ge=1, le=5)
    initial_home: int = Field(default=0, ge=0, le=100)
    initial_away: int = Field(default=0, ge=0, le=100)


class RallyIn(Input):
    set_id: int
    video_id: int
    start: float = Field(ge=0)
    end: float = Field(gt=0)
    serving_team_id: int | None = None
    winner_team_id: int | None = None
    rotation: int | None = Field(default=None, ge=1, le=6)

    @model_validator(mode="after")
    def interval(self):
        if self.end <= self.start:
            raise ValueError("Конец розыгрыша должен быть позже начала")
        return self


class RallyEdit(RallyIn):
    revision: int = Field(ge=1)


Kind = Literal["serve", "reception", "set", "attack", "block", "dig", "cover", "freeball", "error"]
Outcome = Literal["ace", "error", "in_play", "kill", "blocked", "continued", "touch", "point"]
OUTCOMES = {
    "serve": {"ace", "error", "in_play"},
    "reception": {"error", "continued"},
    "set": {"error", "continued"},
    "attack": {"kill", "error", "blocked", "continued"},
    "block": {"point", "touch", "error", "continued"},
    "dig": {"error", "continued"},
    "cover": {"error", "continued"},
    "freeball": {"error", "continued"},
    "error": {"error"},
}


class EventIn(Input):
    rally_id: int
    time: float = Field(ge=0)
    kind: Kind
    team_id: int
    player_id: int | None = None
    subtype: str | None = Field(default=None, max_length=80)
    outcome: Outcome | None = None
    quality: int | None = Field(default=None, ge=0, le=3)
    zone_from: int | None = Field(default=None, ge=1, le=6)
    zone_to: int | None = Field(default=None, ge=1, le=6)
    rotation: int | None = Field(default=None, ge=1, le=6)

    @model_validator(mode="after")
    def compatible(self):
        if self.outcome is not None and self.outcome not in OUTCOMES[self.kind]:
            raise ValueError("Результат несовместим с типом действия")
        if self.kind in {"reception", "dig", "set"} and self.quality is not None:
            if (self.outcome == "error" and self.quality > 0) or (self.outcome == "continued" and self.quality == 0):
                raise ValueError("Оценка 0 означает ошибку; положительная оценка несовместима с ошибкой")
        return self


class EventEdit(EventIn):
    revision: int = Field(ge=1)


class ClipIn(Input):
    event_ids: list[int] = Field(min_length=1, max_length=100)
    before: float = Field(default=3, ge=0, le=30)
    after: float = Field(default=4, gt=0, le=30)
    name: str = Field(default="Подборка", min_length=1, max_length=100)


class YandexIn(Input):
    public_key: str = Field(max_length=1000)
    path: str | None = Field(default=None, max_length=1000)


class VideoEdit(Input):
    position: int = Field(ge=0)
    offset: float | None = Field(default=None, ge=0)
