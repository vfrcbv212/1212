"""Video-specific observed floor geometry and explicitly confirmed player-card samples."""

import hashlib
import json
import math
import os
import threading
import uuid
from typing import Literal

from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import Response
from pydantic import BaseModel, ConfigDict, Field, model_validator
from sqlalchemy import select
from sqlalchemy.orm import Session as DBSession

from .db import DATA, session
from .models import Roster, Video
from .media import display_filter

router = APIRouter(prefix="/api", tags=["Initial setup"])
lock = threading.RLock()


class Point(BaseModel):
    image: tuple[float, float]
    court: tuple[float, float]

    @model_validator(mode="after")
    def bounds(self):
        if any(not math.isfinite(x) for x in (*self.image, *self.court)):
            raise ValueError("Координаты должны быть конечными")
        if not all(0 <= x <= 1 for x in self.image) or not (0 <= self.court[0] <= 18 and 0 <= self.court[1] <= 9):
            raise ValueError("Изображение: 0..1; пол площадки: 18×9 м")
        return self


class Calibration(BaseModel):
    model_config = ConfigDict(extra="ignore", allow_inf_nan=False)
    mode: Literal["image", "court"] = "image"
    points: list[Point] = Field(default_factory=list, max_length=30)
    visibility_polygon: list[tuple[float, float]] = Field(default_factory=list, max_length=50)
    frame_time: float = Field(default=0, ge=0)
    lens: Literal["unknown", "uncalibrated_ultrawide"] = "unknown"

    @model_validator(mode="after")
    def polygon(self):
        if self.visibility_polygon and len(self.visibility_polygon) < 3:
            raise ValueError("Для области наблюдения нужны минимум 3 точки")
        if any(not math.isfinite(v) or not 0 <= v <= 1 for p in self.visibility_polygon for v in p):
            raise ValueError("Область наблюдения задаётся в координатах изображения 0..1")
        if len({p.image for p in self.points}) != len(self.points):
            raise ValueError("Опорные точки изображения не должны повторяться")
        if len({p.court for p in self.points}) != len(self.points):
            raise ValueError("Опорные точки пола не должны повторяться")
        return self


class Sample(BaseModel):
    model_config = ConfigDict(extra="forbid", allow_inf_nan=False)
    time: float = Field(ge=0)
    bbox: tuple[float, float, float, float]

    @model_validator(mode="after")
    def box(self):
        x1, y1, x2, y2 = self.bbox
        if not all(math.isfinite(v) and 0 <= v <= 1 for v in self.bbox) or x1 >= x2 or y1 >= y2:
            raise ValueError("Вырезка игрока должна находиться внутри кадра и иметь ненулевой размер")
        return self


class Card(BaseModel):
    model_config = ConfigDict(extra="forbid", allow_inf_nan=False)
    player_id: int
    team_id: int
    number: str | None = Field(default=None, max_length=8)
    confirmed: bool = False
    samples: list[Sample] = Field(default_factory=list, max_length=12)

    @model_validator(mode="after")
    def confirmed_sample(self):
        if self.confirmed and not self.samples:
            raise ValueError("Подтверждение карточки требует хотя бы одного настоящего кадра")
        return self


class SetupIn(BaseModel):
    model_config = ConfigDict(extra="forbid")
    revision: int = Field(ge=0)
    calibration: Calibration = Field(default_factory=Calibration)
    cards: list[Card] = Field(default_factory=list, max_length=100)


def evaluate_calibration(calibration, width, height):
    result = dict(calibration)
    result.update(
        homography=None,
        projection_scope="floor_only",
        lens_status="uncorrected",
        image_size=[width, height],
        independently_validated=False,
    )
    if calibration["mode"] != "court":
        result["reason"] = "Координаты видео: метрическая проекция не запрошена"
        return result
    points = calibration["points"]
    if len(points) < 4:
        result.update(mode="image", reason="Недостаточно независимых опорных точек пола; доступны координаты видео")
        return result
    try:
        import numpy as np
    except ImportError:
        result.update(
            mode="image", reason="Для расчёта геометрии установите requirements-ai.lock; координаты видео сохранены"
        )
        return result
    source = np.asarray([p["image"] for p in points], dtype=float)
    target = np.asarray([p["court"] for p in points], dtype=float) / [18, 9]
    if (
        np.linalg.matrix_rank(np.c_[source, np.ones(len(points))]) < 3
        or np.linalg.matrix_rank(np.c_[target, np.ones(len(points))]) < 3
    ):
        result.update(mode="image", reason="Опорные точки лежат на одной линии; проекция в метры не определена")
        return result
    a, b = [], []
    for (x, y), (u, v) in zip(source, target):
        a.extend(([x, y, 1, 0, 0, 0, -u * x, -u * y], [0, 0, 0, x, y, 1, -v * x, -v * y]))
        b.extend((u, v))
    matrix = np.asarray(a)
    if np.linalg.matrix_rank(matrix) < 8 or np.linalg.cond(matrix) > 1e8:
        result.update(mode="image", reason="Геометрия неустойчива; сохранены координаты видео")
        return result
    h = np.r_[np.linalg.lstsq(matrix, b, rcond=None)[0], 1].reshape(3, 3)
    if abs(np.linalg.det(h)) < 1e-10:
        result.update(mode="image", reason="Вырожденная геометрия; сохранены координаты видео")
        return result
    inverse = np.linalg.inv(h)
    predicted = (inverse @ np.c_[target, np.ones(len(target))].T).T
    if np.any(abs(predicted[:, 2]) < 1e-9):
        result.update(mode="image", reason="Неустойчивая обратная проекция; сохранены координаты видео")
        return result
    errors = np.linalg.norm((predicted[:, :2] / predicted[:, 2:] - source) * [width, height], axis=1)
    rms = float(np.sqrt(np.mean(errors**2)))
    result["reprojection_error_pixels"] = round(rms, 3)
    if rms > max(3, math.hypot(width, height) * 0.008):
        result.update(
            mode="image",
            reason="Опорные точки не согласованы; проверьте совмещение линий или используйте координаты видео",
        )
        return result
    result.update(
        mode="court",
        homography=(np.diag([18.0, 9.0, 1.0]) @ h).tolist(),
        reason="Совмещение рассчитано по видимым точкам пола. Летящий мяч и руки не являются точками пола; дисторсия не исправлена.",
    )
    if len(points) == 4:
        result["reason"] += " Четыре точки определяют преобразование, но нулевая невязка не доказывает точность."
    return result


def get_setup(video_id):
    path = DATA / "setup" / f"{int(video_id)}.json"
    if path.exists():
        try:
            value = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError) as exc:
            raise ValueError("Настройка видео повреждена; восстановите её из резервной копии") from exc
    else:
        value = {
            "video_id": int(video_id),
            "revision": 0,
            "calibration": Calibration().model_dump(mode="json"),
            "cards": [],
        }
    canonical = json.dumps(
        {k: v for k, v in value.items() if k != "config_sha256"},
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
    )
    return {**value, "config_sha256": hashlib.sha256(canonical.encode()).hexdigest()}


def video_for(db, video_id):
    video = db.get(Video, video_id)
    if video is None:
        raise HTTPException(404, "Видео не найдено")
    return video


@router.get("/videos/{video_id}/setup")
def read_setup(video_id: int, db: DBSession = Depends(session)):
    video_for(db, video_id)
    with lock:
        return get_setup(video_id)


@router.put("/videos/{video_id}/setup")
def save_setup(video_id: int, body: SetupIn, db: DBSession = Depends(session)):
    video = video_for(db, video_id)
    if body.calibration.frame_time >= video.duration:
        raise HTTPException(422, "Стоп-кадр должен находиться внутри исходного видео")
    seen = set()
    for card in body.cards:
        roster = db.scalar(
            select(Roster).where(
                Roster.match_id == video.match_id, Roster.player_id == card.player_id, Roster.team_id == card.team_id
            )
        )
        if roster is None:
            raise HTTPException(422, "Карточка игрока должна принадлежать составу этого матча и команды")
        if card.player_id in seen:
            raise HTTPException(422, "Игрок повторяется в карточках")
        seen.add(card.player_id)
        if any(sample.time >= video.duration for sample in card.samples):
            raise HTTPException(422, "Кадр карточки должен находиться внутри исходного видео")
    with lock:
        current = get_setup(video_id)
        if current["revision"] != body.revision:
            raise HTTPException(409, "Настройка изменена другим запросом; обновите страницу")
        width, height = video.width, video.height
        if abs((video.metadata_json or {}).get("rotation_degrees") or 0) % 180 == 90:
            width, height = height, width
        value = {
            "video_id": video_id,
            "revision": body.revision + 1,
            "calibration": evaluate_calibration(body.calibration.model_dump(mode="json"), width, height),
            "cards": [c.model_dump(mode="json") for c in body.cards],
        }
        folder = DATA / "setup"
        folder.mkdir(exist_ok=True)
        target = folder / f"{video_id}.json"
        temporary = folder / f"{video_id}-{uuid.uuid4().hex}.tmp"
        try:
            with temporary.open("x", encoding="utf-8") as f:
                json.dump(value, f, ensure_ascii=False, allow_nan=False)
                f.flush()
                os.fsync(f.fileno())
            os.replace(temporary, target)
        finally:
            temporary.unlink(missing_ok=True)
        return get_setup(video_id)


@router.get("/videos/{video_id}/frame")
def frame(video_id: int, time: float = Query(default=0, ge=0, allow_inf_nan=False), db: DBSession = Depends(session)):
    video = video_for(db, video_id)
    if time >= video.duration:
        raise HTTPException(422, "Стоп-кадр должен находиться внутри исходного видео")
    original = (DATA / video.path).resolve()
    if not original.is_relative_to(DATA) or not original.is_file():
        raise HTTPException(404, "Исходный файл отсутствует")
    # JPEG is generated locally. No arbitrary user URL/path is passed to FFmpeg.
    import subprocess

    try:
        result = subprocess.run(
            [
                "ffmpeg",
                "-nostdin",
                "-v",
                "error",
                "-ss",
                str(time),
                "-i",
                str(original),
                "-frames:v",
                "1",
                "-vf",
                display_filter(video, "scale=min(1280\\,iw):-2"),
                "-threads",
                "2",
                "-f",
                "image2pipe",
                "-vcodec",
                "mjpeg",
                "-",
            ],
            check=True,
            capture_output=True,
            timeout=30,
        )
    except (FileNotFoundError, subprocess.SubprocessError) as exc:
        raise HTTPException(422, "Не удалось получить стоп-кадр; проверьте кодек и FFmpeg") from exc
    if not result.stdout.startswith(b"\xff\xd8"):
        raise HTTPException(422, "Декодер не вернул изображение")
    return Response(content=result.stdout, media_type="image/jpeg", headers={"Cache-Control": "no-store"})


def inside_polygon(x, y, polygon):
    """Boundary-inclusive observed floor mask; this mask must never clip flying balls."""
    if not polygon:
        return True
    inside = False
    previous = polygon[-1]
    for current in polygon:
        x1, y1 = previous
        x2, y2 = current
        cross = (x - x1) * (y2 - y1) - (y - y1) * (x2 - x1)
        if (
            abs(cross) < 1e-10
            and min(x1, x2) - 1e-10 <= x <= max(x1, x2) + 1e-10
            and min(y1, y2) - 1e-10 <= y <= max(y1, y2) + 1e-10
        ):
            return True
        if (y1 > y) != (y2 > y) and x < (x2 - x1) * (y - y1) / (y2 - y1) + x1:
            inside = not inside
        previous = current
    return inside


def project_person_floor(bbox, frame_width, frame_height, calibration):
    """Approximate feet from bbox bottom, never a 3D measurement or ball projection."""
    if calibration.get("mode") != "court" or not calibration.get("homography"):
        return None
    if frame_width <= 0 or frame_height <= 0 or len(bbox) != 4:
        return None
    x1, y1, x2, y2 = map(float, bbox)
    if not all(math.isfinite(v) for v in (x1, y1, x2, y2)) or y2 >= frame_height - 1:
        return None  # Cropped feet provide no defensible floor anchor.
    x, y = (x1 + x2) / 2 / frame_width, y2 / frame_height
    if not 0 <= x <= 1 or not 0 <= y <= 1 or not inside_polygon(x, y, calibration.get("visibility_polygon", [])):
        return None
    h = calibration["homography"]
    denominator = h[2][0] * x + h[2][1] * y + h[2][2]
    if not math.isfinite(denominator) or abs(denominator) < 1e-9:
        return None
    u = (h[0][0] * x + h[0][1] * y + h[0][2]) / denominator
    v = (h[1][0] * x + h[1][1] * y + h[1][2]) / denominator
    if not (math.isfinite(u) and math.isfinite(v) and 0 <= u <= 18 and 0 <= v <= 9):
        return None
    return {
        "court": [round(u, 4), round(v, 4)],
        "approximate": True,
        "reason": "Оценка точки ног по нижней границе bbox; дисторсия не исправлена, не физическое измерение",
        "source": "person_bbox_bottom",
        "lens_status": calibration.get("lens_status", "uncorrected"),
    }
