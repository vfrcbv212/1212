from alembic import context

from volleyvision.db import Base, engine
from volleyvision import models, analysis_models  # noqa: F401

with engine.connect() as connection:
    context.configure(connection=connection, target_metadata=Base.metadata, render_as_batch=True)
    with context.begin_transaction():
        context.run_migrations()
