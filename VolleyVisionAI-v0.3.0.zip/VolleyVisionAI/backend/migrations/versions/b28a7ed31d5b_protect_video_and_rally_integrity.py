"""Protect video/rally integrity using additive SQLite DDL and safe preflight checks."""

from alembic import op
import sqlalchemy as sa

revision = "b28a7ed31d5b"
down_revision = "fe256e772f1e"
branch_labels = None
depends_on = None


def upgrade():
    bind = op.get_bind()
    duplicates = bind.execute(
        sa.text("""SELECT match_id, sha256, group_concat(id)
        FROM videos GROUP BY match_id, sha256 HAVING count(*) > 1""")
    ).fetchall()
    if duplicates:
        ids = "; ".join(f"матч {row[0]}, видео {row[2]}" for row in duplicates[:10])
        raise RuntimeError(
            "Найдены повторные видео в старой базе: "
            + ids
            + ". Сохраните резервную копию и устраните дубликаты с переносом разметки. "
            "Данные не удалены; миграция остановлена до изменения схемы."
        )
    inspector = sa.inspect(bind)
    # SQLite DDL may survive an interrupted upgrade: a safe retry must not add twice.
    if "revision" not in {column["name"] for column in inspector.get_columns("rallies")}:
        op.add_column("rallies", sa.Column("revision", sa.Integer(), nullable=False, server_default="1"))
    if "uq_video_match_sha256" not in {index["name"] for index in inspector.get_indexes("videos")}:
        op.create_index("uq_video_match_sha256", "videos", ["match_id", "sha256"], unique=True)
    op.execute("""CREATE TRIGGER IF NOT EXISTS no_rally_overlap_insert BEFORE INSERT ON rallies
        WHEN EXISTS (SELECT 1 FROM rallies r WHERE r.video_id=NEW.video_id
            AND r.start < NEW.end AND r.end > NEW.start)
        BEGIN SELECT RAISE(ABORT, 'overlapping rally interval'); END""")
    op.execute("""CREATE TRIGGER IF NOT EXISTS no_rally_overlap_update BEFORE UPDATE OF video_id, start, end ON rallies
        WHEN EXISTS (SELECT 1 FROM rallies r WHERE r.video_id=NEW.video_id AND r.id != NEW.id
            AND r.start < NEW.end AND r.end > NEW.start)
        BEGIN SELECT RAISE(ABORT, 'overlapping rally interval'); END""")


def downgrade():
    op.execute("DROP TRIGGER no_rally_overlap_update")
    op.execute("DROP TRIGGER no_rally_overlap_insert")
    op.drop_index("uq_video_match_sha256", table_name="videos")
    op.drop_column("rallies", "revision")
