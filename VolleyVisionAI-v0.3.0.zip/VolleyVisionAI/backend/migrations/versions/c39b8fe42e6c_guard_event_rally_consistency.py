"""Keep event/rally source and bounds valid even across competing transactions."""

from alembic import op

revision = "c39b8fe42e6c"
down_revision = "b28a7ed31d5b"
branch_labels = None
depends_on = None


EVENT_VALID = """EXISTS (SELECT 1 FROM rallies r WHERE r.id=NEW.rally_id
    AND r.match_id=NEW.match_id AND r.video_id=NEW.video_id
    AND NEW.time >= r.start AND NEW.time <= r.end)"""
RALLY_CONFLICT = """EXISTS (SELECT 1 FROM events e WHERE e.rally_id=OLD.id AND e.deleted=0
    AND (e.video_id != NEW.video_id OR e.match_id != NEW.match_id OR e.time < NEW.start OR e.time > NEW.end))"""


def upgrade():
    op.execute(f"""CREATE TRIGGER IF NOT EXISTS valid_event_rally_insert BEFORE INSERT ON events
        WHEN NEW.deleted=0 AND NOT {EVENT_VALID}
        BEGIN SELECT RAISE(ABORT, 'event outside rally source or bounds'); END""")
    op.execute(f"""CREATE TRIGGER IF NOT EXISTS valid_event_rally_update BEFORE UPDATE OF rally_id, video_id, match_id, time, deleted ON events
        WHEN NEW.deleted=0 AND NOT {EVENT_VALID}
        BEGIN SELECT RAISE(ABORT, 'event outside rally source or bounds'); END""")
    op.execute(f"""CREATE TRIGGER IF NOT EXISTS preserve_rally_events BEFORE UPDATE OF video_id, match_id, start, end ON rallies
        WHEN {RALLY_CONFLICT}
        BEGIN SELECT RAISE(ABORT, 'rally edit would invalidate existing events'); END""")


def downgrade():
    for name in ("preserve_rally_events", "valid_event_rally_update", "valid_event_rally_insert"):
        op.execute("DROP TRIGGER " + name)
