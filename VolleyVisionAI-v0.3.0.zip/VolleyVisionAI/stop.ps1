﻿$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
& .\.venv\Scripts\python.exe scripts\serve.py --stop
if ($LASTEXITCODE -ne 0) { throw 'Остановка не подтверждена. Используйте Ctrl+C в окне приложения.' }
