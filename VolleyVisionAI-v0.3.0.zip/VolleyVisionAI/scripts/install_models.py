"""Install checksum-pinned official ONNX artifacts; no model code or pickle is loaded."""

import argparse
import json
import os
import shutil
import sys
import tempfile
from pathlib import Path
from urllib.parse import urlparse, urljoin

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "backend"))

from volleyvision.vision import MODELS, file_sha256, get_model_manifest, model_path  # noqa: E402


ALLOWED_DOWNLOAD_HOSTS = {"github.com", "release-assets.githubusercontent.com", "objects.githubusercontent.com"}


def _validate_download_url(url):
    parsed = urlparse(str(url))
    try:
        port = parsed.port
    except ValueError as exc:
        raise ValueError("Некорректный порт адреса модели") from exc
    if (
        parsed.scheme != "https"
        or parsed.hostname not in ALLOWED_DOWNLOAD_HOSTS
        or parsed.username is not None
        or parsed.password is not None
        or port not in (None, 443)
    ):
        raise ValueError("Официальная загрузка перенаправлена на неподдерживаемый HTTPS-адрес")


def _download(url, output, expected_bytes, client=None):
    """Validate each target BEFORE requesting it; never follow redirects implicitly."""
    import httpx
    from contextlib import nullcontext

    _validate_download_url(url)
    context = httpx.Client(timeout=120, follow_redirects=False) if client is None else nullcontext(client)
    with context as connection:
        for _ in range(6):
            with connection.stream("GET", url, follow_redirects=False) as response:
                if response.status_code in {301, 302, 303, 307, 308}:
                    location = response.headers.get("location")
                    if not location:
                        raise ValueError("Официальный сервер не указал адрес перенаправления")
                    next_url = urljoin(str(response.url), location)
                    _validate_download_url(next_url)
                    url = next_url
                    continue
                response.raise_for_status()
                total = 0
                for chunk in response.iter_bytes(1024 * 1024):
                    total += len(chunk)
                    if total > expected_bytes:
                        raise ValueError("Размер ответа превышает размер официального артефакта")
                    output.write(chunk)
                return
    raise ValueError("Слишком много перенаправлений официальной загрузки")


def install(model_id, offline_path=None):
    spec = MODELS[model_id]
    target = model_path(model_id)
    if target.is_file() and target.stat().st_size == spec["bytes"] and file_sha256(target) == spec["sha256"]:
        return {"model_id": model_id, "status": "already_verified", "sha256": spec["sha256"]}
    target.parent.mkdir(parents=True, exist_ok=True)
    if shutil.disk_usage(target.parent).free < spec["bytes"] * 2 + 128 * 1024**2:
        raise ValueError("Недостаточно места для загрузки и проверки модели")
    descriptor, name = tempfile.mkstemp(prefix=target.stem + "-", suffix=".part", dir=target.parent)
    temporary = Path(name)
    try:
        with os.fdopen(descriptor, "wb") as output:
            if offline_path is not None:
                source = Path(offline_path)
                if not source.is_file() or source.stat().st_size != spec["bytes"]:
                    raise ValueError("Локальный файл модели отсутствует или имеет неверный размер")
                with source.open("rb") as stream:
                    shutil.copyfileobj(stream, output, 1024 * 1024)
            else:
                url = get_model_manifest(model_id)["source_url"]
                _download(url, output, spec["bytes"])
            output.flush()
            os.fsync(output.fileno())
        if temporary.stat().st_size != spec["bytes"] or file_sha256(temporary) != spec["sha256"]:
            raise ValueError("SHA256/размер модели не совпали. Файл удалён; проверку нельзя отключать")
        os.replace(temporary, target)
        manifest = get_model_manifest(model_id)
        target.with_suffix(".manifest.json").write_text(
            json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        return {"model_id": model_id, "status": "installed_verified", "sha256": spec["sha256"]}
    finally:
        temporary.unlink(missing_ok=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Официальные YOLOX ONNX: лицензия/источники в MODEL_REGISTRY.md")
    parser.add_argument("--model", choices=[*MODELS, "all"], default="yolox-tiny")
    parser.add_argument("--offline-path", type=Path, help="Официальный ONNX из файла; SHA256 всё равно проверяется")
    parser.add_argument("--check", action="store_true", help="Проверить локальные веса без скачивания")
    args = parser.parse_args()
    selected = list(MODELS) if args.model == "all" else [args.model]
    if args.offline_path and len(selected) != 1:
        parser.error("--offline-path требует одну выбранную модель")
    if args.check:
        manifests = [get_model_manifest(name) for name in selected]
        print(json.dumps(manifests, ensure_ascii=False, indent=2))
        raise SystemExit(0 if all(m["verified"] for m in manifests) else 1)
    for name in selected:
        print(json.dumps(install(name, args.offline_path), ensure_ascii=False))
