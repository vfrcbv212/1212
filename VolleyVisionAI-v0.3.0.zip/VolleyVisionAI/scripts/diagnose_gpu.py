"""Read-only OS/CPU/RAM/NVIDIA/ONNX diagnostics; never installs a driver or claims unrun CUDA."""

import argparse
import csv
import ctypes
import importlib.metadata
import json
import os
import platform
import shutil
import struct
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

os.environ.setdefault("ORT_DISABLE_TELEMETRY", "1")


def _version(distribution):
    try:
        return importlib.metadata.version(distribution)
    except importlib.metadata.PackageNotFoundError:
        return None


def _limit_file(path):
    try:
        value = Path(path).read_text(encoding="ascii").strip()
        return int(value) if value != "max" else None
    except (OSError, ValueError):
        return None


def ram_info():
    physical, available, method = None, None, "unknown"
    if os.name == "nt":

        class MemoryStatus(ctypes.Structure):
            _fields_ = [
                ("dwLength", ctypes.c_ulong),
                ("dwMemoryLoad", ctypes.c_ulong),
                ("ullTotalPhys", ctypes.c_ulonglong),
                ("ullAvailPhys", ctypes.c_ulonglong),
                ("ullTotalPageFile", ctypes.c_ulonglong),
                ("ullAvailPageFile", ctypes.c_ulonglong),
                ("ullTotalVirtual", ctypes.c_ulonglong),
                ("ullAvailVirtual", ctypes.c_ulonglong),
                ("ullAvailExtendedVirtual", ctypes.c_ulonglong),
            ]

        value = MemoryStatus()
        value.dwLength = ctypes.sizeof(value)
        try:
            if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(value)):
                physical, available, method = int(value.ullTotalPhys), int(value.ullAvailPhys), "GlobalMemoryStatusEx"
        except (AttributeError, OSError):
            pass
    elif hasattr(os, "sysconf"):
        try:
            physical = os.sysconf("SC_PHYS_PAGES") * os.sysconf("SC_PAGE_SIZE")
            available = os.sysconf("SC_AVPHYS_PAGES") * os.sysconf("SC_PAGE_SIZE")
            method = "sysconf"
        except (ValueError, OSError):
            pass
    limit = None
    if sys.platform.startswith("linux"):
        limits = [_limit_file("/sys/fs/cgroup/memory.max"), _limit_file("/sys/fs/cgroup/memory/memory.limit_in_bytes")]
        useful = [value for value in limits if value is not None and 0 < value < 2**60]
        limit = min(useful) if useful else None
    budget = min(x for x in (physical, limit) if x is not None) if physical is not None or limit is not None else None
    return {
        "physical_bytes": physical,
        "available_host_bytes": available,
        "container_limit_bytes": limit,
        "effective_budget_bytes": budget,
        "method": method,
        "note": "Доступная RAM не является измерением пика анализа; контейнер может иметь меньший лимит, чем хост.",
    }


def nvidia_info():
    executable = shutil.which("nvidia-smi")
    if not executable:
        return {
            "status": "not_available",
            "gpus": [],
            "physical_gpu_count": None,
            "reason": "nvidia-smi не найден. Это не доказывает физическое отсутствие GPU; CUDA не проверена.",
        }
    try:
        result = subprocess.run(
            [executable, "--query-gpu=name,driver_version,memory.total", "--format=csv,noheader,nounits"],
            check=True,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=10,
        )
        cards = []
        for row in csv.reader(result.stdout.splitlines()):
            if len(row) != 3:
                continue
            name, driver, memory = (value.strip() for value in row)
            try:
                vram = int(float(memory))
            except ValueError:
                vram = None
            cards.append({"name": name, "driver_version": driver, "vram_total_mib": vram})
        if not cards:
            return {
                "status": "no_readable_devices",
                "gpus": [],
                "physical_gpu_count": None,
                "reason": "Команда выполнена, но устройства не удалось прочитать; CUDA не проверена.",
            }
        return {
            "status": "observed",
            "gpus": cards,
            "physical_gpu_count": len(cards),
            "reason": "Устройства видны nvidia-smi; это ещё не подтверждение исполнения модели на CUDA.",
        }
    except (OSError, subprocess.SubprocessError):
        return {
            "status": "query_failed",
            "gpus": [],
            "physical_gpu_count": None,
            "reason": "nvidia-smi не выполнился. Проверьте драйвер на целевом ПК; он автоматически не меняется.",
        }


def onnx_info():
    versions = {name: _version(name) for name in ("onnxruntime", "onnxruntime-gpu")}
    result = {
        "distributions": versions,
        "available_providers": [],
        "session_created": False,
        "active_session_providers": None,
        "cuda_execution_verified": False,
    }
    if not any(versions.values()):
        return {**result, "status": "not_installed"}
    try:
        import onnxruntime as ort

        return {
            **result,
            "status": "imported",
            "module_version": ort.__version__,
            "available_providers": ort.get_available_providers(),
            "note": "Доступный CUDAExecutionProvider не доказывает назначение операций модели на GPU. Смотрите лог настоящего inference.",
        }
    except Exception as exc:
        return {**result, "status": "import_failed", "error_type": type(exc).__name__}


def inspect(include_torch=False):
    affinity = None
    if hasattr(os, "sched_getaffinity"):
        try:
            affinity = len(os.sched_getaffinity(0))
        except OSError:
            pass
    torch = {"distribution_version": _version("torch"), "imported": False, "cuda_available": None}
    if include_torch and torch["distribution_version"]:
        try:
            import torch as library

            torch.update(
                imported=True, cuda_available=library.cuda.is_available(), compiled_cuda_version=library.version.cuda
            )
            if torch["cuda_available"]:
                torch["devices"] = [
                    {
                        "name": library.cuda.get_device_name(i),
                        "total_memory_bytes": library.cuda.get_device_properties(i).total_memory,
                    }
                    for i in range(library.cuda.device_count())
                ]
        except Exception as exc:
            torch["error_type"] = type(exc).__name__
    nvidia, runtime = nvidia_info(), onnx_info()
    return {
        "schema": 1,
        "observed_at_utc": datetime.now(timezone.utc).isoformat(),
        "machine": {
            "os": platform.system(),
            "release": platform.release(),
            "architecture": platform.machine(),
            "python_version": platform.python_version(),
            "python_bits": struct.calcsize("P") * 8,
            "processor": platform.processor() or None,
            "logical_cpu_count": os.cpu_count(),
            "affinity_cpu_count": affinity,
        },
        "ram": ram_info(),
        "nvidia": nvidia,
        "onnx_runtime": runtime,
        "torch": torch,
        "validation": {
            "windows_observed": platform.system() == "Windows",
            "model_inference_executed": False,
            "cuda_execution_verified": False,
            "vram_peak_measured": False,
            "cpu_fallback_available": "CPUExecutionProvider" in runtime["available_providers"],
        },
        "note": "Это диагностика текущего компьютера. Она не заменяет тест Windows, CUDA-инференса, скорости или точности реального матча.",
    }


def main():
    parser = argparse.ArgumentParser(
        description="Локальная диагностика реального устройства без установки ПО и передачи данных"
    )
    parser.add_argument("--output", type=Path)
    parser.add_argument(
        "--include-torch", action="store_true", help="Импортировать уже установленный PyTorch; не устанавливает его"
    )
    args = parser.parse_args()
    report = inspect(args.include_torch)
    text = json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False)
    if args.output:
        try:
            args.output.parent.mkdir(parents=True, exist_ok=True)
            with args.output.open("x", encoding="utf-8") as out:
                out.write(text + "\n")
        except OSError as exc:
            parser.exit(2, f"Диагностика не сохранена: {exc}\n")
    else:
        print(text)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
