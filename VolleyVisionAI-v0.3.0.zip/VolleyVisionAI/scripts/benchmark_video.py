"""Reproducible synthetic large-video HTTP benchmark; no real-match or AI accuracy claims.

Run from repository root:
  .venv/bin/python scripts/benchmark_video.py --output docs/BENCHMARK_VIDEO.json

Generates a 2-second 1080p60 color sample, repeats it losslessly to 25 minutes,
and appends a valid MP4 free atom so the final upload exceeds 32 MiB. All media,
databases and server logs live in a temporary directory that is removed afterward.
This intentionally simple synthetic sequence tests transport, storage, metadata,
seek and memory behavior, not motion complexity, codec coverage or AI quality.
"""

import argparse
import hashlib
import json
import os
import platform
import signal
import socket
import struct
import subprocess
import sys
import tempfile
import threading
import time
from datetime import datetime, timezone
from pathlib import Path

import httpx

ROOT = Path(__file__).resolve().parents[1]
MIB = 1024 * 1024


def execute(args, *, env=None, timeout=120):
    result = subprocess.run(
        args,
        cwd=ROOT,
        env=env,
        check=True,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        timeout=timeout,
    )
    return result.stdout


def sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for chunk in iter(lambda: source.read(MIB), b""):
            digest.update(chunk)
    return digest.hexdigest()


class RssMonitor:
    """Linux /proc observations; explicitly no claims on Windows where unavailable."""

    def __init__(self, pid):
        self.pid = pid
        self.peak_kib = None
        self.samples = 0
        self.finished = threading.Event()
        self.thread = threading.Thread(target=self.loop, daemon=True)

    def loop(self):
        while not self.finished.is_set():
            try:
                content = Path(f"/proc/{self.pid}/status").read_text(encoding="ascii")
                values = {
                    line.split(":")[0]: line.split(":", 1)[1].strip() for line in content.splitlines() if ":" in line
                }
                rss = int(values["VmRSS"].split()[0])
                high_water = int(values.get("VmHWM", values["VmRSS"]).split()[0])
                self.peak_kib = max(self.peak_kib or 0, rss, high_water)
                self.samples += 1
            except (OSError, KeyError, ValueError):
                pass
            self.finished.wait(0.02)

    def start(self):
        self.thread.start()

    def stop(self):
        self.finished.set()
        self.thread.join(timeout=2)


def benchmark(port=18765):
    if not 1 <= port <= 65535:
        raise ValueError("Invalid test port")
    with socket.socket() as available:
        available.bind(("127.0.0.1", port))
    started = time.monotonic()
    result = {
        "schema": 1,
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "synthetic": True,
        "scope": "25min 1080p60 repeated constant-color video, padded with valid free atom; HTTP transport/storage/seek only",
        "excluded": [
            "real_match_analysis",
            "AI_accuracy",
            "full_length_proxy_encoding",
            "Windows_validation",
            "CUDA_validation",
        ],
        "platform": platform.system(),
        "python": platform.python_version(),
        "checks": {},
    }
    with tempfile.TemporaryDirectory(prefix="volleyvision-video-benchmark-") as temporary:
        workspace = Path(temporary)
        sample, video = workspace / "sample.mp4", workspace / "synthetic-25min.mp4"
        generation_started = time.monotonic()
        execute(
            [
                "ffmpeg",
                "-nostdin",
                "-v",
                "error",
                "-f",
                "lavfi",
                "-i",
                "color=c=navy:size=1920x1080:rate=60",
                "-t",
                "2",
                "-c:v",
                "libx264",
                "-preset",
                "ultrafast",
                "-crf",
                "35",
                "-pix_fmt",
                "yuv420p",
                "-g",
                "120",
                "-threads",
                "2",
                str(sample),
            ]
        )
        execute(
            [
                "ffmpeg",
                "-nostdin",
                "-v",
                "error",
                "-stream_loop",
                "749",
                "-i",
                str(sample),
                "-t",
                "1500",
                "-c",
                "copy",
                "-movflags",
                "+faststart",
                str(video),
            ]
        )
        unpadded_bytes = video.stat().st_size
        atom_size = max(8, 40 * MIB - unpadded_bytes)
        with video.open("ab") as stream:
            stream.write(struct.pack(">I4s", atom_size, b"free"))
            remaining = atom_size - 8
            padding = bytes(MIB)
            while remaining:
                amount = min(remaining, len(padding))
                stream.write(padding[:amount])
                remaining -= amount
        size = video.stat().st_size
        source_hash = sha256(video)
        result["input"] = {
            "bytes": size,
            "mib": round(size / MIB, 3),
            "unpadded_bytes": unpadded_bytes,
            "free_atom_bytes": atom_size,
            "sha256": source_hash,
            "duration_seconds": 1500,
            "width": 1920,
            "height": 1080,
            "fps": 60,
            "construction_seconds": round(time.monotonic() - generation_started, 3),
        }
        assert size > 32 * MIB
        env = {**os.environ, "VOLLEYVISION_DATA": str(workspace / "data")}
        execute([sys.executable, "-m", "alembic", "upgrade", "head"], env=env)
        with (workspace / "server.log").open("w", encoding="utf-8") as log:
            server = subprocess.Popen(
                [
                    sys.executable,
                    "-m",
                    "uvicorn",
                    "volleyvision.main:app",
                    "--app-dir",
                    "backend",
                    "--host",
                    "127.0.0.1",
                    "--port",
                    str(port),
                ],
                cwd=ROOT,
                env=env,
                stdout=log,
                stderr=log,
            )
            monitor = RssMonitor(server.pid)
            monitor.start()
            try:
                base_url = f"http://127.0.0.1:{port}/api"
                with httpx.Client(base_url=base_url, timeout=120, trust_env=False) as client:
                    deadline = time.monotonic() + 30
                    while True:
                        if server.poll() is not None:
                            raise RuntimeError("Benchmark server exited before readiness")
                        try:
                            if client.get("/health").status_code == 200:
                                break
                        except httpx.HTTPError:
                            pass
                        if time.monotonic() > deadline:
                            raise TimeoutError("Benchmark server readiness timed out")
                        time.sleep(0.05)

                    def create(path, body):
                        response = client.post(path, json=body)
                        response.raise_for_status()
                        assert response.status_code == 201
                        return response.json()

                    home = create("/teams", {"name": "SYNTHETIC benchmark A"})
                    away = create("/teams", {"name": "SYNTHETIC benchmark B"})
                    match = create(
                        "/matches",
                        {
                            "home_id": home["id"],
                            "away_id": away["id"],
                            "date": "2026-11-15",
                            "title": "SYNTHETIC large-video benchmark",
                        },
                    )
                    upload_started = time.monotonic()
                    # The open file is handed to httpx's streaming multipart encoder;
                    # read_bytes() is deliberately not used for the upload.
                    with video.open("rb") as source:
                        response = client.post(
                            f"/matches/{match['id']}/videos",
                            files={"file": ("synthetic-25min.mp4", source, "video/mp4")},
                        )
                    response.raise_for_status()
                    assert response.status_code == 201
                    uploaded = response.json()
                    result["upload_seconds"] = round(time.monotonic() - upload_started, 3)
                    assert uploaded["size"] == size
                    assert uploaded["sha256"] == source_hash
                    assert abs(uploaded["duration"] - 1500) < 0.1
                    assert uploaded["width"] == 1920 and uploaded["height"] == 1080
                    assert abs(uploaded["fps"] - 60) < 0.01
                    stored = workspace / "data" / uploaded["path"]
                    assert stored.is_file() and sha256(stored) == source_hash
                    result["checks"]["http_streaming_upload_201"] = True
                    result["checks"]["stored_file_sha256_matches_source"] = True
                    result["checks"]["metadata_25min_1080p60"] = True
                    result["observed_metadata"] = {
                        key: uploaded[key] for key in ("duration", "width", "height", "fps", "codec", "size")
                    }
                    offset = size - 1024
                    response = client.get(f"/videos/{uploaded['id']}/stream", headers={"Range": f"bytes={offset}-"})
                    assert response.status_code == 206
                    assert response.headers["content-range"] == f"bytes {offset}-{size - 1}/{size}"
                    with video.open("rb") as original:
                        original.seek(offset)
                        assert response.content == original.read(1024)
                    result["checks"]["near_end_http_range_206_exact_bytes"] = True
                    result["range"] = {
                        "offset": offset,
                        "bytes": len(response.content),
                        "content_range": response.headers["content-range"],
                    }
                    decode_started = time.monotonic()
                    progress = execute(
                        [
                            "ffmpeg",
                            "-nostdin",
                            "-v",
                            "error",
                            "-ss",
                            "1499",
                            "-i",
                            str(stored),
                            "-frames:v",
                            "1",
                            "-progress",
                            "pipe:1",
                            "-f",
                            "null",
                            "-",
                        ]
                    )
                    frames = [
                        int(line.split("=", 1)[1].strip())
                        for line in progress.splitlines()
                        if line.startswith("frame=")
                    ]
                    assert frames and max(frames) == 1
                    result["checks"]["decode_real_frame_at_1499_seconds"] = True
                    result["near_end_decode_seconds"] = round(time.monotonic() - decode_started, 3)
            finally:
                if server.poll() is None:
                    if os.name == "nt":
                        server.terminate()
                    else:
                        server.send_signal(signal.SIGINT)
                    try:
                        server.wait(timeout=20)
                    except subprocess.TimeoutExpired:
                        server.kill()
                        server.wait(timeout=5)
                monitor.stop()
            result["server_exit_code"] = server.returncode
            result["server_process_peak_rss_mib"] = (
                round(monitor.peak_kib / 1024, 3) if monitor.peak_kib is not None else None
            )
            result["rss_samples"] = monitor.samples
            result["rss_method"] = (
                "Linux /proc server VmRSS/VmHWM; excludes external FFmpeg/ffprobe processes"
                if monitor.samples
                else "Unavailable on this platform"
            )
            assert server.returncode == 0
    result["temporary_files_cleaned"] = True
    result["total_seconds"] = round(time.monotonic() - started, 3)
    result["passed"] = True
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=ROOT / "docs" / "BENCHMARK_VIDEO.json")
    parser.add_argument("--port", type=int, default=18765)
    args = parser.parse_args()
    evidence = benchmark(args.port)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(evidence, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(evidence, ensure_ascii=False, indent=2))
