"""Read-only local diagnostics: no installs, environment dumps or uploaded data."""

import argparse
import importlib.metadata
import hashlib
import json
import os
import shutil
import sqlite3
import subprocess
import sys
from contextlib import closing
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def inspect(data=None):
    data = Path(data or os.environ.get("VOLLEYVISION_DATA", ROOT / "data")).resolve()
    checks = []

    def record(name, ok, detail, required=True):
        checks.append({"name": name, "ok": bool(ok), "detail": detail, "required": required})

    record("Python", sys.version_info[:2] == (3, 12), f"{sys.version.split()[0]}; поддерживается Python 3.12")
    for name in ("fastapi", "uvicorn", "SQLAlchemy", "alembic", "pydantic", "python-multipart", "httpx", "openpyxl"):
        try:
            record(name, True, importlib.metadata.version(name))
        except importlib.metadata.PackageNotFoundError:
            record(name, False, "Не установлен. Запустите setup.ps1 или pip install -r requirements.lock")
    for name in ("ffmpeg", "ffprobe", "git"):
        executable = shutil.which(name)
        if not executable:
            record(name, False, "Не найден в PATH")
            continue
        try:
            output = subprocess.run(
                [executable, "-version" if name != "git" else "--version"],
                capture_output=True,
                text=True,
                timeout=10,
                encoding="utf-8",
                errors="replace",
                check=True,
            )
            record(name, True, output.stdout.splitlines()[0])
        except (OSError, subprocess.SubprocessError, IndexError):
            record(name, False, "Команда найдена, но не выполняется")
    record(
        "Интерфейс",
        (ROOT / "frontend" / "dist" / "index.html").is_file(),
        "Сборка frontend/dist/index.html; при отсутствии выполните setup.ps1 или npm run build",
    )
    ancestor = data
    while not ancestor.exists() and ancestor.parent != ancestor:
        ancestor = ancestor.parent
    try:
        free = shutil.disk_usage(ancestor).free
        record(
            "Свободное место", free > 1024**3, f"{free / 1024**3:.1f} ГБ. Нужен запас для исходников, прокси и экспорта"
        )
    except OSError:
        record("Свободное место", False, "Не удалось проверить каталог данных")
    database = data / "volleyvision.db"
    if database.is_file():
        try:
            with closing(sqlite3.connect(database.as_uri() + "?mode=ro", uri=True, timeout=5)) as db:
                integrity = db.execute("PRAGMA integrity_check").fetchone()[0]
                foreign_errors = db.execute("PRAGMA foreign_key_check").fetchall()
                version = db.execute("SELECT version_num FROM alembic_version").fetchone()
            record(
                "Целостность SQLite",
                integrity == "ok" and not foreign_errors,
                f"{integrity}; нарушений связей: {len(foreign_errors)}",
            )
            try:
                from alembic.config import Config
                from alembic.script import ScriptDirectory

                heads = ScriptDirectory.from_config(Config(str(ROOT / "alembic.ini"))).get_heads()
                current = version[0] if version else None
                record(
                    "Миграции",
                    current in heads,
                    f"Версия: {current or 'не установлена'}; ожидается {', '.join(heads)}. Обновление: setup.ps1",
                )
            except ImportError:
                record("Миграции", False, "Не установлен Alembic; выполните setup.ps1")
        except sqlite3.Error:
            record(
                "База данных",
                False,
                "Не читается или схема не установлена. Сначала сохраните копию data, затем проверьте миграции",
            )
    else:
        record("База данных", False, "Не создана. Выполните setup.ps1; диагностика не создаёт и не изменяет базу")
    models = Path(os.environ.get("VOLLEYVISION_MODELS_DIR", data / "models"))
    manifest_path = models / "yolox_tiny.manifest.json"
    model_file = models / "yolox_tiny.onnx"
    verified = False
    if manifest_path.is_file() and model_file.is_file():
        try:
            manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
            checksum = hashlib.sha256()
            with model_file.open("rb") as source:
                for chunk in iter(lambda: source.read(1024 * 1024), b""):
                    checksum.update(chunk)
            verified = checksum.hexdigest() == manifest.get("sha256") and model_file.stat().st_size == manifest.get(
                "bytes"
            )
        except (OSError, ValueError, TypeError):
            pass
    ai_packages = []
    for distribution in ("onnxruntime", "onnxruntime-gpu", "opencv-python-headless", "numpy"):
        try:
            ai_packages.append(distribution + "=" + importlib.metadata.version(distribution))
        except importlib.metadata.PackageNotFoundError:
            pass
    ai_detail = (
        "Веса Tiny проверены по локальному манифесту. "
        if verified
        else "Веса Tiny не проверены/отсутствуют; setup-ai.ps1. "
    )
    ai_detail += ", ".join(ai_packages) if ai_packages else "AI-зависимости не установлены."
    ai_detail += " CUDA здесь не подтверждается: scripts/diagnose_gpu.py; реальное исполнение — запуск анализа. Классификатора волейбольных действий пока нет."
    record("AI / CUDA", True, ai_detail, required=False)
    return checks


def main():
    parser = argparse.ArgumentParser(description="Проверка локальной установки VolleyVision без изменения данных")
    parser.add_argument("--data", type=Path, help="Каталог данных, если он отличается от стандартного")
    args = parser.parse_args()
    checks = inspect(args.data)
    for item in checks:
        print(f"{'OK' if item['ok'] else 'ОШИБКА'} | {item['name']}: {item['detail']}")
    failures = sum(not item["ok"] and item["required"] for item in checks)
    print(f"Обязательных ошибок: {failures}. Это проверка установки, а не качества AI или статистики реального матча.")
    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
