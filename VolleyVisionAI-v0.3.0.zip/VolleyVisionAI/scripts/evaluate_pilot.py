"""Independent pilot evaluator. No inference, network calls or silent unknown-to-zero conversion."""

import argparse
import bisect
import hashlib
import heapq
import json
import math
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path

SCHEMA = 1
ACCEPTED = {"accepted", "auto_accepted"}
SOURCE = ("match_id", "camera_id", "video_id")
SECTIONS = ("events", "detections", "rallies", "statistics")


def fraction(numerator, denominator):
    return numerator / denominator if denominator else None


def scores(tp, fp, fn):
    return {
        "tp": tp,
        "fp": fp,
        "fn": fn,
        "precision": fraction(tp, tp + fp),
        "recall": fraction(tp, tp + fn),
        "f1": fraction(2 * tp, 2 * tp + fp + fn),
    }


def finite(value, label):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise ValueError(f"{label}: требуется конечное число")
    return float(value)


def scope(record):
    if any(record.get(k) is None or isinstance(record[k], (dict, list)) for k in SOURCE):
        raise ValueError("У каждой записи нужны match_id, camera_id и video_id")
    return tuple(str(record[k]) for k in SOURCE)


def temporal(record, rally=False):
    return finite(record.get("start" if rally else "time"), "Таймкод")


def iou(first, second):
    a, b = first, second
    intersection = max(0.0, min(a[2], b[2]) - max(a[0], b[0])) * max(0.0, min(a[3], b[3]) - max(a[1], b[1]))
    area_a, area_b = (a[2] - a[0]) * (a[3] - a[1]), (b[2] - b[0]) * (b[3] - b[1])
    return intersection / (area_a + area_b - intersection)


def _validate_records(document):
    for section in SECTIONS:
        records = document.get(section, [])
        if not isinstance(records, list):
            raise ValueError(f"{section}: нужен список")
        seen = set()
        for record in records:
            if not isinstance(record, dict) or record.get("id") is None:
                raise ValueError(f"{section}: каждая запись должна иметь id")
            key = str(record["id"])
            if key in seen:
                raise ValueError(f"{section}: повторный id {key}")
            seen.add(key)
            scope(record)
            if section in {"events", "detections"}:
                if temporal(record) < 0:
                    raise ValueError("Таймкод не может быть отрицательным")
            if section == "events" and record.get("kind") is not None and not isinstance(record["kind"], str):
                raise ValueError("kind должен быть строкой или null")
            if section == "rallies":
                start, end = temporal(record, True), finite(record.get("end"), "Конец розыгрыша")
                if start < 0 or end <= start:
                    raise ValueError("Некорректные границы розыгрыша")
            if section == "detections":
                box = record.get("bbox")
                if not isinstance(box, list) or len(box) != 4:
                    raise ValueError("bbox — [x1,y1,x2,y2]")
                box = [finite(x, "bbox") for x in box]
                if box[0] >= box[2] or box[1] >= box[3] or not isinstance(record.get("class_name"), str):
                    raise ValueError("Вырезка должна иметь ненулевую площадь и class_name")
            if section == "statistics":
                if not isinstance(record.get("metric"), str):
                    raise ValueError("У статистики нужен metric")
                if record.get("value") is not None:
                    finite(record["value"], "Значение статистики")


def validate(ground_truth, predictions, split):
    for document in (ground_truth, predictions):
        if not isinstance(document, dict) or document.get("schema") != SCHEMA:
            raise ValueError("Ожидается документ schema=1")
        _validate_records(document)
    dataset = ground_truth.get("dataset", {})
    if not isinstance(dataset, dict) or not dataset.get("id"):
        raise ValueError("Эталону нужен dataset.id")
    predicted_dataset = predictions.get("dataset")
    if not isinstance(predicted_dataset, dict):
        raise ValueError("Предсказаниям нужен dataset-объект")
    if predicted_dataset.get("id") != dataset["id"]:
        raise ValueError("dataset.id эталона и предсказаний различаются")
    if dataset.get("annotation_status") != "human_verified":
        raise ValueError("Нужна независимо проверенная разметка dataset.annotation_status=human_verified")
    units = dataset.get("bbox_units", "pixels")
    if units not in {"pixels", "normalized"} or predictions.get("dataset", {}).get("bbox_units", "pixels") != units:
        raise ValueError("Единицы bbox должны совпадать: pixels или normalized")
    if units == "normalized":
        for document in (ground_truth, predictions):
            if any(
                not 0 <= coordinate <= 1 for record in document.get("detections", []) for coordinate in record["bbox"]
            ):
                raise ValueError("Нормализованные bbox должны находиться в пределах 0..1")
    assignments = {}
    allowed = set()
    partitions = dataset.get("partitions")
    if not isinstance(partitions, list) or not partitions:
        raise ValueError("Нужен список dataset.partitions с разделением по матчам, а не соседним кадрам")
    for part in partitions:
        if not isinstance(part, dict) or not all(part.get(k) is not None for k in ("match_id", "camera_id", "split")):
            raise ValueError("У раздела нужны match_id, camera_id, split")
        match = str(part["match_id"])
        if match in assignments and assignments[match] != part["split"]:
            raise ValueError("Утечка: один матч попал в разные train/validation/test")
        assignments[match] = part["split"]
        if part["split"] == split:
            allowed.add((match, str(part["camera_id"])))
    if not allowed:
        raise ValueError("В эталоне нет выбранного раздела")
    coverage = ground_truth.get("coverage")
    if not isinstance(coverage, list) or not coverage:
        raise ValueError("Нужны явно размеченные coverage-интервалы; отсутствие меток не означает отсутствие действия")
    selected = []
    for interval in coverage:
        key = scope(interval)
        start, end = temporal(interval, True), finite(interval.get("end"), "Конец coverage")
        if start < 0 or end < start:
            raise ValueError("Некорректное окно coverage")
        for flag in ("events", "rallies", "statistics"):
            if flag in interval and not isinstance(interval[flag], bool):
                raise ValueError("Флаги coverage должны быть true/false")
        classes = interval.get("detections", [])
        if not isinstance(classes, list) or not all(isinstance(c, str) for c in classes):
            raise ValueError("coverage.detections — список названий классов")
        if (key[0], key[1]) in allowed:
            selected.append(interval)
    if not selected:
        raise ValueError("Нет coverage-интервалов выбранного раздела")
    return selected


def _covered(record, coverage, section):
    key = scope(record)
    start = temporal(record, section == "rallies") if section != "statistics" else None
    end = finite(record["end"], "Конец") if section == "rallies" else start
    for window in coverage:
        if scope(window) != key:
            continue
        if section == "statistics":
            # Aggregate labels are allowed only when a separately declared complete
            # statistics window exists, not merely because one action was annotated.
            if window.get("statistics") is True:
                return True
        elif window["start"] <= start <= end <= window["end"]:
            if section == "detections" and record["class_name"] in window.get("detections", []):
                return True
            if section != "detections" and window.get(section) is True:
                return True
    return False


def _min_cost_pairs(left_count, right_count, candidates):
    """Maximum-cardinality, minimum-total-cost bipartite matching (unit-capacity flow)."""
    source, sink = left_count + right_count, left_count + right_count + 1
    graph = [[] for _ in range(sink + 1)]

    def edge(u, v, cost):
        forward = [v, len(graph[v]), 1, cost]
        backward = [u, len(graph[u]), 0, -cost]
        graph[u].append(forward)
        graph[v].append(backward)
        return forward

    for i in range(left_count):
        edge(source, i, 0.0)
    for j in range(right_count):
        edge(left_count + j, sink, 0.0)
    refs = []
    for i, j, cost in sorted(candidates):
        refs.append((i, j, edge(i, left_count + j, cost)))
    potential = [0.0] * len(graph)
    while True:
        distance, previous = [math.inf] * len(graph), [None] * len(graph)
        distance[source] = 0.0
        queue = [(0.0, source)]
        while queue:
            current, node = heapq.heappop(queue)
            if current > distance[node] + 1e-12:
                continue
            for index, (dest, _, capacity, cost) in enumerate(graph[node]):
                proposed = current + cost + potential[node] - potential[dest]
                if capacity and proposed + 1e-12 < distance[dest]:
                    distance[dest] = proposed
                    previous[dest] = (node, index)
                    heapq.heappush(queue, (proposed, dest))
        if previous[sink] is None:
            break
        for i, dist in enumerate(distance):
            if math.isfinite(dist):
                potential[i] += dist
        node = sink
        while node != source:
            parent, index = previous[node]
            item = graph[parent][index]
            item[2] = 0
            graph[node][item[1]][2] = 1
            node = parent
    return [(i, j) for i, j, item in refs if item[2] == 0]


def match_records(truth, predictions, tolerance, label, acceptable=None, extra_cost=None, rally=False):
    groups = defaultdict(lambda: ([], []))
    for index, record in enumerate(truth):
        groups[(scope(record), record.get(label))][0].append(index)
    for index, record in enumerate(predictions):
        groups[(scope(record), record.get(label))][1].append(index)
    pairs = []
    for truth_indexes, prediction_indexes in groups.values():
        prediction_indexes.sort(key=lambda j: temporal(predictions[j], rally))
        times = [temporal(predictions[j], rally) for j in prediction_indexes]
        candidates = []
        for i, ti in enumerate(truth_indexes):
            time = temporal(truth[ti], rally)
            lo, hi = (
                bisect.bisect_left(times, time - tolerance - 1e-9),
                bisect.bisect_right(times, time + tolerance + 1e-9),
            )
            for j in range(lo, hi):
                pj = prediction_indexes[j]
                if acceptable is None or acceptable(truth[ti], predictions[pj]):
                    cost = abs(time - times[j]) / max(tolerance, 1e-9)
                    if extra_cost:
                        cost = extra_cost(truth[ti], predictions[pj]) + cost * 0.001
                    candidates.append((i, j, cost))
        pairs.extend(
            (truth_indexes[i], prediction_indexes[j])
            for i, j in _min_cost_pairs(len(truth_indexes), len(prediction_indexes), candidates)
        )
    return pairs


def _categorical_pairs(truth, predictions, pairs, field, require_team=False):
    known_truth = [(truth[i], predictions[j]) for i, j in pairs if truth[i].get(field) is not None]
    assigned = [
        (a, b)
        for a, b in known_truth
        if b.get(field) is not None and (not require_team or a.get("team_id") is None or b.get("team_id") is not None)
    ]
    correct = sum(
        a[field] == b[field] and (not require_team or a.get("team_id") is None or a.get("team_id") == b.get("team_id"))
        for a, b in assigned
    )
    return {
        "matched_with_known_truth": len(known_truth),
        "assigned": len(assigned),
        "unknown": len(known_truth) - len(assigned),
        "correct": correct,
        "accuracy_on_assigned": fraction(correct, len(assigned)),
        "correct_fraction_of_identifiable": fraction(correct, len(known_truth)),
        "assignment_coverage": fraction(len(assigned), len(known_truth)),
    }


def _counts(truth, predictions, pairs, labels):
    result = {}
    for value in labels:
        tp = sum(truth[i].get("kind", truth[i].get("class_name")) == value for i, _ in pairs)
        gt = sum(r.get("kind", r.get("class_name")) == value for r in truth)
        pred = sum(r.get("kind", r.get("class_name")) == value for r in predictions)
        result[value] = scores(tp, pred - tp, gt - tp)
    return result


def _statistics(truth, predictions, coverage):
    def key(row):
        return (*scope(row), row.get("team_id"), row.get("player_id"), row["metric"])

    truth = [r for r in truth if _covered(r, coverage, "statistics")]
    predictions = [r for r in predictions if _covered(r, coverage, "statistics")]
    for records in (truth, predictions):
        keys = [key(r) for r in records]
        if len(keys) != len(set(keys)):
            raise ValueError("Повторная статистическая метрика для одного источника/игрока/команды")
    known = {key(r): r for r in truth if r.get("value") is not None}
    guessed = {key(r): r for r in predictions}
    errors = []
    unknown = 0
    for index, actual in known.items():
        predicted = guessed.get(index)
        if predicted is None or predicted.get("value") is None:
            unknown += 1
            continue
        delta = predicted["value"] - actual["value"]
        errors.append(
            {
                "match_id": actual["match_id"],
                "camera_id": actual["camera_id"],
                "video_id": actual["video_id"],
                "team_id": actual.get("team_id"),
                "player_id": actual.get("player_id"),
                "metric": actual["metric"],
                "truth": actual["value"],
                "predicted": predicted["value"],
                "error": delta,
                "absolute_error": abs(delta),
            }
        )
    return {
        "known_truth_values": len(known),
        "compared_values": len(errors),
        "unknown_predictions": unknown,
        "unknown_truth_values": sum(r.get("value") is None for r in truth),
        "mean_absolute_error": fraction(sum(e["absolute_error"] for e in errors), len(errors)),
        "errors": errors,
    }


def evaluate(
    ground_truth,
    predictions,
    *,
    split="test",
    event_tolerance=0.25,
    detection_tolerance=0.05,
    iou_threshold=0.5,
    rally_tolerance=0.5,
    identity_switch_max_gap=1.0,
):
    for name, value in [
        ("event_tolerance", event_tolerance),
        ("detection_tolerance", detection_tolerance),
        ("rally_tolerance", rally_tolerance),
        ("identity_switch_max_gap", identity_switch_max_gap),
    ]:
        if finite(value, name) < 0:
            raise ValueError("Погрешность времени не может быть отрицательной")
    if not 0 < finite(iou_threshold, "IoU threshold") <= 1:
        raise ValueError("IoU threshold должен быть в (0,1]")
    coverage = validate(ground_truth, predictions, split)
    raw_events = [e for e in predictions.get("events", []) if _covered(e, coverage, "events")]
    truth_events = [
        e for e in ground_truth.get("events", []) if e.get("kind") is not None and _covered(e, coverage, "events")
    ]
    predicted_events = [e for e in raw_events if e.get("status") in ACCEPTED and e.get("kind") is not None]
    event_pairs = match_records(truth_events, predicted_events, event_tolerance, "kind")
    events = scores(len(event_pairs), len(predicted_events) - len(event_pairs), len(truth_events) - len(event_pairs))
    events.update(
        accepted_predictions=len(predicted_events),
        hypotheses=sum(e.get("status") not in ACCEPTED for e in raw_events),
        unknown_kind=sum(e.get("kind") is None for e in raw_events),
        by_kind=_counts(
            truth_events, predicted_events, event_pairs, sorted({e["kind"] for e in truth_events + predicted_events})
        ),
        matched=[
            {
                "truth_id": truth_events[i]["id"],
                "prediction_id": predicted_events[j]["id"],
                "absolute_time_error": abs(truth_events[i]["time"] - predicted_events[j]["time"]),
            }
            for i, j in event_pairs
        ],
        player=_categorical_pairs(truth_events, predicted_events, event_pairs, "player_id", True),
        team=_categorical_pairs(truth_events, predicted_events, event_pairs, "team_id"),
        outcome=_categorical_pairs(truth_events, predicted_events, event_pairs, "outcome"),
        direction=_categorical_pairs(truth_events, predicted_events, event_pairs, "direction"),
    )
    events["unknown_truth_kind"] = sum(
        e.get("kind") is None and _covered(e, coverage, "events") for e in ground_truth.get("events", [])
    )
    events["predictions_outside_coverage"] = len(predictions.get("events", [])) - len(raw_events)
    events["player"]["all_known_truth"] = sum(e.get("player_id") is not None for e in truth_events)
    events["player"]["correct_fraction_of_all_known_truth"] = fraction(
        events["player"]["correct"], events["player"]["all_known_truth"]
    )
    truth_boxes = [e for e in ground_truth.get("detections", []) if _covered(e, coverage, "detections")]
    predicted_boxes = [
        e
        for e in predictions.get("detections", [])
        if e.get("observed", True) is True
        and e.get("interpolated", False) is not True
        and _covered(e, coverage, "detections")
    ]
    box_pairs = match_records(
        truth_boxes,
        predicted_boxes,
        detection_tolerance,
        "class_name",
        lambda a, b: iou(a["bbox"], b["bbox"]) >= iou_threshold,
        lambda a, b: 1 - iou(a["bbox"], b["bbox"]),
    )
    boxes = scores(len(box_pairs), len(predicted_boxes) - len(box_pairs), len(truth_boxes) - len(box_pairs))
    boxes.update(
        by_class=_counts(
            truth_boxes, predicted_boxes, box_pairs, sorted({e["class_name"] for e in truth_boxes + predicted_boxes})
        ),
        matched=[
            {
                "truth_id": truth_boxes[i]["id"],
                "prediction_id": predicted_boxes[j]["id"],
                "iou": iou(truth_boxes[i]["bbox"], predicted_boxes[j]["bbox"]),
            }
            for i, j in box_pairs
        ],
        non_observed_predictions_excluded=sum(
            e.get("observed", True) is not True or e.get("interpolated", False) is True
            for e in predictions.get("detections", [])
        ),
    )
    people_pairs = [(i, j) for i, j in box_pairs if truth_boxes[i]["class_name"] == "person"]
    boxes["player"] = _categorical_pairs(truth_boxes, predicted_boxes, people_pairs, "player_id", True)
    boxes["player"]["all_known_truth"] = sum(
        e["class_name"] == "person" and e.get("player_id") is not None for e in truth_boxes
    )
    boxes["player"]["correct_fraction_of_all_known_truth"] = fraction(
        boxes["player"]["correct"], boxes["player"]["all_known_truth"]
    )
    tracks = defaultdict(list)
    for i, j in people_pairs:
        actual, predicted = truth_boxes[i], predicted_boxes[j]
        if actual.get("track_id") is not None:
            tracks[(*scope(actual), str(actual["track_id"]))].append((actual["time"], predicted.get("track_id")))
    switches, transitions, unknown_track = 0, 0, 0
    for observations in tracks.values():
        last = None
        for time, track in sorted(observations):
            if track is None:
                unknown_track += 1
                continue
            if last is not None and time - last[0] <= identity_switch_max_gap:
                transitions += 1
                switches += track != last[1]
            last = (time, track)
    boxes["tracking"] = {
        "id_switches": switches,
        "comparable_transitions": transitions,
        "unknown_predicted_track_ids": unknown_track,
        "max_gap_seconds": identity_switch_max_gap,
        "definition": "Смена track_id для одного эталонного непрерывного трека; не OCR номера игрока",
    }
    truth_rallies = [r for r in ground_truth.get("rallies", []) if _covered(r, coverage, "rallies")]
    predicted_rallies = [
        r for r in predictions.get("rallies", []) if r.get("status") in ACCEPTED and _covered(r, coverage, "rallies")
    ]
    rally_pairs = match_records(
        truth_rallies,
        predicted_rallies,
        rally_tolerance,
        "kind",
        lambda a, b: abs(a["end"] - b["end"]) <= rally_tolerance + 1e-9,
        rally=True,
    )
    rallies = scores(len(rally_pairs), len(predicted_rallies) - len(rally_pairs), len(truth_rallies) - len(rally_pairs))
    rallies["matched"] = [
        {
            "truth_id": truth_rallies[i]["id"],
            "prediction_id": predicted_rallies[j]["id"],
            "start_absolute_error": abs(truth_rallies[i]["start"] - predicted_rallies[j]["start"]),
            "end_absolute_error": abs(truth_rallies[i]["end"] - predicted_rallies[j]["end"]),
        }
        for i, j in rally_pairs
    ]
    warnings = [
        "Результат относится только к независимо размеченным интервалам и выбранному разделу, не ко всему матчу."
    ]
    if ground_truth["dataset"].get("synthetic") is True:
        warnings.append("Синтетический эталон проверяет инструменты, а не точность на настоящих матчах.")
    if not predicted_events:
        warnings.append(
            "Ноль принятых событий не является доказательством качества; precision может быть null, recall учитывает пропуски."
        )
    if len({scope(c)[0] for c in coverage}) < 2:
        warnings.append("Доступен только один матч: пилот, без заявления о надёжности на новых матчах.")
    return {
        "schema": SCHEMA,
        "dataset_id": ground_truth["dataset"]["id"],
        "split": split,
        "synthetic": ground_truth["dataset"].get("synthetic"),
        "coverage": coverage,
        "parameters": {
            "event_tolerance_seconds": event_tolerance,
            "detection_tolerance_seconds": detection_tolerance,
            "iou_threshold": iou_threshold,
            "rally_boundary_tolerance_seconds": rally_tolerance,
            "identity_switch_max_gap_seconds": identity_switch_max_gap,
        },
        "events": events,
        "detections": boxes,
        "rallies": rallies,
        "statistics": _statistics(ground_truth.get("statistics", []), predictions.get("statistics", []), coverage),
        "quality_gate": {
            "evaluated": False,
            "reason": "Пороги готовности должны быть определены после пилота; нулевая выборка не проходит приёмку",
        },
        "warnings": warnings,
    }


def main():
    parser = argparse.ArgumentParser(
        description="Сверка пилотных предсказаний с независимым эталоном, без запуска модели"
    )
    parser.add_argument("--truth", type=Path, required=True)
    parser.add_argument("--predictions", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--split", default="test")
    parser.add_argument("--event-tolerance", type=float, default=0.25)
    parser.add_argument("--detection-tolerance", type=float, default=0.05)
    parser.add_argument("--iou", type=float, default=0.5)
    parser.add_argument("--rally-tolerance", type=float, default=0.5)
    args = parser.parse_args()
    try:
        raw_truth, raw_predictions = args.truth.read_bytes(), args.predictions.read_bytes()
        result = evaluate(
            json.loads(raw_truth),
            json.loads(raw_predictions),
            split=args.split,
            event_tolerance=args.event_tolerance,
            detection_tolerance=args.detection_tolerance,
            iou_threshold=args.iou,
            rally_tolerance=args.rally_tolerance,
        )
        result["input_sha256"] = {
            "truth": hashlib.sha256(raw_truth).hexdigest(),
            "predictions": hashlib.sha256(raw_predictions).hexdigest(),
        }
        result["evaluated_at_utc"] = datetime.now(timezone.utc).isoformat()
        encoded = json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False)
        args.output.parent.mkdir(parents=True, exist_ok=True)
        # Exclusive output prevents accidentally replacing an earlier experiment.
        with args.output.open("x", encoding="utf-8") as out:
            out.write(encoded + "\n")
        print(f"Сверка сохранена: {args.output}. Это не автоматическое заключение о готовности модели.")
        return 0
    except (OSError, ValueError, TypeError) as exc:
        parser.exit(2, f"Сверка не выполнена: {exc}\n")


if __name__ == "__main__":
    raise SystemExit(main())
