"""Prepare local private-profile state. Never enables a VPN or publishes a route."""

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "backend"))


def main():
    from volleyvision.access import configure, load_config

    parser = argparse.ArgumentParser(description="Настройка приватного профиля VolleyVision")
    sub = parser.add_subparsers(dest="command", required=True)
    setup = sub.add_parser("configure")
    setup.add_argument("--hostname", required=True)
    setup.add_argument("--allow-login", action="append", required=True)
    sub.add_parser("target", help="Для скрипта настройки Serve; вывод содержит приватный upstream capability")
    sub.add_parser("public", help="Публичный для разрешённых устройств URL, без секретов")
    args = parser.parse_args()
    if args.command == "configure":
        access = configure(args.hostname, args.allow_login)
        print("Приватный профиль сохранён локально. Приложение не опубликовано: " + access.public_origin)
    else:
        access = load_config("remote-private")
        if args.command == "target":
            print(f"http://127.0.0.1:8765{access.upstream_prefix}/")
        else:
            print(json.dumps({"url": access.public_origin, "hostname": access.hostname}, ensure_ascii=False))


if __name__ == "__main__":
    try:
        main()
    except ValueError as exc:
        raise SystemExit(str(exc)) from exc
