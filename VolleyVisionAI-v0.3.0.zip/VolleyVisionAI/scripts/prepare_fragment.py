"""Create a short local excerpt without changing the source.

Copy mode preserves encoded video/audio packets (keyframe-limited boundaries).
Compress mode is explicitly labelled and cannot validate original 4K/HEVC quality.
"""

import argparse
import hashlib
import json
import math
import os
import subprocess
import tempfile
from fractions import Fraction
from pathlib import Path


def probe(path):
    result = subprocess.run(
        ["ffprobe", "-v", "error", "-show_streams", "-show_format", "-of", "json", str(path)],
        check=True,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        timeout=60,
    )
    data = json.loads(result.stdout)
    stream = next((s for s in data.get("streams", []) if s.get("codec_type") == "video"), None)
    if not stream:
        raise ValueError("В файле нет видеопотока")
    try:
        fps = float(Fraction(stream.get("avg_frame_rate", "0/1")))
    except (ValueError, ZeroDivisionError):
        fps = None
    return {
        key: stream.get(key)
        for key in (
            "codec_name",
            "width",
            "height",
            "pix_fmt",
            "avg_frame_rate",
            "r_frame_rate",
            "color_space",
            "color_transfer",
            "color_primaries",
            "bits_per_raw_sample",
            "side_data_list",
        )
    } | {
        "duration_seconds": float(data.get("format", {}).get("duration") or stream.get("duration") or 0),
        "fps_average": fps,
        "bytes": path.stat().st_size,
    }


def _publish(source, destination):
    try:
        if os.name == "nt":
            os.rename(source, destination)
        else:
            os.link(source, destination)
            source.unlink()
    except FileExistsError as exc:
        raise ValueError("Выходной файл уже существует; выберите новое имя") from exc


def prepare(source, output, start=0, duration=30, mode="copy"):
    source, output = Path(source).resolve(), Path(output).resolve()
    if not source.is_file():
        raise ValueError("Исходное видео не найдено")
    if output == source or output.exists():
        raise ValueError("Исходник и существующие файлы не заменяются; укажите новое имя")
    if (
        mode not in {"copy", "compress"}
        or not math.isfinite(start)
        or not math.isfinite(duration)
        or start < 0
        or duration <= 0
    ):
        raise ValueError("Укажите допустимые начало, длительность и режим")
    source_info = probe(source)
    if start >= source_info["duration_seconds"]:
        raise ValueError("Начало фрагмента находится за концом видео")
    if output.suffix.lower() not in {".mp4", ".mov", ".mkv"}:
        raise ValueError("Для фрагмента выберите MP4, MOV или MKV")
    if output.with_suffix(output.suffix + ".json").exists():
        raise ValueError("Файл отчёта уже существует; выберите новое имя фрагмента")
    output.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary_name = tempfile.mkstemp(prefix="fragment-", suffix=output.suffix, dir=output.parent)
    os.close(descriptor)
    temporary = Path(temporary_name)
    temporary.unlink()
    command = [
        "ffmpeg",
        "-nostdin",
        "-n",
        "-v",
        "error",
        "-ss",
        str(start),
        "-i",
        str(source),
        "-t",
        str(min(duration, source_info["duration_seconds"] - start)),
        "-map",
        "0:v:0",
        "-map",
        "0:a?",
    ]
    if mode == "copy":
        command += ["-c", "copy", "-avoid_negative_ts", "make_zero"]
    else:
        command += [
            "-vf",
            "scale=trunc(min(1280\\,iw)/2)*2:-2,setsar=1",
            "-c:v",
            "libx264",
            "-pix_fmt",
            "yuv420p",
            "-preset",
            "veryfast",
            "-crf",
            "24",
            "-threads",
            "2",
            "-c:a",
            "aac",
        ]
    if output.suffix.lower() in {".mp4", ".mov"}:
        command += ["-movflags", "+faststart"]
    command.append(str(temporary))
    try:
        subprocess.run(
            command, check=True, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=900
        )
        output_info = probe(temporary)
        checksum = hashlib.sha256()
        with temporary.open("rb") as file:
            for chunk in iter(lambda: file.read(1024 * 1024), b""):
                checksum.update(chunk)
        _publish(temporary, output)
    finally:
        temporary.unlink(missing_ok=True)
    report = {
        "source_name": source.name,
        "source": source_info,
        "output_name": output.name,
        "output": output_info,
        "requested_start_seconds": start,
        "requested_duration_seconds": duration,
        "mode": mode,
        "compressed": mode == "compress",
        "timing": "keyframe_approximate" if mode == "copy" else "decode_accurate",
        "sha256": checksum.hexdigest(),
        "under_32_mib": output_info["bytes"] <= 32 * 1024**2,
        "limitations": ["Пережатый фрагмент не проверяет исходное качество 4K/HEVC/HDR."]
        if mode == "compress"
        else ["Копирование сохраняет качество; фактические границы зависят от ключевых кадров."],
    }
    report_path = output.with_suffix(output.suffix + ".json")
    if report_path.exists():
        raise ValueError("Фрагмент создан, но файл отчёта уже существует; существующий отчёт не заменён")
    with report_path.open("x", encoding="utf-8") as file:
        json.dump(report, file, ensure_ascii=False, indent=2)
    return report


def main():
    parser = argparse.ArgumentParser(description="Подготовить фрагмент видео локально, не меняя исходник")
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--start", type=float, default=0, help="Начало в секундах")
    parser.add_argument("--duration", type=float, default=30, help="Длительность в секундах")
    parser.add_argument("--mode", choices=("copy", "compress"), default="copy")
    args = parser.parse_args()
    try:
        report = prepare(args.source, args.output, args.start, args.duration, args.mode)
    except (ValueError, OSError, subprocess.SubprocessError) as exc:
        print("Ошибка подготовки фрагмента:", str(exc))
        return 1
    print(json.dumps(report, ensure_ascii=False, indent=2))
    if not report["under_32_mib"]:
        print("Фрагмент больше 32 МиБ: сократите длительность или явно выберите --mode compress с новым именем.")
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
