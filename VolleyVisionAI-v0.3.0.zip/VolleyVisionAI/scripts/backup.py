"""Consistent SQLite backup and checksummed, non-overwriting restore. No cloud upload."""

import argparse
import hashlib
import json
import os
import re
import shutil
import sqlite3
import stat
import subprocess
import tempfile
import zipfile
from contextlib import closing
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath

ROOT = Path(__file__).resolve().parents[1]
RESERVED_WINDOWS_NAMES = {
    "CON",
    "PRN",
    "AUX",
    "NUL",
    *(f"COM{i}" for i in range(1, 10)),
    *(f"LPT{i}" for i in range(1, 10)),
}


def digest(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _publish_no_replace(temporary, output):
    """Publish a closed file without replacing any concurrently created destination."""
    try:
        if os.name == "nt":
            # Windows rename fails if output exists, including on FAT/exFAT.
            os.rename(temporary, output)
        else:
            # POSIX rename would replace output; a same-filesystem hard link is exclusive.
            os.link(temporary, output)
            temporary.unlink()
    except FileExistsError as exc:
        raise ValueError("Файл архива уже существует; выберите новое имя") from exc


def backup(output, include_videos=False, data=None):
    data = Path(data or os.environ.get("VOLLEYVISION_DATA", ROOT / "data")).resolve()
    database = data / "volleyvision.db"
    if not database.is_file():
        raise ValueError("База данных не найдена; сначала выполните миграции")
    output = Path(output).resolve()
    if output.exists():
        raise ValueError("Файл архива уже существует; выберите новое имя")
    output.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary_name = tempfile.mkstemp(prefix=output.name + ".", suffix=".part", dir=output.parent)
    os.close(descriptor)
    temporary = Path(temporary_name)
    manifest = {
        "format": 1,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "originals_included": bool(include_videos),
        "analysis_configuration_included": True,
        "incomplete_uploads_included": bool(include_videos),
        "model_weights_included": False,
        "private_access_credentials_included": False,
        "files": {},
    }
    try:
        with tempfile.TemporaryDirectory() as temp:
            snapshot = Path(temp) / "volleyvision.db"
            # sqlite3.Connection's own context manager does not close the handle.
            # Explicit close is essential before rename / cleanup on Windows.
            with closing(sqlite3.connect(database.as_uri() + "?mode=ro", uri=True)) as source:
                with closing(sqlite3.connect(snapshot)) as dest:
                    source.backup(dest)
                    if dest.execute("PRAGMA integrity_check").fetchone()[0] != "ok":
                        raise ValueError("Не удалось создать целостный снимок базы данных")
                    tables = {row[0] for row in dest.execute("SELECT name FROM sqlite_master WHERE type='table'")}
                    if "videos" in tables:
                        missing_originals = []
                        for video_id, original, proxy in dest.execute(
                            "SELECT id, path, proxy_path FROM videos"
                        ).fetchall():
                            original_file = (data / original.replace("\\", "/")).resolve()
                            if include_videos and (
                                not original_file.is_relative_to(data) or not original_file.is_file()
                            ):
                                missing_originals.append(str(video_id))
                            proxy_file = (data / proxy.replace("\\", "/")).resolve() if proxy else None
                            if proxy and (
                                not include_videos or not proxy_file.is_relative_to(data) or not proxy_file.is_file()
                            ):
                                dest.execute("UPDATE videos SET proxy_path=NULL WHERE id=?", (video_id,))
                        if missing_originals:
                            raise ValueError(
                                "Полная копия невозможна: отсутствуют исходные видео ID "
                                + ", ".join(missing_originals[:10])
                                + ". Создайте копию без видео и сохраните доступные файлы отдельно."
                            )
                    dest.commit()
            bundle = Path(temp) / "history.bundle"
            subprocess.run(
                ["git", "-C", str(ROOT), "bundle", "create", str(bundle), "--all"], check=True, capture_output=True
            )
            files = subprocess.check_output(["git", "-C", str(ROOT), "ls-files", "-z"]).decode().split("\0")
            with zipfile.ZipFile(temporary, "w", compression=zipfile.ZIP_DEFLATED, allowZip64=True) as z:

                def put(path, name):
                    if path.is_symlink():
                        raise ValueError("Символические ссылки не включаются в архив")
                    checksum = hashlib.sha256()
                    # The checksum covers precisely the archived bytes, even if a file
                    # changes between the earlier directory listing and this read.
                    with path.open("rb") as source, z.open(name, "w", force_zip64=True) as dest:
                        for chunk in iter(lambda: source.read(1024 * 1024), b""):
                            checksum.update(chunk)
                            dest.write(chunk)
                    manifest["files"][name] = checksum.hexdigest()

                for name in files:
                    if name:
                        put(ROOT / name, "code/" + name)
                put(snapshot, "data/volleyvision.db")
                put(bundle, "history.bundle")
                for folder in (
                    ("exports", "setup", "analysis", "derived", "originals", "uploads")
                    if include_videos
                    else ("exports", "setup", "analysis")
                ):
                    for path in (data / folder).rglob("*"):
                        if path.is_file() and ".tmp." not in path.name and path.suffix != ".part":
                            put(path, "data/" + path.relative_to(data).as_posix())
                z.writestr("manifest.json", json.dumps(manifest, ensure_ascii=False, indent=2))
            _publish_no_replace(temporary, output)
    finally:
        temporary.unlink(missing_ok=True)
    return output


def _validate_archive(z, manifest):
    if not isinstance(manifest, dict) or manifest.get("format") != 1 or not isinstance(manifest.get("files"), dict):
        raise ValueError("Неизвестный формат архива")
    names = z.namelist()
    if len(names) != len(set(names)) or set(names) != set(manifest["files"]) | {"manifest.json"}:
        raise ValueError("Список файлов архива не совпадает с манифестом")
    portable_names = set()
    for info in z.infolist():
        path = PurePosixPath(info.filename)
        if not path.parts or path.is_absolute() or ".." in path.parts or "\\" in info.filename or ":" in info.filename:
            raise ValueError("Недопустимый путь в архиве")
        if info.is_dir() or stat.S_ISLNK(info.external_attr >> 16):
            raise ValueError("Архив содержит недопустимый тип записи")
        for part in path.parts:
            if part.endswith((".", " ")) or part.split(".")[0].upper() in RESERVED_WINDOWS_NAMES:
                raise ValueError("Недопустимый для Windows путь в архиве")
        # Reject case aliases and normalized paths before extraction, on every OS.
        portable = path.as_posix().casefold()
        if portable in portable_names or path.as_posix() != info.filename:
            raise ValueError("Архив содержит совпадающие пути")
        portable_names.add(portable)
        if info.filename not in {"manifest.json", "history.bundle"} and path.parts[0] not in {"code", "data"}:
            raise ValueError("Недопустимый корневой каталог")
        if (
            path.parts[0] == "code"
            and len(path.parts) > 1
            and path.parts[1].casefold() in {".git", "data", "manifest.json", "history.bundle"}
        ):
            raise ValueError("Архив содержит конфликтующие каталоги проекта")
    if not {"history.bundle", "data/volleyvision.db"}.issubset(names) or not any(n.startswith("code/") for n in names):
        raise ValueError("В архиве отсутствуют обязательные файлы")
    if not isinstance(manifest.get("originals_included"), bool):
        raise ValueError("Неверные сведения о видео в архиве")
    if any(not isinstance(h, str) or re.fullmatch(r"[0-9a-f]{64}", h) is None for h in manifest["files"].values()):
        raise ValueError("Некорректная контрольная сумма в манифесте")


def restore(archive, destination):
    destination = Path(destination).resolve()
    if destination.exists():
        raise ValueError("Для восстановления укажите новую, несуществующую папку")
    with zipfile.ZipFile(archive) as z:
        try:
            manifest = json.loads(z.read("manifest.json"))
        except (KeyError, json.JSONDecodeError, UnicodeDecodeError) as exc:
            raise ValueError("Манифест архива отсутствует или повреждён") from exc
        _validate_archive(z, manifest)
        destination.parent.mkdir(parents=True, exist_ok=True)
        if sum(info.file_size for info in z.infolist()) + 256 * 1024**2 > shutil.disk_usage(destination.parent).free:
            raise ValueError("Недостаточно места для восстановления архива")
        with tempfile.TemporaryDirectory(dir=destination.parent) as temp:
            staging = Path(temp) / "restore"
            staging.mkdir()
            z.extractall(staging)
            for name, expected in manifest["files"].items():
                if digest(staging / name) != expected:
                    raise ValueError("Контрольная сумма не совпала: " + name)
            database = staging / "data" / "volleyvision.db"
            with closing(sqlite3.connect(database.as_uri() + "?mode=ro", uri=True)) as db:
                if db.execute("PRAGMA integrity_check").fetchone()[0] != "ok":
                    raise ValueError("База данных повреждена")
            recovered_git = Path(temp) / "git-history"
            subprocess.run(
                ["git", "clone", str(staging / "history.bundle"), str(recovered_git)], check=True, capture_output=True
            )
            subprocess.run(
                ["git", "-C", str(recovered_git), "remote", "remove", "origin"], check=True, capture_output=True
            )
            (recovered_git / ".git").rename(staging / ".git")
            (staging / "history.bundle").unlink()
            for item in (staging / "code").iterdir():
                item.rename(staging / item.name)
            (staging / "code").rmdir()
            if not manifest["originals_included"]:
                (staging / "MISSING_VIDEOS.txt").write_text(
                    "Исходные видео и незавершённые загрузки не включены. Скопируйте originals/ отдельно. Прокси создайте повторно. Настройки/карточки, анализ и события сохранены. Веса переустановите setup-ai.ps1; приватный доступ настройте заново.\n",
                    encoding="utf-8",
                )
            # mkdir with exclusive creation prevents racing replacement of an empty
            # destination on POSIX. Only our freshly created directory is populated.
            try:
                destination.mkdir()
            except FileExistsError as exc:
                raise ValueError("Для восстановления укажите новую, несуществующую папку") from exc
            try:
                for item in staging.iterdir():
                    item.rename(destination / item.name)
            except BaseException:
                # Leave partial restoration in its new directory for diagnosis;
                # never remove anything that might now belong to the caller.
                raise
    return destination


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="command", required=True)
    b = sub.add_parser("backup")
    b.add_argument("--output", required=True)
    b.add_argument("--include-videos", action="store_true")
    r = sub.add_parser("restore")
    r.add_argument("--archive", required=True)
    r.add_argument("--destination", required=True)
    args = parser.parse_args()
    if args.command == "backup":
        print(backup(args.output, args.include_videos))
    else:
        print(restore(args.archive, args.destination))
