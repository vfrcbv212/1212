"""Reproducible real-photo/model pilot, explicitly not a volleyball accuracy benchmark."""

import argparse
import json
import platform
import statistics
import sys
import time
import subprocess
import hashlib
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "backend"))


def benchmark(repeats=3):
    import cv2
    from volleyvision.vision import YoloXDetector, box_iou, file_sha256, get_model_manifest

    image_path = ROOT / "backend" / "tests" / "fixtures" / "astronaut.png"
    frame = cv2.imread(str(image_path))
    if frame is None:
        raise ValueError("Разрешённое тестовое изображение не найдено")
    candidates = []
    for model_id in ("yolox-tiny", "yolox-small"):
        detector = YoloXDetector(model_id=model_id, device="cpu")
        for strategy in ("fullframe", "tiles"):
            detector.strategy = strategy
            cold = time.perf_counter()
            detector.detect_frame(frame)
            cold = time.perf_counter() - cold
            timings = []
            for _ in range(repeats):
                started = time.perf_counter()
                detections = detector.detect_frame(frame)
                timings.append(time.perf_counter() - started)
            people = [d for d in detections if d["class_id"] == 0]
            balls = [d for d in detections if d["class_id"] == 32]
            candidate = {
                "model_id": model_id,
                "strategy": strategy,
                "model_sha256": get_model_manifest(model_id)["sha256"],
                "runtime": detector.runtime,
                "cold_inference_seconds": round(cold, 6),
                "warm_inference_seconds": [round(v, 6) for v in timings],
                "warm_median_seconds": round(statistics.median(timings), 6),
                "warm_analyzed_frames_per_second": round(1 / statistics.median(timings), 3),
                "person_count": len(people),
                "ball_count": len(balls),
                "coarse_person_bbox_iou": round(
                    max((box_iou(d["bbox"], [0, 0, 375, 512]) for d in people), default=0), 4
                ),
                "detections": detections,
                "ball_precision": None,
                "ball_recall": None,
                "event_precision": None,
                "event_recall": None,
                "vram_peak_mib": None,
                "vram_reason": "CPUExecutionProvider; GPU/CUDA not tested",
            }
            candidates.append(candidate)
        del detector
    eligible = [row for row in candidates if row["person_count"] == 1 and row["coarse_person_bbox_iou"] >= 0.5]
    selected = min(eligible, key=lambda row: row["warm_median_seconds"]) if eligible else None
    try:
        commit = subprocess.check_output(["git", "-C", str(ROOT), "rev-parse", "HEAD"], text=True).strip()
        dirty = bool(subprocess.check_output(["git", "-C", str(ROOT), "status", "--porcelain"]).strip())
    except (OSError, subprocess.SubprocessError):
        commit, dirty = None, None
    return {
        "build": {
            "git_commit": commit,
            "working_tree_modified": dirty,
            "vision_source_sha256": hashlib.sha256(
                (ROOT / "backend" / "volleyvision" / "vision.py").read_bytes()
            ).hexdigest(),
        },
        "schema": 1,
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "machine": {
            "platform": platform.platform(),
            "python": platform.python_version(),
            "gpu": None,
            "gpu_reason": "NVIDIA/CUDA unavailable in test environment",
        },
        "fixture": {
            "name": "NASA Eileen Collins astronaut.png",
            "sha256": file_sha256(image_path),
            "source": "https://raw.githubusercontent.com/scikit-image/scikit-image/v0.19.3/skimage/data/astronaut.png",
            "rights": "public domain per scikit-image astronaut documentation",
            "width": 512,
            "height": 512,
            "real_photograph": True,
            "volleyball_match": False,
            "people": 1,
            "sports_balls": 0,
            "coarse_manual_person_bbox": [0, 0, 375, 512],
        },
        "candidates": candidates,
        "selection": {"model_id": selected["model_id"], "strategy": selected["strategy"]} if selected else None,
        "selection_scope": "Fastest tested CPU option matching a single real-person smoke fixture; NOT best volleyball/ball model",
        "limitations": [
            "No real match or ball-labelled frame available",
            "No ball/event accuracy measured",
            "No jersey OCR or identity accuracy",
            "No Windows/NVIDIA/iPhone validation",
            "Three warm passes on one photo are an operational pilot, not statistical generalization",
        ],
        "all_candidates_ran": len(candidates) == 4,
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=ROOT / "docs" / "CPU_MODEL_PILOT.json")
    parser.add_argument("--repeats", type=int, default=3)
    args = parser.parse_args()
    if not 1 <= args.repeats <= 20:
        parser.error("--repeats must be 1..20")
    result = benchmark(args.repeats)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(
        json.dumps(
            {
                "output": str(args.output),
                "selection": result["selection"],
                "all_candidates_ran": result["all_candidates_ran"],
            },
            ensure_ascii=False,
        )
    )
