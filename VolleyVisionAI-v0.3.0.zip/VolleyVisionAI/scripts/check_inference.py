"""Execute an actual local model session; a synthetic blank frame is a device smoke test only."""

import argparse
import json
import os
from pathlib import Path
import sys

os.environ.setdefault("ORT_DISABLE_TELEMETRY", "1")
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "backend"))


def main():
    parser = argparse.ArgumentParser(description="Проверка весов и фактического исполнения ONNX, без передачи видео")
    parser.add_argument("--device", choices=["auto", "cpu", "cuda"], default="auto")
    parser.add_argument("--model", choices=["yolox-tiny", "yolox-small"], default="yolox-tiny")
    args = parser.parse_args()
    import numpy as np
    from volleyvision.vision import YoloXDetector

    detector = YoloXDetector(model_id=args.model, device=args.device)
    detections = detector.detect_frame(np.zeros((416, 416, 3), dtype=np.uint8))
    report = {
        "model_id": args.model,
        "runtime": detector.runtime,
        "blank_frame_detections": len(detections),
        "model_inference_executed": True,
        "accuracy_measured": False,
        "all_operations_on_gpu_proven": False,
        "note": "Реальный запуск на искусственном пустом кадре. Это не качество распознавания матча; provider не доказывает размещение каждой операции на GPU.",
    }
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
