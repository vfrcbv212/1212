"""Loopback-only server with authenticated, graceful local stop."""

import json
import os
import secrets
import socket
import sys
import tempfile
import threading
import time
import webbrowser
from contextlib import ExitStack
from pathlib import Path

import uvicorn
from alembic import command
from alembic.config import Config

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "backend"))


def _write_state(state, payload):
    descriptor, name = tempfile.mkstemp(prefix="server-", suffix=".tmp", dir=state.parent)
    temporary = Path(name)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8") as f:
            json.dump(payload, f)
            f.flush()
            os.fsync(f.fileno())
        os.replace(temporary, state)
    finally:
        temporary.unlink(missing_ok=True)


def _read_token(conn):
    data = bytearray()
    while len(data) <= 64:
        chunk = conn.recv(65 - len(data))
        if not chunk:
            break
        data.extend(chunk)
        if b"\n" in chunk:
            break
    return bytes(data).decode("ascii").strip()


def _same_instance(state, token):
    try:
        payload = json.loads(state.read_text(encoding="utf-8"))
        return payload.get("token") == token
    except (OSError, ValueError, AttributeError):
        return False


def run(profile=None):
    from volleyvision.db import DATA
    from volleyvision.access import load_config

    if profile is not None:
        os.environ["VOLLEYVISION_PROFILE"] = profile
    access = load_config()

    state = DATA / "server.json"
    token = secrets.token_hex(32)
    state_written = False
    finished = threading.Event()
    with ExitStack() as stack:
        service = stack.enter_context(socket.socket())
        if os.name != "nt":
            service.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        # Reserve API before migrations/state: a second start cannot replace the
        # first instance's stop token, and startup failure closes every socket.
        service.bind(("127.0.0.1", 8765))
        control = stack.enter_context(socket.socket())
        control.bind(("127.0.0.1", 0))
        control.listen(2)
        command.upgrade(Config(str(ROOT / "alembic.ini")), "head")
        server = uvicorn.Server(
            uvicorn.Config("volleyvision.main:app", host="127.0.0.1", port=8765, proxy_headers=False)
        )
        try:
            _write_state(state, {"pid": os.getpid(), "token": token, "port": control.getsockname()[1]})
            state_written = True

            def listen():
                while not finished.is_set() and not server.should_exit:
                    try:
                        control.settimeout(0.5)
                        conn, _ = control.accept()
                        with conn:
                            conn.settimeout(2)
                            supplied = _read_token(conn)
                            if secrets.compare_digest(supplied, token):
                                server.should_exit = True
                                conn.sendall(b"OK")
                                conn.recv(1)
                    except (OSError, UnicodeError):
                        pass

            threading.Thread(target=listen, daemon=True, name="local-stop").start()
            if "--no-browser" not in sys.argv:

                def open_when_ready():
                    for _ in range(300):
                        if finished.wait(0.1):
                            return
                        if server.started:
                            webbrowser.open(access.public_origin)
                            return

                threading.Thread(target=open_when_ready, daemon=True, name="open-browser").start()
            server.run(sockets=[service])
            if not server.started:
                raise RuntimeError(
                    "Сервер не запустился. Проверьте ошибки запуска выше; приложение не готово к работе."
                )
        finally:
            finished.set()
            control.close()
            service.close()
            if state_written and _same_instance(state, token):
                state.unlink(missing_ok=True)


def stop(timeout=30):
    from volleyvision.db import DATA

    state_path = DATA / "server.json"
    try:
        state = json.loads(state_path.read_text(encoding="utf-8"))
        token, port = state["token"], state["port"]
        if not isinstance(token, str) or len(token) != 64 or not isinstance(port, int) or not 0 < port < 65536:
            raise ValueError("invalid runtime state")
    except (OSError, ValueError, KeyError, TypeError) as exc:
        raise RuntimeError("Запущенный сервер не найден. Проверьте окно приложения.") from exc
    try:
        with socket.create_connection(("127.0.0.1", port), timeout=5) as conn:
            conn.sendall((token + "\n").encode("ascii"))
            if conn.recv(20) != b"OK":
                raise RuntimeError("Остановка не подтверждена")
    except OSError as exc:
        raise RuntimeError("Сервер не отвечает на запрос остановки. Проверьте окно приложения.") from exc
    deadline = time.monotonic() + timeout
    while _same_instance(state_path, token):
        if time.monotonic() >= deadline:
            raise RuntimeError(
                "Остановка запрошена, но сервер ещё завершает задачи. Дождитесь завершения в окне приложения."
            )
        time.sleep(0.1)
    print("Сервер остановлен, текущие данные сохранены.")


if __name__ == "__main__":
    if "--stop" in sys.argv:
        stop()
    else:
        import argparse

        parser = argparse.ArgumentParser(description="VolleyVision: локальный или приватный профиль")
        parser.add_argument("--profile", choices=("local", "remote-private"), default=None)
        parser.add_argument("--no-browser", action="store_true")
        args = parser.parse_args()
        run(args.profile)
