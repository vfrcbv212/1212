﻿param(
    [string]$Hostname,
    [string[]]$AllowedLogins,
    [switch]$ConfigureServe
)
$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
$python = Join-Path $PSScriptRoot '.venv\Scripts\python.exe'
if (-not (Test-Path $python)) { throw 'Сначала выполните .\setup.ps1' }
if (-not (Test-Path 'frontend\dist\index.html')) { throw 'Интерфейс не собран. Выполните .\setup.ps1' }
if ($ConfigureServe) {
    if (-not $Hostname -or -not $AllowedLogins -or $AllowedLogins.Count -eq 0) {
        throw 'Для настройки нужны -Hostname pc.tailnet.ts.net и -AllowedLogins user@example.com'
    }
    if (-not (Get-Command tailscale -ErrorAction SilentlyContinue)) {
        throw 'Установите официальный Tailscale на Windows, войдите в свой tailnet и прочитайте docs\REMOTE_PRIVATE.md. Скрипт ничего не устанавливает.'
    }
    $statusText = & tailscale status --json 2>$null
    if ($LASTEXITCODE -ne 0) { throw 'Tailscale не подключён. Войдите в свой tailnet.' }
    $status = $statusText | ConvertFrom-Json
    if ($status.BackendState -ne 'Running') { throw 'Tailscale ещё не подключён.' }
    $actualHost = ([string]$status.Self.DNSName).TrimEnd('.').ToLowerInvariant()
    if ($Hostname.Trim().ToLowerInvariant() -ne $actualHost) { throw 'Hostname не совпадает с DNSName этого устройства в tailscale status. Укажите точное имя.' }
    $arguments = @('scripts\remote_private.py','configure','--hostname',$actualHost)
    foreach ($login in $AllowedLogins) { $arguments += @('--allow-login',$login) }
    & $python @arguments
    if ($LASTEXITCODE -ne 0) { throw 'Не удалось сохранить конфигурацию приватного доступа.' }
    # Keep this capability out of browser URLs, scripts, Git and console logs.
    $target = (& $python scripts\remote_private.py target).Trim()
    if ($LASTEXITCODE -ne 0) { throw 'Не удалось прочитать приватную конфигурацию.' }
    $serveText = & tailscale serve status --json 2>$null
    if ($LASTEXITCODE -ne 0) { throw 'Не удалось прочитать существующие настройки Serve. Они не будут заменены.' }
    $serveState = $serveText | ConvertFrom-Json
    $existingHost = $serveState.Web.PSObject.Properties | Where-Object { $_.Name -eq "${actualHost}:443" }
    if ($existingHost) {
        $existingRoot = $existingHost.Value.Handlers.PSObject.Properties | Where-Object { $_.Name -eq '/' }
        if ($existingRoot -and $existingRoot.Value.Proxy -ne $target) {
            $target = $null
            throw 'На этом приватном адресе уже настроен другой Serve. Его настройки не заменены; сохраните и согласуйте их отдельно.'
        }
    }
    & tailscale serve --bg --https=443 $target *> $null
    if ($LASTEXITCODE -ne 0) { throw 'Tailscale Serve не настроен. Проверьте HTTPS/MagicDNS и права tailnet; Funnel и проброс роутера не используйте.' }
    $target = $null
    Write-Host ('Приватный Serve настроен: https://' + $actualHost + '. Доступ проверяется по allowed logins.')
}
& $python scripts\remote_private.py public
if ($LASTEXITCODE -ne 0) { throw 'Приватный профиль ещё не настроен. См. docs\REMOTE_PRIVATE.md.' }
Write-Host 'Запускается remote-private на loopback. Для остановки используйте Ctrl+C или stop.ps1.'
& $python scripts\serve.py --profile remote-private
if ($LASTEXITCODE -ne 0) { throw 'Сервер завершился с ошибкой. См. журнал выше.' }
