﻿param(
    [ValidateSet('cpu','cuda')][string]$Device = 'cpu',
    [ValidateSet('yolox-tiny','yolox-small','all')][string]$Model = 'yolox-tiny'
)
$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
$python = Join-Path $PSScriptRoot '.venv\Scripts\python.exe'
if (-not (Test-Path $python)) { throw 'Сначала выполните setup.ps1. Данные data не удаляются.' }
if ($Device -eq 'cuda') {
    if (-not (Get-Command nvidia-smi -ErrorAction SilentlyContinue)) { throw 'nvidia-smi не найден. Сначала проверьте драйвер NVIDIA вручную или выберите -Device cpu.' }
    & nvidia-smi --query-gpu=name,driver_version,memory.total --format=csv,noheader
    if ($LASTEXITCODE -ne 0) { throw 'Драйвер NVIDIA не отвечает. Драйверы этот скрипт не меняет; доступен -Device cpu.' }
    & $python -c "import shutil; assert shutil.disk_usage('.').free > 3*1024**3, 'Для GPU-зависимостей нужно более 3 ГБ свободного места'"
    if ($LASTEXITCODE -ne 0) { throw 'Недостаточно места для GPU-зависимостей.' }
    & $python -m pip uninstall -y onnxruntime
    if ($LASTEXITCODE -ne 0) { throw 'Не удалось переключить ONNX Runtime в локальном venv.' }
    & $python -m pip install --force-reinstall --no-deps onnxruntime-gpu==1.32.0
    if ($LASTEXITCODE -ne 0) { throw 'Не удалось установить ONNX Runtime GPU.' }
    & $python -m pip install -r requirements-ai-cuda.lock
} else {
    & $python -m pip uninstall -y onnxruntime-gpu
    if ($LASTEXITCODE -ne 0) { throw 'Не удалось переключить ONNX Runtime в локальном venv.' }
    & $python -m pip install --force-reinstall --no-deps onnxruntime==1.32.0
    if ($LASTEXITCODE -ne 0) { throw 'Не удалось установить ONNX Runtime CPU.' }
    & $python -m pip install -r requirements-ai.lock
}
if ($LASTEXITCODE -ne 0) { throw 'Установка AI-зависимостей завершилась ошибкой. Системные драйверы не менялись; см. docs/MODEL_SOURCES.md.' }
& $python scripts\install_models.py --model $Model
if ($LASTEXITCODE -ne 0) { throw 'Веса не установлены или SHA256 не совпала. Проверку отключать нельзя.' }
$verifyModel = if ($Model -eq 'all') { 'yolox-tiny' } else { $Model }
& $python scripts\check_inference.py --device $Device --model $verifyModel
if ($LASTEXITCODE -ne 0) { throw 'Реальное исполнение модели не подтверждено. Для CUDA проверьте совместимость драйвера с CUDA13/cuDNN9; доступен setup-ai.ps1 -Device cpu.' }
Write-Host 'Локальный детектор установлен и проверен. Это детекция людей/мяча, а не полный распознаватель волейбольных действий. Запуск: start.ps1'
