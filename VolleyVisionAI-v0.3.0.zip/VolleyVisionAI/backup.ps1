﻿param([switch]$IncludeVideos)
$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
$output = Join-Path $PSScriptRoot ('backups\volleyvision-' + (Get-Date -Format 'yyyyMMdd-HHmmss-fff') + '.zip')
$arguments = @('scripts\backup.py','backup','--output',$output)
if ($IncludeVideos) { $arguments += '--include-videos' }
& .\.venv\Scripts\python.exe @arguments
if ($LASTEXITCODE -ne 0) { throw 'Резервная копия не создана.' }
