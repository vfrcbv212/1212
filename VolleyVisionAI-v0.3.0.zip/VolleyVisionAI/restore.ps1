﻿param([Parameter(Mandatory=$true)][string]$Archive, [Parameter(Mandatory=$true)][string]$Destination)
$ErrorActionPreference = 'Stop'
$archivePath = (Resolve-Path -LiteralPath $Archive).ProviderPath
$destinationPath = $ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($Destination)
Set-Location $PSScriptRoot
& .\.venv\Scripts\python.exe scripts\backup.py restore --archive $archivePath --destination $destinationPath
if ($LASTEXITCODE -ne 0) { throw 'Восстановление не выполнено. Текущие данные не заменены.' }
Write-Host 'Проект восстановлен в новую папку. В ней выполните setup.ps1. Если видео не были включены, скопируйте data\originals отдельно.'
