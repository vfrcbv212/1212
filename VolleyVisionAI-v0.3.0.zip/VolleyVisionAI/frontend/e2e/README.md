# Browser E2E
Из frontend: `npx playwright install chromium`, затем `npx playwright test`.
Нужны Python venv, FFmpeg и собранный UI (`npm run build`). Порт 8765 должен быть свободен. Тест сам создаёт отдельный data-каталог в системной temp, не меняет пользовательскую БД.
В Linux со штатным Chromium: `CHROMIUM_PATH=/usr/bin/chromium npx playwright test`. Наличие такой переменной не нужно на Windows после playwright install.
Тест создаёт искусственное видео (не матч), проверяет интерфейс создания команд/игрока/матча, импорт, реальную загрузку видеоплеера, разметку, исправление, статистику, MP4, скачивание XLSX, сохранение после reload, desktop/mobile screenshots. Результаты игнорируются Git.
