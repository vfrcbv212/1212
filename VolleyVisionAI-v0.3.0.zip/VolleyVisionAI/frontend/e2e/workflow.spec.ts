import { test, expect } from "@playwright/test";
import { execFileSync } from "node:child_process";
import { mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";

test("create teams, upload video, annotate, correct, export and persist", async ({
  page,
}) => {
  const temp = mkdtempSync(join(tmpdir(), "vv-video-"));
  const file = join(temp, "synthetic.mp4");
  execFileSync("ffmpeg", [
    "-nostdin",
    "-v",
    "error",
    "-f",
    "lavfi",
    "-i",
    "testsrc2=size=320x180:rate=30",
    "-t",
    "4",
    "-c:v",
    "libx264",
    "-threads",
    "2",
    file,
  ]);
  try {
    await page.goto("/");
    await expect(
      page.getByRole("heading", { name: "Каждый розыгрыш имеет значение" }),
    ).toBeVisible();
    await page
      .getByRole("button", { name: "Команды и игроки", exact: true })
      .click();
    const create = page.locator("section").filter({
      has: page.getByRole("heading", {
        name: "Создать команду",
        exact: true,
      }),
    });
    for (const name of ["E2E Север", "E2E Юг"]) {
      await create.getByLabel("Название").fill(name);
      await create
        .getByRole("button", { name: "Добавить команду", exact: true })
        .click();
      await expect(create.getByRole("button")).toBeEnabled();
    }
    const register = page.locator("section").filter({
      has: page.getByRole("heading", {
        name: "Зарегистрировать игрока",
        exact: true,
      }),
    });
    await register.getByLabel("ФИО").fill("E2E Игрок");
    await register
      .getByRole("combobox", { name: "Команда", exact: true })
      .selectOption({ label: "E2E Север" });
    await register.getByLabel("Номер", { exact: true }).fill("7");
    await register
      .getByRole("button", { name: "Добавить игрока", exact: true })
      .click();
    await expect(page.getByText("E2E Игрок", { exact: true })).toBeVisible();
    await page.getByRole("button", { name: "Матчи", exact: true }).click();
    const newMatch = page.locator("section").filter({
      has: page.getByRole("heading", { name: "Новый матч", exact: true }),
    });
    await newMatch
      .getByRole("combobox", { name: "Первая команда", exact: true })
      .selectOption({ label: "E2E Север" });
    await newMatch
      .getByRole("combobox", { name: "Вторая команда", exact: true })
      .selectOption({ label: "E2E Юг" });
    await newMatch.getByLabel("Дата", { exact: true }).fill("2026-11-15");
    await newMatch
      .getByRole("button", { name: "Создать матч", exact: true })
      .click();
    await expect(
      page.getByRole("heading", { name: "E2E Север — E2E Юг" }),
    ).toBeVisible();
    await page
      .getByRole("button", { name: "Видео и состав", exact: true })
      .click();
    await page
      .getByLabel("Загрузить видео", { exact: true })
      .setInputFiles(file);
    await expect(
      page.getByText("Видео загружено", { exact: true }),
    ).toBeVisible();
    await page
      .getByRole("button", { name: "Разметка и видео", exact: true })
      .click();
    await expect
      .poll(() =>
        page.locator("video").evaluate((v: HTMLVideoElement) => v.readyState),
      )
      .toBeGreaterThanOrEqual(1);
    const rally = page.locator("section").filter({
      has: page.getByRole("heading", { name: "Новый розыгрыш", exact: true }),
    });
    await rally.getByRole("spinbutton", { name: /^Конец, с/ }).fill("3.8");
    await rally
      .getByRole("combobox", { name: "Подающая", exact: true })
      .selectOption({ label: "E2E Север" });
    await rally
      .getByRole("combobox", { name: "Очко команде", exact: true })
      .selectOption({ label: "E2E Север" });
    await rally.getByRole("button", { name: "Добавить", exact: true }).click();
    await expect(
      page.getByText("Очко: E2E Север", { exact: true }),
    ).toBeVisible();
    const editor = page.locator(".event-editor");
    await editor.getByRole("button", { name: "Атака", exact: true }).click();
    await editor.getByRole("spinbutton", { name: /^Время, с/ }).fill("1.5");
    await editor
      .getByRole("combobox", { name: "Игрок", exact: true })
      .selectOption({ label: "#7 E2E Игрок" });
    await editor
      .getByRole("combobox", { name: "Результат", exact: true })
      .selectOption({ label: "Выигрыш" });
    await editor
      .getByRole("button", { name: "Сохранить действие", exact: true })
      .click();
    await expect(
      page.getByRole("cell", { name: "Выигрыш", exact: true }),
    ).toBeVisible();
    await page.getByRole("button", { name: "Изменить", exact: true }).click();
    await editor
      .getByRole("combobox", { name: "Результат", exact: true })
      .selectOption({ label: "Ошибка" });
    await editor
      .getByRole("button", { name: "Сохранить правку", exact: true })
      .click();
    await expect(
      page.getByRole("cell", { name: "Исправлено вручную", exact: true }),
    ).toBeVisible();
    await page
      .getByRole("checkbox", { name: /Включить событие \d+ в клип/ })
      .first()
      .check();
    await page
      .getByRole("button", { name: "Создать MP4 · −3/+4 с", exact: true })
      .click();
    await expect(
      page.getByRole("link", { name: /Подборка действий #\d+/ }),
    ).toBeVisible();
    await page.getByRole("button", { name: "Статистика", exact: true }).click();
    await expect(
      page.getByRole("cell", { name: "-100.0%", exact: true }),
    ).toBeVisible();
    await expect(page.getByRole("alert")).toContainText(
      "противоречий исходов — 1",
    );
    const download = page.waitForEvent("download");
    await page.getByRole("link", { name: "XLSX", exact: true }).click();
    expect((await download).suggestedFilename()).toMatch(/^match-\d+\.xlsx$/);
    await page.evaluate(() => window.scrollTo(0, 0));
    await page.screenshot({
      path: "test-results/statistics-desktop.png",
      fullPage: true,
    });
    await page.setViewportSize({ width: 390, height: 844 });
    await page.evaluate(() => window.scrollTo(0, 0));
    await page.screenshot({
      path: "test-results/statistics-mobile.png",
      fullPage: true,
    });
    expect(
      await page.evaluate(
        () => document.documentElement.scrollWidth <= innerWidth,
      ),
    ).toBeTruthy();
    await page.reload();
    await page.getByRole("button", { name: /E2E Север — E2E Юг/ }).click();
    await expect(
      page.getByRole("cell", { name: "Исправлено вручную", exact: true }),
    ).toBeVisible();
  } finally {
    rmSync(temp, { recursive: true, force: true });
  }
});
