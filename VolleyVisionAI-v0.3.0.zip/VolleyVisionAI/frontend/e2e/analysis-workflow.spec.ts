import { test, expect } from "@playwright/test";
import { execFileSync } from "node:child_process";
import { mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join, resolve } from "node:path";

test("real local detector: browser import, setup and automatic honest report", async ({
  page,
  request,
}) => {
  test.setTimeout(90000);
  const availability = await (
    await request.get("/api/analysis/runtime")
  ).json();
  test.skip(
    !availability.installed,
    "Install verified local YOLOX Tiny weights and AI dependencies for this real-inference scenario",
  );
  const temp = mkdtempSync(join(tmpdir(), "vv-analysis-e2e-"));
  const file = join(temp, "SYNTHETIC-public-domain-photo-not-volleyball.mp4");
  execFileSync("ffmpeg", [
    "-nostdin",
    "-v",
    "error",
    "-loop",
    "1",
    "-i",
    resolve("../backend/tests/fixtures/astronaut.png"),
    "-t",
    "2",
    "-r",
    "10",
    "-c:v",
    "libx264",
    "-pix_fmt",
    "yuv420p",
    "-threads",
    "2",
    file,
  ]);
  const post = async (path: string, data: unknown) => {
    const r = await request.post("/api" + path, { data });
    expect(r.status(), await r.text()).toBe(201);
    return r.json();
  };
  try {
    const a = await post("/teams", { name: "Analysis E2E North" }),
      b = await post("/teams", { name: "Analysis E2E South" });
    const player = await post("/players", {
      name: "SYNTHETIC card subject",
      team_id: a.id,
      number: "7",
    });
    const match = await post("/matches", {
      home_id: a.id,
      away_id: b.id,
      date: "2026-11-15",
      title: "Constructed inference smoke — not match quality",
    });
    const errors: string[] = [];
    page.on("pageerror", (e) => errors.push(e.message));
    await page.goto("/");
    await page
      .getByRole("button", { name: /Analysis E2E North — Analysis E2E South/ })
      .click();
    await page
      .getByRole("button", { name: "Видео и состав", exact: true })
      .click();
    await page
      .getByLabel("Загрузить видео", { exact: true })
      .setInputFiles(file);
    await expect(
      page.getByText("Видео загружено", { exact: true }),
    ).toBeVisible();
    const detail = await (await request.get(`/api/matches/${match.id}`)).json();
    expect(detail.videos).toHaveLength(1);
    const video = detail.videos[0];
    await page
      .getByRole("button", { name: "Автоанализ и отчёт", exact: true })
      .click();
    const canvas = page.getByRole("img", {
      name: "Разметка стоп-кадра",
      exact: true,
    });
    await expect(canvas).toBeVisible();
    // Requesting the same frame again must remount/reload, not hide its overlay forever.
    await page
      .getByRole("button", { name: "Показать кадр", exact: true })
      .click();
    await expect(canvas).toBeVisible();
    const point = async (x: number, y: number) => {
      const r = await canvas.boundingBox();
      expect(r).not.toBeNull();
      await canvas.click({ position: { x: r!.width * x, y: r!.height * y } });
    };
    // These coordinates test setup mechanics on a constructed clip, not real court accuracy.
    for (const [x, y] of [
      [0.1, 0.1],
      [0.9, 0.1],
      [0.9, 0.9],
      [0.1, 0.9],
    ])
      await point(x, y);
    await page
      .getByRole("button", { name: "Опорные точки пола", exact: true })
      .click();
    for (const [i, p] of [
      [0.2, 0.2],
      [0.8, 0.2],
      [0.8, 0.8],
      [0.2, 0.8],
    ].entries()) {
      await point(p[0], p[1]);
      const c = [
        [3, 2],
        [9, 2],
        [9, 8],
        [3, 8],
      ][i];
      await page
        .getByLabel(`Корт X точки ${i + 1}`, { exact: true })
        .fill(String(c[0]));
      await page
        .getByLabel(`Корт Y точки ${i + 1}`, { exact: true })
        .fill(String(c[1]));
    }
    await page
      .getByRole("combobox", { name: "Режим калибровки", exact: true })
      .selectOption("court");
    await page
      .getByRole("button", { name: "Карточка игрока", exact: true })
      .click();
    await page
      .getByRole("combobox", { name: "Игрок для карточки", exact: true })
      .selectOption(String(player.id));
    await point(0.05, 0.05);
    await point(0.95, 0.95);
    await page
      .getByRole("checkbox", {
        name: "Подтверждаю личность по этим кадрам",
        exact: true,
      })
      .check();
    await page
      .getByRole("button", {
        name: "Сохранить начальную настройку",
        exact: true,
      })
      .click();
    await expect(
      page.getByText("Сохранено · версия 1", { exact: true }),
    ).toBeVisible();
    const setup = await (
      await request.get(`/api/videos/${video.id}/setup`)
    ).json();
    expect(setup.calibration.points).toHaveLength(4);
    expect(setup.calibration.visibility_polygon).toHaveLength(4);
    expect(setup.calibration.mode).toBe("court");
    expect(setup.cards[0].player_id).toBe(player.id);
    expect(setup.cards[0].confirmed).toBe(true);
    await page.getByLabel("FPS анализа", { exact: true }).fill("1");
    await page
      .getByRole("combobox", { name: "Устройство", exact: true })
      .selectOption("cpu");
    await page
      .getByRole("button", { name: "Анализировать", exact: true })
      .click();
    await expect(
      page.getByText("Детекция завершена", { exact: true }),
    ).toBeVisible({ timeout: 60000 });
    await expect(
      page.getByRole("heading", {
        name: "Автоматический отчёт детекции",
        exact: true,
      }),
    ).toBeVisible();
    const reportFrame = page.frameLocator('iframe[title="Отчёт анализа"]');
    await expect(
      reportFrame.getByRole("heading", {
        name: "Объектные наблюдения, не полное распознавание матча",
        exact: true,
      }),
    ).toBeVisible();
    await expect(
      reportFrame.getByText(
        "Автоматически принятых волейбольных действий: 0.",
        { exact: false },
      ),
    ).toBeVisible();
    const latest = await (
      await request.get(`/api/videos/${video.id}/analysis/latest`)
    ).json();
    const report = await (
      await request.get(`/api/matches/${match.id}/report?run_id=${latest.id}`)
    ).json();
    expect(report.coverage.person_observations).toBeGreaterThan(0);
    expect(report.coverage.accepted_events).toBe(0);
    expect(latest.summary.active_providers).toContain("CPUExecutionProvider");
    expect(
      (await (await request.get(`/api/matches/${match.id}`)).json()).events,
    ).toHaveLength(0);
    const jobsBefore = await (await request.get("/api/jobs")).json();
    await page.reload();
    await page
      .getByRole("button", { name: /Analysis E2E North — Analysis E2E South/ })
      .click();
    await page
      .getByRole("button", { name: "Автоанализ и отчёт", exact: true })
      .click();
    await expect(
      page.getByRole("heading", {
        name: "Автоматический отчёт детекции",
        exact: true,
      }),
    ).toBeVisible();
    expect(await (await request.get("/api/jobs")).json()).toHaveLength(
      jobsBefore.length,
    );
    expect(
      (
        await (
          await request.get(`/api/videos/${video.id}/analysis/latest`)
        ).json()
      ).id,
    ).toBe(latest.id);
    const downloading = page.waitForEvent("download");
    await page
      .getByRole("link", { name: "Скачать HTML-отчёт", exact: true })
      .click();
    expect((await downloading).suggestedFilename()).toBe(
      `volleyvision-match-${match.id}-analysis-${latest.id}.html`,
    );
    expect(errors).toEqual([]);
    await page.screenshot({
      path: "test-results/real-detector-report-desktop.png",
      fullPage: true,
    });
  } finally {
    rmSync(temp, { recursive: true, force: true });
  }
});
