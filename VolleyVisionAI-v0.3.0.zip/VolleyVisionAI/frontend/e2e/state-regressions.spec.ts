import { test, expect } from "@playwright/test";
import { execFileSync } from "node:child_process";
import { mkdtempSync, readFileSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";

test("annotation follows selected rally and video; switching matches clears old edits", async ({
  page,
  request,
}) => {
  const temp = mkdtempSync(join(tmpdir(), "vv-regression-"));
  const fileA = join(temp, "a.mp4"),
    fileB = join(temp, "b.mp4");
  execFileSync("ffmpeg", [
    "-nostdin",
    "-v",
    "error",
    "-f",
    "lavfi",
    "-i",
    "testsrc2=size=320x180:rate=30",
    "-t",
    "4",
    "-c:v",
    "libx264",
    "-threads",
    "2",
    fileA,
  ]);
  execFileSync("ffmpeg", [
    "-nostdin",
    "-v",
    "error",
    "-i",
    fileA,
    "-vf",
    "hflip",
    "-c:v",
    "libx264",
    "-threads",
    "2",
    fileB,
  ]);
  const post = async (path: string, body: unknown) => {
    const r = await request.post("/api" + path, { data: body });
    expect(r.status(), await r.text()).toBe(201);
    return r.json();
  };
  const upload = async (mid: number, path: string, name: string) => {
    const r = await request.post(`/api/matches/${mid}/videos`, {
      multipart: {
        file: { name, mimeType: "video/mp4", buffer: readFileSync(path) },
      },
    });
    expect(r.status(), await r.text()).toBe(201);
    return r.json();
  };
  try {
    const a = await post("/teams", { name: "Regression A" }),
      b = await post("/teams", { name: "Regression B" }),
      c = await post("/teams", { name: "Regression C" });
    const player = await post("/players", {
      name: "Regression Player",
      team_id: a.id,
      number: "4",
    });
    const first = await post("/matches", {
      home_id: a.id,
      away_id: b.id,
      date: "2026-11-15",
    });
    const second = await post("/matches", {
      home_id: b.id,
      away_id: c.id,
      date: "2026-11-15",
    });
    const va = await upload(first.id, fileA, "first-source.mp4"),
      vb = await upload(first.id, fileB, "second-source.mp4");
    await upload(second.id, fileA, "other-match.mp4");
    const detail = await (await request.get(`/api/matches/${first.id}`)).json();
    const r1 = await post(`/matches/${first.id}/rallies`, {
      set_id: detail.sets[0].id,
      video_id: va.id,
      start: 0,
      end: 1.5,
      winner_team_id: a.id,
    });
    const r2 = await post(`/matches/${first.id}/rallies`, {
      set_id: detail.sets[0].id,
      video_id: va.id,
      start: 2,
      end: 3.8,
    });
    const rb = await post(`/matches/${first.id}/rallies`, {
      set_id: detail.sets[0].id,
      video_id: vb.id,
      start: 1,
      end: 3,
    });
    const event = await post(`/matches/${first.id}/events`, {
      rally_id: r1.id,
      time: 1,
      kind: "attack",
      team_id: a.id,
      player_id: player.id,
      outcome: "kill",
    });
    const errors: string[] = [];
    page.on("pageerror", (e) => errors.push(e.message));
    await page.goto("/");
    await page
      .getByRole("button", { name: /Regression A — Regression B/ })
      .click();
    const editor = page.locator(".event-editor");
    await expect(
      editor.getByRole("combobox", { name: "Розыгрыш", exact: true }),
    ).toHaveValue(String(r1.id));
    await page.locator(".rally-item").nth(1).locator("button").first().click();
    await expect(
      editor.getByRole("combobox", { name: "Розыгрыш", exact: true }),
    ).toHaveValue(String(r2.id));
    await expect(
      editor.getByRole("spinbutton", { name: /^Время, с/ }),
    ).toHaveValue("2");
    await page
      .getByRole("combobox", { name: "Скорость", exact: true })
      .selectOption("0.5");
    await page
      .locator(".player-panel")
      .getByRole("combobox", { name: "Видео", exact: true })
      .selectOption(String(vb.id));
    await expect(
      editor.getByRole("combobox", { name: "Розыгрыш", exact: true }),
    ).toHaveValue(String(rb.id));
    await expect(
      editor.getByRole("spinbutton", { name: /^Время, с/ }),
    ).toHaveValue("1");
    await expect
      .poll(() =>
        page.locator("video").evaluate((v: HTMLVideoElement) => v.playbackRate),
      )
      .toBe(0.5);
    await editor
      .getByRole("combobox", { name: "Розыгрыш", exact: true })
      .selectOption(String(r2.id));
    await expect(
      page
        .locator(".player-panel")
        .getByRole("combobox", { name: "Видео", exact: true }),
    ).toHaveValue(String(va.id));
    await expect
      .poll(() =>
        page.locator("video").evaluate((v: HTMLVideoElement) => v.currentTime),
      )
      .toBeCloseTo(2, 1);
    // Saving from the second source must retain that source's rally and raw time.
    await editor
      .getByRole("combobox", { name: "Розыгрыш", exact: true })
      .selectOption(String(rb.id));
    await editor.getByRole("spinbutton", { name: /^Время, с/ }).fill("2.25");
    await editor
      .getByRole("button", { name: "Сохранить действие", exact: true })
      .click();
    await expect(page.getByText("Сохранено", { exact: true })).toBeVisible();
    const saved = await (await request.get(`/api/matches/${first.id}`)).json();
    const latest = saved.events.find((e: { id: number }) => e.id !== event.id);
    expect(latest.video_id).toBe(vb.id);
    expect(latest.rally_id).toBe(rb.id);
    expect(latest.time).toBe(2.25);
    // Edit mode preserves its own source even while the viewer is switched.
    const row = page.getByRole("row").filter({
      has: page.getByLabel(`Включить событие ${event.id} в клип`, {
        exact: true,
      }),
    });
    await row.getByRole("button", { name: "Изменить", exact: true }).click();
    await expect(
      page
        .locator(".player-panel")
        .getByRole("combobox", { name: "Видео", exact: true }),
    ).toHaveValue(String(va.id));
    await page
      .locator(".player-panel")
      .getByRole("combobox", { name: "Видео", exact: true })
      .selectOption(String(vb.id));
    await expect(
      editor.getByRole("button", { name: "Текущий кадр", exact: true }),
    ).toBeDisabled();
    await row.getByRole("checkbox").check();
    await page
      .getByRole("combobox", { name: "Фильтр действий", exact: true })
      .selectOption("attack");
    await page.getByRole("button", { name: "Матчи", exact: true }).click();
    await page
      .getByRole("button", { name: /Regression B — Regression C/ })
      .click();
    await expect(
      page.getByRole("heading", { name: "Добавить действие", exact: true }),
    ).toBeVisible();
    await expect(
      page.getByRole("heading", { name: "Исправить действие", exact: true }),
    ).toHaveCount(0);
    await expect(
      page.getByText("0 выбрано для подборки", { exact: true }),
    ).toBeVisible();
    await expect(
      page.getByRole("combobox", { name: "Фильтр действий", exact: true }),
    ).toHaveValue("");
    await expect(
      editor.getByRole("button", { name: "Сохранить действие", exact: true }),
    ).toBeDisabled();
    expect(errors).toEqual([]);
  } finally {
    rmSync(temp, { recursive: true, force: true });
  }
});
