export type Team = { id: number; name: string };
export type Player = {
  id: number;
  name: string;
  role: string;
  memberships: { team_id: number; number: string | null }[];
};
export type Match = {
  id: number;
  home_id: number;
  away_id: number;
  date: string;
  title: string;
};
export type Video = {
  id: number;
  name: string;
  duration: number;
  width: number;
  height: number;
  fps: number;
  codec: string;
  size: number;
  proxy_path: string | null;
  position: number;
  offset: number | null;
};
export type Rally = {
  id: number;
  revision: number;
  set_id: number;
  video_id: number;
  start: number;
  end: number;
  serving_team_id: number | null;
  winner_team_id: number | null;
  rotation: number | null;
};
export type GameEvent = {
  id: number;
  rally_id: number;
  video_id: number;
  time: number;
  kind: string;
  team_id: number;
  player_id: number | null;
  outcome: string | null;
  quality: number | null;
  zone_from: number | null;
  zone_to: number | null;
  rotation: number | null;
  subtype: string | null;
  revision: number;
  status: string;
};
export type Detail = Match & {
  videos: Video[];
  rallies: Rally[];
  events: GameEvent[];
  sets: {
    id: number;
    number: number;
    initial_home: number;
    initial_away: number;
  }[];
  roster: {
    player_id: number;
    team_id: number;
    number: string | null;
    libero: boolean;
  }[];
  clips: { id: number; name: string }[];
};
export type ActionStats = {
  attempts: number;
  known_outcomes: number;
  unknown_outcomes: number;
  win_pct?: number | null;
  efficiency?: number | null;
  graded?: number;
  average?: number | null;
  positive_pct?: number | null;
  outcomes: Record<string, number>;
};
export type Summary = {
  events: number;
  counts: Record<string, number>;
  serve: ActionStats;
  attack: ActionStats;
  reception: ActionStats;
  block: ActionStats;
  dig: ActionStats;
  set: ActionStats;
};
export type Stats = {
  trusted_events: number;
  pending_events: number;
  teams: Record<
    string,
    Summary & {
      players: Record<string, Summary>;
      sideout: { pct: number | null; total: number };
      breakpoint: { pct: number | null; total: number };
    }
  >;
  sets: {
    number: number;
    home: number;
    away: number;
    unknown_rallies: number;
  }[];
  data_quality?: {
    grade_conflict_count: number;
    terminal_conflict_count: number;
    overlapping_rally_ids?: number[];
  };
  methodology: string;
};
export const kinds: Record<string, string> = {
  serve: "Подача",
  reception: "Приём",
  set: "Передача",
  attack: "Атака",
  block: "Блок",
  dig: "Защита",
  cover: "Подстраховка",
  freeball: "Свободный мяч",
  error: "Ошибка",
};
export const outcomes: Record<string, Record<string, string>> = {
  serve: { ace: "Эйс", error: "Ошибка", in_play: "В игру" },
  reception: { error: "Ошибка", continued: "Продолжение" },
  set: { error: "Ошибка", continued: "Продолжение" },
  attack: {
    kill: "Выигрыш",
    error: "Ошибка",
    blocked: "Закрыта блоком",
    continued: "Продолжение",
  },
  block: {
    point: "Блок-очко",
    touch: "Касание",
    error: "Ошибка",
    continued: "Продолжение",
  },
  dig: { error: "Ошибка", continued: "Продолжение" },
  cover: { error: "Ошибка", continued: "Продолжение" },
  freeball: { error: "Ошибка", continued: "Продолжение" },
  error: { error: "Ошибка" },
};
export const stamp = (n: number) =>
  `${Math.floor(n / 60)}:${Math.floor(n % 60)
    .toString()
    .padStart(2, "0")}`;
export const pct = (n: number | null | undefined) =>
  n == null || !Number.isFinite(n) ? "—" : `${n.toFixed(1)}%`;
