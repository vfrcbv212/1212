import React, { useEffect, useRef, useState } from "react";
import { createRoot } from "react-dom/client";
import {
  Activity,
  ArrowLeft,
  ArrowRight,
  CheckCircle2,
  ChevronRight,
  Download,
  Film,
  LayoutDashboard,
  Moon,
  Play,
  Plus,
  Sun,
  Target,
  Users,
  Volleyball,
} from "lucide-react";
import { api } from "./api";
import {
  Detail,
  GameEvent,
  Match,
  Player,
  Rally,
  Stats,
  Team,
  kinds,
  outcomes,
  pct,
  stamp,
} from "./types";
import { VideoImport } from "./components/VideoImport";
import { AnalysisWorkspace } from "./components/AnalysisWorkspace";
import "./style.css";

function storedTheme() {
  try {
    return localStorage.getItem("theme") === "light";
  } catch {
    return false;
  }
}

function App() {
  const [teams, setTeams] = useState<Team[]>([]),
    [players, setPlayers] = useState<Player[]>([]),
    [matches, setMatches] = useState<Match[]>([]);
  const [page, setPage] = useState("home"),
    [match, setMatch] = useState<Detail | null>(null),
    [stats, setStats] = useState<Stats | null>(null);
  const [error, setError] = useState(""),
    [notice, setNotice] = useState(""),
    [busy, setBusy] = useState(false),
    [light, setLight] = useState(storedTheme);
  const [jobs, setJobs] = useState<
    { id: number; video_id: number; status: string; error: string | null }[]
  >([]);
  const [videoId, setVideoId] = useState(0),
    [rallyId, setRallyId] = useState(0),
    [tab, setTab] = useState("review");
  const [time, setTime] = useState(0),
    [kindFilter, setKindFilter] = useState(""),
    [playerFilter, setPlayerFilter] = useState("");
  const [editing, setEditing] = useState<GameEvent | null>(null),
    [editingRally, setEditingRally] = useState<Rally | null>(null),
    [selected, setSelected] = useState<number[]>([]);
  const [history, setHistory] = useState<unknown>(null);
  const video = useRef<HTMLVideoElement>(null);
  const activeMatchId = useRef<number | null>(null);
  const operationPending = useRef(false);
  const pendingSeek = useRef<{ videoId: number; time: number } | null>(null);
  const [playbackRate, setPlaybackRate] = useState(1);
  const name = (id: number) =>
    teams.find((t) => t.id === id)?.name || `Команда ${id}`;
  const person = (id: number | null) =>
    id === null
      ? "Неизвестен"
      : players.find((p) => p.id === id)?.name || `Игрок ${id}`;
  const title = (m: Match) => `${name(m.home_id)} — ${name(m.away_id)}`;
  const load = async () => {
    const [t, p, m] = await Promise.all([
      api<Team[]>("/teams"),
      api<Player[]>("/players"),
      api<Match[]>("/matches"),
    ]);
    setTeams(t);
    setPlayers(p);
    setMatches(m);
  };
  const open = async (id: number, activate = true) => {
    const [m, s] = await Promise.all([
      api<Detail>(`/matches/${id}`),
      api<Stats>(`/matches/${id}/stats`),
    ]);
    const changed = activeMatchId.current !== id;
    activeMatchId.current = id;
    setMatch(m);
    setStats(s);
    if (changed) {
      const firstVideo = [...m.videos].sort(
        (a, b) => a.position - b.position || a.id - b.id,
      )[0];
      setVideoId(firstVideo?.id || 0);
      setRallyId(m.rallies.find((r) => r.video_id === firstVideo?.id)?.id || 0);
      setEditing(null);
      setEditingRally(null);
      setSelected([]);
      setHistory(null);
      setKindFilter("");
      setPlayerFilter("");
      setTime(0);
      setTab("review");
      pendingSeek.current = null;
    } else {
      setVideoId((v) =>
        m.videos.some((x) => x.id === v) ? v : m.videos[0]?.id || 0,
      );
      setRallyId((r) =>
        m.rallies.some((x) => x.id === r) ? r : m.rallies[0]?.id || 0,
      );
      setSelected((ids) =>
        ids.filter((id) => m.events.some((e) => e.id === id)),
      );
    }
    if (activate) setPage("match");
  };
  const perform = async (fn: () => Promise<unknown>, message = "Сохранено") => {
    if (operationPending.current) return;
    operationPending.current = true;
    setError("");
    setNotice("");
    setBusy(true);
    try {
      await fn();
      setNotice(message);
    } catch (e) {
      setError((e as Error).message);
    } finally {
      operationPending.current = false;
      setBusy(false);
    }
  };
  useEffect(() => {
    void load().catch((e) => setError(e.message));
  }, []);
  useEffect(() => {
    document.documentElement.dataset.theme = light ? "light" : "dark";
    try {
      localStorage.setItem("theme", light ? "light" : "dark");
    } catch {
      /* Browser storage may be disabled. */
    }
  }, [light]);
  useEffect(() => {
    if (page !== "jobs") return;
    const tick = () =>
      void api<typeof jobs>("/jobs")
        .then(setJobs)
        .catch((e) => setError(e.message));
    tick();
    const id = setInterval(tick, 3000);
    return () => clearInterval(id);
  }, [page]);
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (
        (e.target as HTMLElement).matches("input,select,textarea,button") ||
        !video.current ||
        page !== "match"
      )
        return;
      if (e.code === "Space") {
        e.preventDefault();
        if (video.current.paused) void video.current.play().catch(() => {});
        else video.current.pause();
      }
      if (e.key === "ArrowRight" || e.key === "ArrowLeft") {
        e.preventDefault();
        const target =
          video.current.currentTime +
          (e.key === "ArrowRight" ? 1 : -1) /
            (match?.videos.find((x) => x.id === videoId)?.fps || 30);
        video.current.pause();
        video.current.currentTime = Math.max(
          0,
          Math.min(target, video.current.duration || 0),
        );
      }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [page, match, videoId]);
  const seek = (id: number, t: number, targetRally?: number) => {
    const duration = match?.videos.find((v) => v.id === id)?.duration || 0;
    const target = Math.max(0, Math.min(t, duration));
    setVideoId(id);
    setTime(target);
    const rally =
      targetRally ??
      match?.rallies.find(
        (r) => r.video_id === id && r.start <= target && target <= r.end,
      )?.id ??
      0;
    setRallyId(rally);
    pendingSeek.current = { videoId: id, time: target };
    if (video.current && id === videoId && video.current.readyState >= 1) {
      video.current.currentTime = target;
      pendingSeek.current = null;
    }
  };
  const selectVideo = (id: number) => {
    const rally = match?.rallies.find((r) => r.video_id === id);
    seek(id, 0, rally?.id || 0);
  };
  const currentVideo = match?.videos.find((v) => v.id === videoId);
  const filtered =
    match?.events.filter(
      (e) =>
        (!kindFilter || e.kind === kindFilter) &&
        (!playerFilter || String(e.player_id) === playerFilter),
    ) || [];
  const field = (f: FormData, k: string) => String(f.get(k) || "");
  const optional = (f: FormData, k: string) =>
    field(f, k) === "" ? null : Number(field(f, k));
  const form =
    (fn: (f: FormData) => Promise<unknown>) =>
    (e: React.FormEvent<HTMLFormElement>) => {
      e.preventDefault();
      const target = e.currentTarget;
      void perform(async () => {
        await fn(new FormData(target));
      });
    };
  const matchRefresh = async () => {
    if (match) await open(match.id, false);
  };
  const teamOptions = (onlyMatch = false) =>
    (onlyMatch && match
      ? teams.filter((t) => [match.home_id, match.away_id].includes(t.id))
      : teams
    ).map((t) => (
      <option key={t.id} value={t.id}>
        {t.name}
      </option>
    ));
  return (
    <div className="shell">
      <aside>
        <a
          className="brand"
          href="#"
          onClick={(e) => {
            e.preventDefault();
            setPage("home");
          }}
        >
          <span className="brand-icon">
            <Volleyball size={25} />
          </span>
          <span>
            VolleyVision <b>AI</b>
            <small>РАБОЧЕЕ ПРОСТРАНСТВО</small>
          </span>
        </a>
        <div className="nav-label">АНАЛИТИКА</div>
        <nav>
          {[
            ["home", "Обзор", LayoutDashboard],
            ["matches", "Матчи", Film],
            ["teams", "Команды и игроки", Users],
            ["jobs", "Обработка видео", Activity],
          ].map(([id, label, Icon]) => (
            <button
              key={String(id)}
              className={page === id ? "active" : ""}
              onClick={() => setPage(String(id))}
            >
              <Icon size={18} />
              {String(label)}
            </button>
          ))}
        </nav>
        <div className="sidebar-bottom">
          <div className="local">
            <span className="dot" />
            Локальное хранение
          </div>
          <p>Видео и разметка остаются на вашем компьютере.</p>
          <button className="theme" onClick={() => setLight(!light)}>
            {light ? <Moon size={16} /> : <Sun size={16} />}{" "}
            {light ? "Тёмная тема" : "Светлая тема"}
          </button>
          <small>v0.3 · Локальная детекция</small>
        </div>
      </aside>
      <main aria-busy={busy}>
        <header>
          <span>
            Рабочее пространство <ChevronRight size={14} />{" "}
            {page === "match"
              ? "Анализ матча"
              : page === "teams"
                ? "Команды"
                : page === "jobs"
                  ? "Обработка видео"
                  : "Обзор матчей"}
          </span>
          <div className="badge">
            <span className="dot" /> Локальный режим
          </div>
        </header>
        <div className="content">
          {error && (
            <div className="alert" role="alert">
              {error}
              <button onClick={() => setError("")}>×</button>
            </div>
          )}
          {notice && (
            <div className="notice" role="status">
              <CheckCircle2 size={16} />
              {notice}
            </div>
          )}
          {busy && (
            <div className="working" role="status">
              Выполняется операция… Для большого видео это может занять
              несколько минут.
            </div>
          )}
          {(page === "home" || page === "matches") && (
            <>
              <div className="page-heading">
                <div>
                  <div className="eyebrow">ВАША ИГРА. В ДЕТАЛЯХ.</div>
                  <h1>
                    {page === "home"
                      ? "Каждый розыгрыш имеет значение"
                      : "Матчи"}
                  </h1>
                  <p>От видеозаписи — к понятным решениям на площадке.</p>
                </div>
                <span className="heading-icon">
                  <Volleyball size={38} />
                </span>
              </div>
              <div className="cards">
                <Metric
                  title="Матчей в библиотеке"
                  value={matches.length}
                  icon={<Film />}
                />
                <Metric title="Команд" value={teams.length} icon={<Users />} />
                <Metric
                  title="Зарегистрировано игроков"
                  value={players.length}
                  icon={<Target />}
                />
              </div>
              <div className="section-heading">
                <h2>
                  Библиотека матчей <span>{matches.length}</span>
                </h2>
                <span className="muted">Данные сохраняются автоматически</span>
              </div>
              <div className="match-grid">
                {matches.map((m) => (
                  <button
                    className="match-card"
                    key={m.id}
                    onClick={() =>
                      void perform(() => open(m.id), "Матч открыт")
                    }
                  >
                    <div className="match-art">
                      <Volleyball size={54} />
                      <span className="badge">РУЧНАЯ РАЗМЕТКА</span>
                    </div>
                    <div className="match-info">
                      <small>
                        {m.date} {m.title && `· ${m.title}`}
                      </small>
                      <h3>{title(m)}</h3>
                      <span>
                        Открыть рабочий экран <ArrowRight size={16} />
                      </span>
                    </div>
                  </button>
                ))}
                {matches.length === 0 && (
                  <div className="empty">
                    <Film size={34} />
                    <h3>Первый матч начинается здесь</h3>
                    <p>
                      Добавьте команды и игроков, создайте матч и загрузите
                      запись.
                    </p>
                    <button onClick={() => setPage("teams")}>
                      Добавить команды <ArrowRight size={15} />
                    </button>
                  </div>
                )}
              </div>
              <section className="panel">
                <h2>
                  <Plus size={18} /> Новый матч
                </h2>
                <form
                  onSubmit={form(async (f) => {
                    const m = await api<Match>("/matches", "POST", {
                      home_id: Number(field(f, "home")),
                      away_id: Number(field(f, "away")),
                      date: field(f, "date"),
                      title: field(f, "title"),
                    });
                    await load();
                    await open(m.id);
                  })}
                  className="form-row"
                >
                  <label>
                    Первая команда
                    <select required name="home">
                      <option value="">Выберите команду</option>
                      {teamOptions()}
                    </select>
                  </label>
                  <label>
                    Вторая команда
                    <select required name="away">
                      <option value="">Выберите команду</option>
                      {teamOptions()}
                    </select>
                  </label>
                  <label>
                    Дата
                    <input
                      required
                      type="date"
                      name="date"
                      defaultValue={new Date().toLocaleDateString("en-CA")}
                    />
                  </label>
                  <label>
                    Турнир / название
                    <input
                      name="title"
                      placeholder="Необязательно"
                      maxLength={180}
                    />
                  </label>
                  <button
                    className="primary"
                    disabled={busy || teams.length < 2}
                  >
                    Создать матч
                  </button>
                </form>
              </section>
              <div className="honesty">
                <Activity size={20} />
                <div>
                  <strong>Контроль качества на каждом этапе</strong>
                  <p>
                    Сейчас доступны ручная разметка, расчёт статистики и
                    видеоэкспорт. Локальная детекция людей и возможного мяча
                    доступна во вкладке «Автоанализ и отчёт» после установки
                    весов. Распознавание действий ещё не подключено.
                  </p>
                </div>
              </div>
            </>
          )}
          {page === "teams" && (
            <>
              <div className="page-heading">
                <div className="eyebrow">СОСТАВЫ И УЧАСТНИКИ</div>
                <h1>Команды и игроки</h1>
                <p>Личность игрока сохраняется независимо от номера в матче.</p>
              </div>
              <section className="panel">
                <h2>Создать команду</h2>
                <form
                  className="form-row"
                  onSubmit={form(async (f) => {
                    await api("/teams", "POST", { name: field(f, "name") });
                    await load();
                  })}
                >
                  <label>
                    Название
                    <input
                      required
                      name="name"
                      maxLength={120}
                      placeholder="Например, Динамо"
                    />
                  </label>
                  <button className="primary" disabled={busy}>
                    Добавить команду
                  </button>
                </form>
              </section>
              <section className="panel">
                <h2>Зарегистрировать игрока</h2>
                <form
                  className="form-row"
                  onSubmit={form(async (f) => {
                    await api("/players", "POST", {
                      name: field(f, "name"),
                      team_id: Number(field(f, "team")),
                      number: field(f, "number") || null,
                      role: field(f, "role"),
                    });
                    await load();
                  })}
                >
                  <label>
                    ФИО
                    <input required name="name" maxLength={120} />
                  </label>
                  <label>
                    Команда
                    <select required name="team">
                      {teamOptions()}
                    </select>
                  </label>
                  <label>
                    Номер
                    <input name="number" maxLength={8} />
                  </label>
                  <label>
                    Амплуа
                    <select name="role">
                      {[
                        "Не указано",
                        "Связующий",
                        "Доигровщик",
                        "Диагональный",
                        "Центральный блокирующий",
                        "Либеро",
                      ].map((v) => (
                        <option key={v}>{v}</option>
                      ))}
                    </select>
                  </label>
                  <button className="primary" disabled={busy || !teams.length}>
                    Добавить игрока
                  </button>
                </form>
              </section>
              <div className="match-grid">
                {teams.map((t) => (
                  <section className="panel" key={t.id}>
                    <div className="section-heading">
                      <h2>{t.name}</h2>
                      <Users size={19} />
                    </div>
                    {players
                      .filter((p) =>
                        p.memberships.some((m) => m.team_id === t.id),
                      )
                      .map((p) => (
                        <div className="player" key={p.id}>
                          <span className="number">
                            {p.memberships.find((m) => m.team_id === t.id)
                              ?.number || "—"}
                          </span>
                          <div>
                            <strong>{p.name}</strong>
                            <small>{p.role}</small>
                          </div>
                        </div>
                      ))}
                  </section>
                ))}
              </div>
            </>
          )}
          {page === "jobs" && (
            <>
              <div className="page-heading">
                <div className="eyebrow">МЕДИАПАЙПЛАЙН</div>
                <h1>Обработка видео</h1>
                <p>
                  Одна тяжёлая задача за раз. Прерванную задачу можно запустить
                  повторно.
                </p>
              </div>
              <div className="honesty">
                <Activity />
                <p>
                  Доступно создание H.264-прокси для браузера. AI-модели не
                  установлены; вымышленные результаты не генерируются. Прокси
                  при сбое создаётся заново, а не с середины файла.
                </p>
              </div>
              {jobs.length === 0 && (
                <div className="empty">
                  Очередь пуста. Создать прокси можно на экране матча.
                </div>
              )}
              {jobs.map((j) => (
                <section className="panel" key={j.id}>
                  <h3>
                    Прокси видео #{j.video_id}{" "}
                    <span className="badge">
                      {
                        (
                          {
                            queued: "Ожидание",
                            running: "Обработка",
                            completed: "Завершено",
                            failed: "Ошибка",
                            interrupted: "Прервано",
                          } as Record<string, string>
                        )[j.status]
                      }
                    </span>
                  </h3>
                  {j.error && <p className="error-text">{j.error}</p>}
                  {["failed", "interrupted"].includes(j.status) && (
                    <button
                      disabled={busy}
                      onClick={() =>
                        void perform(() => api(`/jobs/${j.id}/retry`, "POST"))
                      }
                    >
                      Повторить
                    </button>
                  )}
                </section>
              ))}
            </>
          )}
          {page === "match" && match && (
            <>
              <div className="page-heading compact">
                <button className="back" onClick={() => setPage("matches")}>
                  <ArrowLeft size={16} /> Все матчи
                </button>
                <div className="title-row">
                  <div>
                    <div className="eyebrow">
                      {match.date} · {match.title || "ВОЛЕЙБОЛ 6 × 6"}
                    </div>
                    <h1>{title(match)}</h1>
                  </div>
                  <div className="badge">
                    {match.events.length} событий · {match.rallies.length}{" "}
                    розыгрышей
                  </div>
                </div>
              </div>
              <div className="tabs">
                {[
                  ["review", "Разметка и видео"],
                  ["analysis", "Автоанализ и отчёт"],
                  ["statistics", "Статистика"],
                  ["import", "Видео и состав"],
                ].map(([v, l]) => (
                  <button
                    key={v}
                    className={tab === v ? "active" : ""}
                    onClick={() => setTab(v)}
                  >
                    {l}
                  </button>
                ))}
              </div>
              {tab === "import" && (
                <>
                  <VideoImport
                    key={match.id}
                    matchId={match.id}
                    onImported={matchRefresh}
                  />
                  <YandexImport
                    mid={match.id}
                    perform={perform}
                    refresh={matchRefresh}
                  />
                  <section className="panel">
                    <h2>Исходные записи</h2>
                    <p className="muted">
                      Непрерывность роликов не предполагается. Смещение на общей
                      шкале задаётся вручную.
                    </p>
                    {match.videos.map((v) => (
                      <form
                        className="video-row"
                        key={v.id}
                        onSubmit={form(async (f) => {
                          await api(`/videos/${v.id}`, "PUT", {
                            position: Number(field(f, "position")),
                            offset: optional(f, "offset"),
                          });
                          await matchRefresh();
                        })}
                      >
                        <Film />
                        <div>
                          <strong>{v.name}</strong>
                          <small>
                            {v.width}×{v.height} · {v.fps.toFixed(2)} FPS ·{" "}
                            {stamp(v.duration)} · {v.codec} ·{" "}
                            {(v.size / 1024 ** 2).toFixed(1)} МБ
                          </small>
                        </div>
                        <label>
                          Порядок
                          <input
                            name="position"
                            type="number"
                            min={0}
                            defaultValue={v.position}
                          />
                        </label>
                        <label>
                          Смещение, с
                          <input
                            name="offset"
                            type="number"
                            min={0}
                            step="0.001"
                            defaultValue={v.offset ?? ""}
                            placeholder="Неизвестно"
                          />
                        </label>
                        <button disabled={busy}>Сохранить</button>
                        <button
                          type="button"
                          disabled={busy}
                          onClick={() =>
                            void perform(
                              () => api(`/videos/${v.id}/proxy`, "POST"),
                              "Задача прокси добавлена в очередь",
                            )
                          }
                        >
                          Создать прокси
                        </button>
                      </form>
                    ))}
                  </section>
                  <section className="panel">
                    <h2>Партии</h2>
                    <p>
                      {match.sets
                        .map(
                          (s) =>
                            `Партия ${s.number} · начальный счёт ${s.initial_home}:${s.initial_away}`,
                        )
                        .join(" / ")}
                    </p>
                    <form
                      className="form-row"
                      onSubmit={form(async (f) => {
                        await api(`/matches/${match.id}/sets`, "POST", {
                          number: Number(field(f, "number")),
                          initial_home: Number(field(f, "home")),
                          initial_away: Number(field(f, "away")),
                        });
                        await matchRefresh();
                      })}
                    >
                      <label>
                        Номер
                        <input
                          name="number"
                          type="number"
                          min={1}
                          max={5}
                          defaultValue={Math.min(5, match.sets.length + 1)}
                        />
                      </label>
                      <label>
                        Начальный счёт хозяев
                        <input
                          name="home"
                          type="number"
                          min={0}
                          max={100}
                          defaultValue={0}
                        />
                      </label>
                      <label>
                        Гостей
                        <input
                          name="away"
                          type="number"
                          min={0}
                          max={100}
                          defaultValue={0}
                        />
                      </label>
                      <button disabled={busy}>Добавить партию</button>
                    </form>
                  </section>
                  <section className="panel">
                    <h2>Состав на матч</h2>
                    <p className="muted">
                      {match.roster
                        .map(
                          (r) =>
                            `${person(r.player_id)} #${r.number || "—"}${r.libero ? " (либеро)" : ""}`,
                        )
                        .join(" · ") || "Пусто"}
                    </p>
                    <form
                      className="form-row"
                      onSubmit={form(async (f) => {
                        await api(`/matches/${match.id}/roster`, "POST", {
                          team_id: Number(field(f, "team")),
                          player_id: Number(field(f, "player")),
                          number: field(f, "number") || null,
                          libero: f.get("libero") === "on",
                        });
                        await matchRefresh();
                      })}
                    >
                      <label>
                        Игрок
                        <select name="player" required>
                          {players
                            .filter(
                              (p) =>
                                !match.roster.some((r) => r.player_id === p.id),
                            )
                            .map((p) => (
                              <option key={p.id} value={p.id}>
                                {p.name}
                              </option>
                            ))}
                        </select>
                      </label>
                      <label>
                        Команда<select name="team">{teamOptions(true)}</select>
                      </label>
                      <label>
                        Номер на матч
                        <input name="number" maxLength={8} />
                      </label>
                      <label className="check">
                        <input type="checkbox" name="libero" /> Либеро
                      </label>
                      <button disabled={busy}>Включить в состав</button>
                    </form>
                  </section>
                </>
              )}
              {tab === "analysis" && (
                <AnalysisWorkspace
                  key={match.id}
                  match={match}
                  players={players}
                  teams={teams}
                  initialVideoId={videoId}
                />
              )}
              {tab === "review" && (
                <>
                  <div className="workspace">
                    <section className="player-panel">
                      <div className="video-header">
                        <span>
                          <span className="dot" /> ВИДЕО МАТЧА
                        </span>
                        <select
                          aria-label="Видео"
                          value={videoId}
                          onChange={(e) => {
                            selectVideo(Number(e.target.value));
                          }}
                        >
                          {[...match.videos]
                            .sort((a, b) => a.position - b.position)
                            .map((v) => (
                              <option key={v.id} value={v.id}>
                                {v.name}
                              </option>
                            ))}
                        </select>
                      </div>
                      {currentVideo ? (
                        <video
                          key={videoId}
                          ref={video}
                          controls
                          preload="metadata"
                          src={`/api/videos/${videoId}/stream`}
                          onLoadedMetadata={() => {
                            if (!video.current) return;
                            video.current.playbackRate = playbackRate;
                            const requested =
                              pendingSeek.current?.videoId === videoId
                                ? pendingSeek.current.time
                                : time;
                            video.current.currentTime = Math.max(
                              0,
                              Math.min(requested, video.current.duration),
                            );
                            pendingSeek.current = null;
                          }}
                          onTimeUpdate={() =>
                            setTime(video.current?.currentTime || 0)
                          }
                          onError={() =>
                            setError(
                              "Браузер не воспроизводит этот кодек. Создайте H.264-прокси во вкладке «Видео и состав».",
                            )
                          }
                        />
                      ) : (
                        <div className="video-empty">
                          <Play size={44} />
                          <h3>Добавьте запись матча</h3>
                          <p>
                            После загрузки можно отмечать розыгрыши и действия.
                          </p>
                          <button onClick={() => setTab("import")}>
                            Импортировать видео
                          </button>
                        </div>
                      )}
                      <div className="video-tools">
                        <span className="time">
                          {stamp(time)} / {stamp(currentVideo?.duration || 0)}
                        </span>
                        <span className="muted">
                          Пробел — пауза · ← → — кадр
                        </span>
                        <select
                          aria-label="Скорость"
                          onChange={(e) => {
                            const rate = Number(e.target.value);
                            setPlaybackRate(rate);
                            if (video.current)
                              video.current.playbackRate = rate;
                          }}
                          value={playbackRate}
                        >
                          {[0.25, 0.5, 1, 1.5, 2].map((n) => (
                            <option key={n} value={n}>
                              {n}×
                            </option>
                          ))}
                        </select>
                      </div>
                      <div className="timeline" aria-label="Временная шкала">
                        {match.rallies
                          .filter((r) => r.video_id === videoId)
                          .map((r) => (
                            <button
                              title={`Розыгрыш ${r.id} · ${stamp(r.start)}–${stamp(r.end)}`}
                              key={r.id}
                              style={{
                                left: `${(r.start / (currentVideo?.duration || 1)) * 100}%`,
                                width: `${Math.max(0.5, ((r.end - r.start) / (currentVideo?.duration || 1)) * 100)}%`,
                              }}
                              onClick={() => {
                                setRallyId(r.id);
                                seek(r.video_id, r.start, r.id);
                              }}
                            />
                          ))}
                        {match.events
                          .filter((e) => e.video_id === videoId)
                          .map((e) => (
                            <button
                              className={`event-dot ${e.kind}`}
                              key={e.id}
                              title={`${kinds[e.kind]} ${stamp(e.time)}`}
                              style={{
                                left: `${(e.time / (currentVideo?.duration || 1)) * 100}%`,
                              }}
                              onClick={() =>
                                seek(e.video_id, e.time, e.rally_id)
                              }
                            />
                          ))}
                        <div
                          className="playhead"
                          style={{
                            left: `${(time / (currentVideo?.duration || 1)) * 100}%`,
                          }}
                        />
                      </div>
                      <div className="timeline-legend">
                        <span>
                          <i /> Розыгрыш
                        </span>
                        <span>
                          <i className="attack" /> Атака
                        </span>
                        <span>
                          <i className="serve" /> Подача
                        </span>
                      </div>
                    </section>
                    <section className="panel rally-panel">
                      <h2>
                        Розыгрыши{" "}
                        <span className="badge">{match.rallies.length}</span>
                      </h2>
                      <div className="rally-list">
                        {match.rallies.map((r, i) => (
                          <div
                            className={
                              "rally-item " +
                              (r.id === rallyId ? "selected" : "")
                            }
                            key={r.id}
                          >
                            <button
                              onClick={() => {
                                setRallyId(r.id);
                                seek(r.video_id, r.start, r.id);
                              }}
                            >
                              <span className="number">
                                {String(i + 1).padStart(2, "0")}
                              </span>
                              <span>
                                <strong>
                                  {stamp(r.start)} — {stamp(r.end)}
                                </strong>
                                <small>
                                  {r.winner_team_id
                                    ? `Очко: ${name(r.winner_team_id)}`
                                    : "Победитель неизвестен"}
                                </small>
                              </span>
                            </button>
                            <button
                              className="text-button"
                              onClick={() => setEditingRally(r)}
                            >
                              Правка
                            </button>
                          </div>
                        ))}
                      </div>
                      <p className="muted">
                        Счёт определяется победителем розыгрыша. Укажите его
                        после просмотра.
                      </p>
                    </section>
                  </div>
                  <section className="panel">
                    <h2>
                      {editingRally ? "Исправить розыгрыш" : "Новый розыгрыш"}
                    </h2>
                    <form
                      key={`rally-${editingRally?.id || 0}-${videoId}`}
                      className="form-row"
                      onSubmit={form(async (f) => {
                        const body = {
                          set_id: Number(field(f, "set")),
                          video_id: Number(field(f, "video")),
                          start: Number(field(f, "start")),
                          end: Number(field(f, "end")),
                          serving_team_id: optional(f, "serving"),
                          winner_team_id: optional(f, "winner"),
                          rotation: optional(f, "rotation"),
                        };
                        const r = await api<Rally>(
                          editingRally
                            ? `/rallies/${editingRally.id}`
                            : `/matches/${match.id}/rallies`,
                          editingRally ? "PUT" : "POST",
                          editingRally
                            ? { ...body, revision: editingRally.revision }
                            : body,
                        );
                        setEditingRally(null);
                        await matchRefresh();
                        seek(r.video_id, r.start, r.id);
                      })}
                    >
                      <label>
                        Видео
                        <select
                          name="video"
                          defaultValue={editingRally?.video_id || videoId}
                        >
                          {match.videos.map((v) => (
                            <option key={v.id} value={v.id}>
                              {v.name}
                            </option>
                          ))}
                        </select>
                      </label>
                      <label>
                        Партия
                        <select
                          name="set"
                          defaultValue={
                            editingRally?.set_id || match.sets[0]?.id
                          }
                        >
                          {match.sets.map((s) => (
                            <option key={s.id} value={s.id}>
                              {s.number}
                            </option>
                          ))}
                        </select>
                      </label>
                      <label>
                        Начало, с
                        <input
                          required
                          name="start"
                          type="number"
                          step="0.001"
                          min={0}
                          defaultValue={editingRally?.start ?? 0}
                        />
                        <button
                          type="button"
                          className="text-button"
                          onClick={(e) => {
                            const form = e.currentTarget.form!;
                            if (
                              Number(
                                (
                                  form.elements.namedItem(
                                    "video",
                                  ) as HTMLSelectElement
                                ).value,
                              ) !== videoId
                            ) {
                              setError(
                                "Текущий кадр относится к другому видео. Выберите нужный источник в плеере.",
                              );
                              return;
                            }
                            (
                              form.elements.namedItem(
                                "start",
                              ) as HTMLInputElement
                            ).value = time.toFixed(3);
                          }}
                        >
                          Текущий кадр
                        </button>
                      </label>
                      <label>
                        Конец, с
                        <input
                          required
                          name="end"
                          type="number"
                          step="0.001"
                          min={0}
                          defaultValue={
                            editingRally?.end ??
                            Math.min(10, currentVideo?.duration || 10)
                          }
                        />
                        <button
                          type="button"
                          className="text-button"
                          onClick={(e) => {
                            const form = e.currentTarget.form!;
                            if (
                              Number(
                                (
                                  form.elements.namedItem(
                                    "video",
                                  ) as HTMLSelectElement
                                ).value,
                              ) !== videoId
                            ) {
                              setError(
                                "Текущий кадр относится к другому видео. Выберите нужный источник в плеере.",
                              );
                              return;
                            }
                            (
                              form.elements.namedItem("end") as HTMLInputElement
                            ).value = time.toFixed(3);
                          }}
                        >
                          Текущий кадр
                        </button>
                      </label>
                      <label>
                        Подающая
                        <select
                          name="serving"
                          defaultValue={editingRally?.serving_team_id ?? ""}
                        >
                          <option value="">Неизвестно</option>
                          {teamOptions(true)}
                        </select>
                      </label>
                      <label>
                        Очко команде
                        <select
                          name="winner"
                          defaultValue={editingRally?.winner_team_id ?? ""}
                        >
                          <option value="">Неизвестно</option>
                          {teamOptions(true)}
                        </select>
                      </label>
                      <label>
                        Ротация подачи
                        <select
                          name="rotation"
                          defaultValue={editingRally?.rotation ?? ""}
                        >
                          <option value="">Неизвестно</option>
                          {[1, 2, 3, 4, 5, 6].map((n) => (
                            <option key={n} value={n}>
                              P{n}
                            </option>
                          ))}
                        </select>
                      </label>
                      <button className="primary" disabled={busy || !videoId}>
                        {editingRally ? "Сохранить правку" : "Добавить"}
                      </button>
                      {editingRally && (
                        <button
                          type="button"
                          onClick={() => setEditingRally(null)}
                        >
                          Отмена
                        </button>
                      )}
                    </form>
                  </section>
                  <EventEditor
                    key={`${match.id}-${editing?.id || "new"}`}
                    event={editing}
                    match={match}
                    players={players}
                    teams={teams}
                    time={time}
                    rallyId={rallyId}
                    currentVideoId={videoId}
                    onRallyChange={(id) => {
                      const target = match.rallies.find((r) => r.id === id);
                      if (target)
                        seek(target.video_id, target.start, target.id);
                    }}
                    busy={busy}
                    onCancel={() => setEditing(null)}
                    onSave={(body) =>
                      perform(async () => {
                        await api(
                          editing
                            ? `/events/${editing.id}`
                            : `/matches/${match.id}/events`,
                          editing ? "PUT" : "POST",
                          editing
                            ? { ...body, revision: editing.revision }
                            : body,
                        );
                        setEditing(null);
                        await matchRefresh();
                      })
                    }
                  />
                  <section className="panel">
                    <div className="section-heading">
                      <h2>
                        Лента действий <span>{filtered.length}</span>
                      </h2>
                      <div className="filters">
                        <select
                          aria-label="Фильтр действий"
                          value={kindFilter}
                          onChange={(e) => setKindFilter(e.target.value)}
                        >
                          <option value="">Все действия</option>
                          {Object.entries(kinds).map(([v, l]) => (
                            <option key={v} value={v}>
                              {l}
                            </option>
                          ))}
                        </select>
                        <select
                          aria-label="Фильтр игроков"
                          value={playerFilter}
                          onChange={(e) => setPlayerFilter(e.target.value)}
                        >
                          <option value="">Все игроки</option>
                          <option value="null">Неизвестный игрок</option>
                          {match.roster.map((r) => (
                            <option key={r.player_id} value={r.player_id}>
                              {person(r.player_id)}
                            </option>
                          ))}
                        </select>
                      </div>
                    </div>
                    <div className="table-wrap">
                      <table>
                        <thead>
                          <tr>
                            <th>Клип</th>
                            <th>Время</th>
                            <th>Действие</th>
                            <th>Игрок / команда</th>
                            <th>Результат</th>
                            <th>Качество</th>
                            <th>Статус</th>
                            <th>Правки</th>
                          </tr>
                        </thead>
                        <tbody>
                          {filtered.map((e) => (
                            <tr key={e.id}>
                              <td>
                                <input
                                  aria-label={`Включить событие ${e.id} в клип`}
                                  type="checkbox"
                                  checked={selected.includes(e.id)}
                                  onChange={(x) =>
                                    setSelected((a) =>
                                      x.target.checked
                                        ? [...a, e.id]
                                        : a.filter((id) => id !== e.id),
                                    )
                                  }
                                />
                              </td>
                              <td>
                                <button
                                  className="time-link"
                                  onClick={() =>
                                    seek(e.video_id, e.time, e.rally_id)
                                  }
                                >
                                  <Play size={12} />
                                  {stamp(e.time)}
                                </button>
                              </td>
                              <td>
                                <span className={"action-tag " + e.kind}>
                                  {kinds[e.kind]}
                                </span>
                              </td>
                              <td>
                                {person(e.player_id)}
                                <small>{name(e.team_id)}</small>
                              </td>
                              <td>
                                {e.outcome
                                  ? outcomes[e.kind]?.[e.outcome] || e.outcome
                                  : "Неизвестно"}
                              </td>
                              <td>{e.quality ?? "—"}</td>
                              <td>
                                <span className="status">
                                  {
                                    (
                                      {
                                        manual: "Вручную",
                                        corrected: "Исправлено вручную",
                                        confirmed: "Подтверждено",
                                        auto: "Распознано автоматически",
                                        review: "Требует проверки",
                                      } as Record<string, string>
                                    )[e.status]
                                  }
                                </span>
                              </td>
                              <td>
                                <div className="row-actions">
                                  <button
                                    onClick={() => {
                                      setEditing(e);
                                      seek(e.video_id, e.time, e.rally_id);
                                    }}
                                  >
                                    Изменить
                                  </button>
                                  <button
                                    onClick={() =>
                                      void perform(
                                        async () =>
                                          setHistory(
                                            await api(
                                              `/events/${e.id}/history`,
                                            ),
                                          ),
                                        "История загружена",
                                      )
                                    }
                                  >
                                    История
                                  </button>
                                  <button
                                    disabled={busy}
                                    onClick={() =>
                                      void perform(async () => {
                                        await api(
                                          `/events/${e.id}?revision=${e.revision}`,
                                          "DELETE",
                                        );
                                        setSelected((a) =>
                                          a.filter((id) => id !== e.id),
                                        );
                                        await matchRefresh();
                                      }, "Удалено с сохранением истории")
                                    }
                                  >
                                    Удалить
                                  </button>
                                </div>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                      {filtered.length === 0 && (
                        <div className="empty small">
                          Здесь появятся размеченные действия.
                        </div>
                      )}
                    </div>
                    <div className="export-bar">
                      <span>{selected.length} выбрано для подборки</span>
                      <button
                        disabled={busy || !selected.length}
                        onClick={() =>
                          void perform(async () => {
                            await api(`/matches/${match.id}/clips`, "POST", {
                              event_ids: selected,
                              before: 3,
                              after: 4,
                              name: "Подборка действий",
                            });
                            await matchRefresh();
                          }, "MP4-подборка создана")
                        }
                      >
                        <Film size={15} /> Создать MP4 · −3/+4 с
                      </button>
                    </div>
                    {match.clips.map((c) => (
                      <a
                        className="download"
                        key={c.id}
                        href={`/api/clips/${c.id}/download`}
                      >
                        <Download size={14} />
                        {c.name} #{c.id}
                      </a>
                    ))}
                    {history !== null && (
                      <details open>
                        <summary onClick={() => setHistory(null)}>
                          История изменений · закрыть
                        </summary>
                        <pre>{JSON.stringify(history, null, 2)}</pre>
                      </details>
                    )}
                  </section>
                </>
              )}
              {tab === "statistics" && stats && (
                <>
                  <div className="cards">
                    <Metric
                      title="Доверенных событий"
                      value={stats.trusted_events}
                      icon={<CheckCircle2 />}
                    />
                    <Metric
                      title="Требуют проверки"
                      value={stats.pending_events}
                      icon={<Activity />}
                    />
                    <Metric
                      title="Размечено розыгрышей"
                      value={match.rallies.length}
                      icon={<Volleyball />}
                    />
                  </div>
                  <div className="honesty">
                    <Target size={24} />
                    <div>
                      <strong>Статистика по размеченным эпизодам</strong>
                      <p>
                        Счёт не считается полным:{" "}
                        {stats.sets
                          .map(
                            (s) =>
                              `партия ${s.number}: ${s.home}:${s.away}, неизвестных исходов ${s.unknown_rallies}`,
                          )
                          .join(" · ")}
                        . «—» означает отсутствие данных для расчёта.
                      </p>
                    </div>
                  </div>
                  {stats.data_quality &&
                    (stats.data_quality.grade_conflict_count > 0 ||
                      stats.data_quality.terminal_conflict_count > 0 ||
                      (stats.data_quality.overlapping_rally_ids?.length || 0) >
                        0) && (
                      <div className="alert" role="alert">
                        Проверьте разметку: противоречивых оценок качества —{" "}
                        {stats.data_quality.grade_conflict_count}; противоречий
                        исходов — {stats.data_quality.terminal_conflict_count}.
                        Итог действия может противоречить победителю розыгрыша.
                        Исправьте первичные события; счёт автоматически не
                        подменяется.
                        {(stats.data_quality.overlapping_rally_ids?.length ||
                          0) > 0 && (
                          <span>
                            Пересекающиеся розыгрыши: #
                            {stats.data_quality.overlapping_rally_ids!.join(
                              ", #",
                            )}
                            . Пока дубликаты и границы не исправлены, счёт может
                            учитывать одно очко несколько раз.
                          </span>
                        )}
                      </div>
                    )}
                  {Object.entries(stats.teams).map(([tid, t]) => (
                    <section className="panel" key={tid}>
                      <h2>{name(Number(tid))}</h2>
                      <div className="mini-metrics">
                        <span>
                          Side-out <b>{pct(t.sideout.pct)}</b>
                          <small>{t.sideout.total} известных розыгрышей</small>
                        </span>
                        <span>
                          Break point <b>{pct(t.breakpoint.pct)}</b>
                          <small>
                            {t.breakpoint.total} известных розыгрышей
                          </small>
                        </span>
                        <span>
                          Приём 2–3 <b>{pct(t.reception.positive_pct)}</b>
                          <small>
                            Оценено: {t.reception.graded} /{" "}
                            {t.reception.attempts}
                          </small>
                        </span>
                      </div>
                      <p className="muted">
                        Известных исходов: подачи {t.serve.known_outcomes} /{" "}
                        {t.serve.attempts}; атаки {t.attack.known_outcomes} /{" "}
                        {t.attack.attempts}. Счётчики показывают только
                        размеченные действия. Общая эффективность скрыта, если
                        хотя бы один исход неизвестен.
                      </p>
                      <div className="table-wrap">
                        <table>
                          <thead>
                            <tr>
                              <th>Игрок</th>
                              <th>Подачи</th>
                              <th>Эйсы</th>
                              <th>Ошибки подачи</th>
                              <th>Атаки</th>
                              <th>Неизвестных исходов атаки</th>
                              <th>Выигрыш %</th>
                              <th>Эфф. атаки</th>
                              <th>Приём (ср.)</th>
                              <th>Оценено приёмов</th>
                              <th>Блок-очки*</th>
                              <th>Защиты</th>
                            </tr>
                          </thead>
                          <tbody>
                            {Object.entries(t.players).map(([pid, p]) => (
                              <tr key={pid}>
                                <td>
                                  <button
                                    className="text-button"
                                    onClick={() => {
                                      setPlayerFilter(
                                        pid === "unknown" ? "null" : pid,
                                      );
                                      setTab("review");
                                    }}
                                  >
                                    {person(
                                      pid === "unknown" ? null : Number(pid),
                                    )}
                                  </button>
                                </td>
                                <td>{p.serve.attempts}</td>
                                <td>{p.serve.outcomes.ace || 0}</td>
                                <td>{p.serve.outcomes.error || 0}</td>
                                <td>{p.attack.attempts}</td>
                                <td>{p.attack.unknown_outcomes}</td>
                                <td>{pct(p.attack.win_pct)}</td>
                                <td>{pct(p.attack.efficiency)}</td>
                                <td>{p.reception.average ?? "—"}</td>
                                <td>
                                  {p.reception.graded} / {p.reception.attempts}
                                </td>
                                <td>{p.block.outcomes.point || 0}</td>
                                <td>{p.dig.attempts}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                      <p className="muted">
                        * Автор командного блок-очка по ручной оценке. Участие в
                        групповом блоке пока не учитывается.
                      </p>
                    </section>
                  ))}
                  <section className="panel">
                    <h2>Экспорт матча</h2>
                    <p className="muted">
                      События с таймкодами, статистика и статус проверки. Excel
                      содержит отдельный лист статистики.
                    </p>
                    <div className="filters">
                      {["xlsx", "csv", "json"].map((fmt) => (
                        <a
                          className="button"
                          key={fmt}
                          href={`/api/matches/${match.id}/export/${fmt}`}
                        >
                          <Download size={16} /> {fmt.toUpperCase()}
                        </a>
                      ))}
                      <button onClick={() => window.print()}>
                        Печать / PDF через браузер
                      </button>
                    </div>
                  </section>
                </>
              )}
            </>
          )}
        </div>
        <footer>
          VolleyVision AI <span>Реальные события. Проверяемая статистика.</span>
        </footer>
      </main>
    </div>
  );
}

function Metric({
  title,
  value,
  icon,
}: {
  title: string;
  value: number;
  icon: React.ReactNode;
}) {
  return (
    <div className="metric">
      <span className="metric-icon">{icon}</span>
      <div>
        <span>{title}</span>
        <strong>{value}</strong>
      </div>
    </div>
  );
}

function EventEditor({
  event,
  match,
  players,
  teams,
  time,
  rallyId,
  currentVideoId,
  onRallyChange,
  busy,
  onCancel,
  onSave,
}: {
  event: GameEvent | null;
  match: Detail;
  players: Player[];
  teams: Team[];
  time: number;
  rallyId: number;
  currentVideoId: number;
  onRallyChange: (id: number) => void;
  busy: boolean;
  onCancel: () => void;
  onSave: (body: Record<string, unknown>) => Promise<void>;
}) {
  const [kind, setKind] = useState(event?.kind || "serve"),
    [team, setTeam] = useState(event?.team_id || match.home_id);
  const [selectedRallyId, setSelectedRallyId] = useState(
    event?.rally_id || rallyId,
  );
  const [eventTime, setEventTime] = useState(
    event?.time ?? Number(time.toFixed(3)),
  );
  useEffect(() => {
    if (!event) {
      setSelectedRallyId(rallyId);
      const rally = match.rallies.find((r) => r.id === rallyId);
      if (rally) setEventTime(Math.max(rally.start, Math.min(time, rally.end)));
    }
  }, [rallyId, event]);
  const selectedRally = match.rallies.find((r) => r.id === selectedRallyId);
  const frameFromSameVideo = selectedRally?.video_id === currentVideoId;
  return (
    <section className="panel event-editor">
      <div className="section-heading">
        <h2>
          <Plus size={18} />
          {event ? "Исправить действие" : "Добавить действие"}
        </h2>
        <span className="badge">РУЧНОЙ ВВОД</span>
      </div>
      <form
        onSubmit={(e) => {
          e.preventDefault();
          const f = new FormData(e.currentTarget);
          const n = (k: string) => (f.get(k) === "" ? null : Number(f.get(k)));
          void onSave({
            rally_id: selectedRallyId,
            time: eventTime,
            kind,
            team_id: team,
            player_id: n("player"),
            outcome: f.get("outcome") || null,
            quality: n("quality"),
            zone_from: n("from"),
            zone_to: n("to"),
            rotation: n("rotation"),
            subtype: String(f.get("subtype") || "") || null,
          });
        }}
      >
        <div className="action-buttons">
          {Object.entries(kinds).map(([k, l]) => (
            <button
              key={k}
              type="button"
              className={kind === k ? "selected" : ""}
              onClick={() => setKind(k)}
            >
              {l}
            </button>
          ))}
        </div>
        <div className="form-row">
          <label>
            Розыгрыш
            <select
              required
              name="rally"
              value={selectedRallyId || ""}
              onChange={(e) => {
                const id = Number(e.target.value);
                setSelectedRallyId(id);
                const rally = match.rallies.find((r) => r.id === id);
                if (rally) setEventTime(rally.start);
                onRallyChange(id);
              }}
            >
              <option value="" disabled>
                Выберите розыгрыш
              </option>
              {match.rallies.map((r, i) => (
                <option key={r.id} value={r.id}>
                  #{i + 1} · {stamp(r.start)}–{stamp(r.end)} · видео #
                  {r.video_id}
                </option>
              ))}
            </select>
          </label>
          <label>
            Время, с
            <input
              required
              name="time"
              type="number"
              min={selectedRally?.start ?? 0}
              max={selectedRally?.end}
              step="0.001"
              value={eventTime}
              onChange={(e) => setEventTime(Number(e.target.value))}
            />
            <button
              className="text-button"
              type="button"
              disabled={!frameFromSameVideo}
              title={
                !frameFromSameVideo
                  ? "Выберите видео этого розыгрыша"
                  : undefined
              }
              onClick={() => setEventTime(Number(time.toFixed(3)))}
            >
              Текущий кадр
            </button>
          </label>
          <label>
            Команда
            <select
              value={team}
              onChange={(e) => setTeam(Number(e.target.value))}
            >
              {teams
                .filter((t) => [match.home_id, match.away_id].includes(t.id))
                .map((t) => (
                  <option key={t.id} value={t.id}>
                    {t.name}
                  </option>
                ))}
            </select>
          </label>
          <label>
            Игрок
            <select
              key={team}
              name="player"
              defaultValue={event?.player_id ?? ""}
            >
              <option value="">Неизвестен</option>
              {match.roster
                .filter((r) => r.team_id === team)
                .map((r) => (
                  <option key={r.player_id} value={r.player_id}>
                    #{r.number || "—"}{" "}
                    {players.find((p) => p.id === r.player_id)?.name}
                  </option>
                ))}
            </select>
          </label>
          <label>
            Результат
            <select
              key={kind}
              name="outcome"
              defaultValue={event?.kind === kind ? (event.outcome ?? "") : ""}
            >
              <option value="">Неизвестно</option>
              {Object.entries(outcomes[kind]).map(([v, l]) => (
                <option key={v} value={v}>
                  {l}
                </option>
              ))}
            </select>
          </label>
          <label>
            Качество
            <select name="quality" defaultValue={event?.quality ?? ""}>
              <option value="">Не оценено</option>
              {[0, 1, 2, 3].map((q) => (
                <option key={q} value={q}>
                  {q}
                </option>
              ))}
            </select>
          </label>
          {[
            ["from", "Из зоны", event?.zone_from],
            ["to", "В зону", event?.zone_to],
            ["rotation", "Ротация", event?.rotation],
          ].map(([key, label, v]) => (
            <label key={key}>
              {label}
              <select name={String(key)} defaultValue={v ?? ""}>
                <option value="">Неизвестно</option>
                {[1, 2, 3, 4, 5, 6].map((q) => (
                  <option key={q} value={q}>
                    {q}
                  </option>
                ))}
              </select>
            </label>
          ))}
          <label>
            Подтип
            <input
              name="subtype"
              defaultValue={event?.subtype ?? ""}
              maxLength={80}
              placeholder="Планер, pipe…"
            />
          </label>
          <button className="primary" disabled={busy || !selectedRally}>
            {event ? "Сохранить правку" : "Сохранить действие"}
          </button>
          {event && (
            <button type="button" onClick={onCancel}>
              Отмена
            </button>
          )}
        </div>
      </form>
    </section>
  );
}

function YandexImport({
  mid,
  perform,
  refresh,
}: {
  mid: number;
  perform: (fn: () => Promise<unknown>, message?: string) => Promise<void>;
  refresh: () => Promise<void>;
}) {
  const [key, setKey] = useState("https://disk.yandex.ru/d/cMooiUl8iArrng"),
    [path, setPath] = useState<string | null>(null),
    [data, setData] = useState<{
      resource: { name: string; type: string; size: number; path: string };
      items: { name: string; type: string; size: number; path: string }[];
      total: number;
    } | null>(null);
  const browse = (p: string | null) =>
    perform(async () => {
      setData(await api("/yandex/list", "POST", { public_key: key, path: p }));
      setPath(p);
    }, "Список получен");
  const download = (p: string | null) =>
    perform(async () => {
      await api(`/matches/${mid}/yandex`, "POST", { public_key: key, path: p });
      await refresh();
    }, "Видео скачано и проверено");
  return (
    <section className="panel">
      <h2>Импорт с Яндекс Диска</h2>
      <p className="muted">
        Приложение обращается к Яндексу только по вашему запросу. При
        ограничении доступа загрузите файл с компьютера.
      </p>
      <div className="form-row">
        <label className="grow">
          Публичная ссылка
          <input
            value={key}
            onChange={(e) => {
              setKey(e.target.value);
              setData(null);
            }}
          />
        </label>
        <button onClick={() => void browse(null)}>Показать файлы</button>
      </div>
      {data && (
        <div>
          <p>
            {data.resource.name}{" "}
            {path && (
              <button onClick={() => void browse(null)}>В корень</button>
            )}
          </p>
          {data.resource.type === "file" ? (
            <button onClick={() => void download(path)}>
              Скачать {(data.resource.size / 1024 ** 2).toFixed(1)} МБ
            </button>
          ) : (
            data.items.map((v) => (
              <div className="video-row" key={v.path}>
                <span>{v.name}</span>
                <small>
                  {v.type === "dir"
                    ? "Папка"
                    : `${(v.size / 1024 ** 2).toFixed(1)} МБ`}
                </small>
                <button
                  onClick={() =>
                    void (v.type === "dir" ? browse(v.path) : download(v.path))
                  }
                >
                  {v.type === "dir" ? "Открыть" : "Импортировать"}
                </button>
              </div>
            ))
          )}
          {data.total > data.items.length && (
            <p>
              Показаны первые 100 элементов. Для остальных используйте прямую
              публичную ссылку на файл.
            </p>
          )}
        </div>
      )}
    </section>
  );
}

createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
);
