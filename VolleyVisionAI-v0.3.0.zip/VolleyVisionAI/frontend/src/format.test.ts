import { describe, it, expect } from "vitest";
import { pct, stamp, outcomes } from "./types";
describe("Отображение статистики", () => {
  it("не подменяет неизвестные проценты нулём", () => {
    expect(pct(null)).toBe("—");
    expect(pct(undefined)).toBe("—");
    expect(pct(0)).toBe("0.0%");
  });
  it("сохраняет полные минуты видео", () => {
    expect(stamp(1500.5)).toBe("25:00");
    expect(stamp(61)).toBe("1:01");
  });
  it("разделяет результаты атаки и подачи", () => {
    expect(outcomes.attack.blocked).toBe("Закрыта блоком");
    expect(outcomes.serve.blocked).toBeUndefined();
  });
});

describe("invalid metric display", () => {
  it("shows missing values for nonfinite metrics", () => {
    expect(pct(Number.NaN)).toBe("—");
    expect(pct(Infinity)).toBe("—");
  });
});
