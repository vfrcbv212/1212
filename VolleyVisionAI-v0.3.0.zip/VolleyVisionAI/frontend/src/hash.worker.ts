import { Sha256 } from "./sha256";
self.onmessage = async (event: MessageEvent<File>) => {
  try {
    const file = event.data;
    const hash = new Sha256();
    const chunkSize = 1024 * 1024;
    for (let start = 0; start < file.size; start += chunkSize) {
      hash.update(
        new Uint8Array(
          await file.slice(start, start + chunkSize).arrayBuffer(),
        ),
      );
      self.postMessage({
        progress: Math.min(1, (start + chunkSize) / file.size),
      });
    }
    self.postMessage({ digest: hash.hex(), progress: 1 });
  } catch {
    self.postMessage({
      error: "Не удалось прочитать файл для проверки контрольной суммы.",
    });
  }
};
