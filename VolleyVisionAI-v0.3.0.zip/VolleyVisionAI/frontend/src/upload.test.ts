import { describe, expect, it } from "vitest";
import { Sha256, sha256 } from "./sha256";
import { missingChunks } from "./upload";
const bytes = (s: string) => new TextEncoder().encode(s);
describe("Потоковая проверка и возобновление видео", () => {
  it("проверяет известные SHA256-векторы", () => {
    expect(sha256(bytes(""))).toBe(
      "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
    );
    expect(sha256(bytes("abc"))).toBe(
      "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad",
    );
  });
  it.each([1, 55, 56, 63, 64, 65, 1024, 1048576])(
    "совпадает с независимым digest для %i байт и разрезанных блоков",
    async (size) => {
      const source = Uint8Array.from({ length: size }, (_, i) => i % 251);
      const hash = new Sha256();
      for (let i = 0; i < size; i += 37)
        hash.update(source.subarray(i, i + 37));
      const independent = await crypto.subtle.digest("SHA-256", source.buffer);
      const expected = [...new Uint8Array(independent)]
        .map((v) => v.toString(16).padStart(2, "0"))
        .join("");
      expect(hash.hex()).toBe(expected);
    },
  );
  it("не пересылает уже полученные части", () => {
    expect(missingChunks({ total_chunks: 5, received: [0, 3, 1, 1] })).toEqual([
      2, 4,
    ]);
  });
  it("не начинает новых частей для полной загрузки", () => {
    expect(missingChunks({ total_chunks: 2, received: [1, 0] })).toEqual([]);
  });
});
