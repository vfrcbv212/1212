import { errorMessage } from "./api";
import { sha256 } from "./sha256";
export type UploadState = {
  id: string;
  match_id: number;
  name: string;
  size: number;
  sha256: string;
  chunk_size: number;
  total_chunks: number;
  received: number[];
  received_bytes: number;
  status: "uploading" | "completed";
  video?: { id: number };
};
export const missingChunks = (
  state: Pick<UploadState, "total_chunks" | "received">,
) => {
  const received = new Set(state.received);
  return Array.from({ length: state.total_chunks }, (_, i) => i).filter(
    (i) => !received.has(i),
  );
};
export function hashFile(
  file: File,
  onProgress: (n: number) => void,
  signal: AbortSignal,
): Promise<string> {
  return new Promise((resolve, reject) => {
    const worker = new Worker(new URL("./hash.worker.ts", import.meta.url), {
      type: "module",
    });
    const finish = () => {
      signal.removeEventListener("abort", cancel);
      worker.terminate();
    };
    const cancel = () => {
      finish();
      reject(new DOMException("Загрузка приостановлена", "AbortError"));
    };
    signal.addEventListener("abort", cancel, { once: true });
    worker.onmessage = (
      event: MessageEvent<{
        progress?: number;
        digest?: string;
        error?: string;
      }>,
    ) => {
      if (event.data.progress !== undefined) onProgress(event.data.progress);
      if (event.data.error) {
        finish();
        reject(new Error(event.data.error));
      }
      if (event.data.digest) {
        finish();
        resolve(event.data.digest);
      }
    };
    worker.onerror = () => {
      finish();
      reject(
        new Error(
          "Не удалось запустить проверку файла. Обновите браузер и повторите.",
        ),
      );
    };
    if (signal.aborted) {
      cancel();
      return;
    }
    worker.postMessage(file);
  });
}
export async function sendChunk(
  id: string,
  index: number,
  data: Blob,
  signal: AbortSignal,
): Promise<UploadState> {
  const digest = sha256(new Uint8Array(await data.arrayBuffer()));
  const response = await fetch(
    `/api/uploads/${encodeURIComponent(id)}/chunks/${index}?sha256=${digest}`,
    { method: "PUT", body: data, signal },
  );
  if (!response.ok) {
    const error = await response.json().catch(() => null);
    throw new Error(errorMessage(error?.detail, response.status));
  }
  return response.json();
}
