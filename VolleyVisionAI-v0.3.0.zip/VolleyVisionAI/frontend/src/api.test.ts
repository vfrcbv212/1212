import { afterEach, describe, expect, it, vi } from "vitest";
import { api, errorMessage } from "./api";
afterEach(() => vi.unstubAllGlobals());
describe("HTTP errors preserve meaningful user feedback", () => {
  it("keeps API error text and formats individual validation fields", () => {
    expect(errorMessage("Событие уже изменено", 409)).toBe(
      "Событие уже изменено",
    );
    expect(
      errorMessage(
        [{ loc: ["body", "time"], msg: "Должно входить в розыгрыш" }],
        422,
      ),
    ).toBe("time: Должно входить в розыгрыш");
  });
  it("reports non-JSON upload errors without an undefined message", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn().mockResolvedValue(new Response("Too large", { status: 413 })),
    );
    await expect(api("/upload", "POST", new FormData())).rejects.toThrow(
      "Файл слишком большой",
    );
  });
  it("distinguishes a disconnected local server", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn().mockRejectedValue(new TypeError("Failed to fetch")),
    );
    await expect(api("/teams")).rejects.toThrow(
      "Нет связи с локальным сервером",
    );
  });
  it("does not JSON-encode multipart or set an incorrect boundary", async () => {
    const fetch = vi
      .fn()
      .mockResolvedValue(new Response('{"ok":true}', { status: 200 }));
    vi.stubGlobal("fetch", fetch);
    const form = new FormData();
    form.set("label", "video");
    await expect(api("/upload", "POST", form)).resolves.toEqual({ ok: true });
    expect(fetch.mock.calls[0][1].body).toBe(form);
    expect(fetch.mock.calls[0][1].headers).toBeUndefined();
  });
  it("handles a successful empty response", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn().mockResolvedValue(new Response(null, { status: 204 })),
    );
    await expect(api("/events/1", "DELETE")).resolves.toBeUndefined();
  });
});

it("tolerates malformed validation details", () => {
  expect(errorMessage([null, { loc: null, msg: null }], 422)).toContain(
    "Недопустимое значение",
  );
  expect(errorMessage([], 500)).toContain("HTTP 500");
});
