type ValidationIssue = { loc?: (string | number)[]; msg?: string };
export function errorMessage(detail: unknown, status: number): string {
  if (typeof detail === "string" && detail.trim()) return detail;
  if (Array.isArray(detail) && detail.length) {
    return detail
      .map((candidate: unknown) => {
        const issue =
          candidate !== null && typeof candidate === "object"
            ? (candidate as ValidationIssue)
            : {};
        const field = Array.isArray(issue.loc)
          ? issue.loc.filter((v) => v !== "body").join(" → ")
          : "";
        return `${field ? `${field}: ` : ""}${typeof issue.msg === "string" ? issue.msg : "Недопустимое значение"}`;
      })
      .join("; ");
  }
  if (status === 413)
    return "Файл слишком большой для загрузки. Проверьте допустимый размер.";
  return `Ошибка сервера (HTTP ${status}). Повторите операцию; если ошибка сохраняется, проверьте журнал приложения.`;
}
export async function api<T>(
  path: string,
  method = "GET",
  body?: unknown,
): Promise<T> {
  const form = body instanceof FormData;
  let response: Response;
  try {
    response = await fetch("/api" + path, {
      method,
      headers:
        body !== undefined && !form
          ? { "Content-Type": "application/json" }
          : undefined,
      body:
        body !== undefined ? (form ? body : JSON.stringify(body)) : undefined,
    });
  } catch {
    throw new Error(
      "Нет связи с локальным сервером. Убедитесь, что VolleyVision запущен, и повторите операцию. Данные формы сохранены на экране.",
    );
  }
  if (!response.ok) {
    const data = await response.json().catch(() => null);
    throw new Error(errorMessage(data?.detail, response.status));
  }
  if (response.status === 204) return undefined as T;
  return response.json();
}
