import { describe, expect, it } from "vitest";
import { inverse3, normalizedBox, normalizedPoint, project } from "./geometry";
describe("Координаты калибровки и карточек", () => {
  it("не зависит от масштаба экрана или поворота телефона", () => {
    expect(
      normalizedPoint(120, 80, { left: 20, top: 30, width: 200, height: 100 }),
    ).toEqual([0.5, 0.5]);
    expect(
      normalizedPoint(60, 55, { left: 10, top: 30, width: 100, height: 50 }),
    ).toEqual([0.5, 0.5]);
  });
  it("ограничивает касания рамкой кадра", () => {
    expect(
      normalizedPoint(-5, 999, { left: 0, top: 0, width: 100, height: 100 }),
    ).toEqual([0, 1]);
  });
  it("не создаёт область из невидимого кадра", () => {
    expect(() =>
      normalizedPoint(1, 1, { left: 0, top: 0, width: 0, height: 10 }),
    ).toThrow();
  });
  it("нормализует любой порядок углов карточки", () => {
    expect(normalizedBox([0.8, 0.9], [0.2, 0.3])).toEqual([0.2, 0.3, 0.8, 0.9]);
  });
  it("инвертирует проекцию только при определённой матрице", () => {
    const inverse = inverse3([
      [18, 0, 0],
      [0, 9, 0],
      [0, 0, 1],
    ])!;
    expect(project(inverse, [9, 4.5])).toEqual([0.5, 0.5]);
    expect(
      inverse3([
        [1, 0, 0],
        [2, 0, 0],
        [0, 0, 1],
      ]),
    ).toBeNull();
  });
  it("не рисует точки на бесконечности как реальные измерения", () => {
    expect(
      project(
        [
          [1, 0, 0],
          [0, 1, 0],
          [0, 0, 0],
        ],
        [1, 1],
      ),
    ).toBeNull();
  });
});
