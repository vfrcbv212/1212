export type Point = [number, number];
export type FloorPoint = { image: Point; court: Point };
export type CardSample = {
  time: number;
  bbox: [number, number, number, number];
};
export type PlayerCard = {
  player_id: number;
  team_id: number;
  number?: string;
  confirmed: boolean;
  samples: CardSample[];
};
export type Calibration = {
  mode: "image" | "court";
  points: FloorPoint[];
  visibility_polygon: Point[];
  frame_time: number;
  lens: "unknown" | "uncalibrated_ultrawide";
  reason?: string;
  homography?: number[][];
  reprojection_error_pixels?: number;
  image_size?: [number, number];
  projection_scope?: string;
  lens_status?: string;
};
export type VideoSetup = {
  video_id: number;
  revision: number;
  calibration: Calibration;
  cards: PlayerCard[];
  config_sha256: string;
};
export type AnalysisRun = {
  id: number;
  job_id: number;
  status: "queued" | "running" | "interrupted" | "failed" | "completed";
  progress: number;
  video_id: number;
  match_id: number;
  fingerprint: string;
  setup_sha256?: string;
  summary?: Record<string, unknown>;
  error: string | null;
  report_url: string;
  sample_fps?: number;
  strategy?: string;
  device?: string;
};
export type RuntimeInfo = {
  installed?: boolean;
  available?: boolean;
  model?: string | { name?: string; model_id?: string };
  model_id?: string;
  active_device?: string;
  device?: string;
  provider?: string;
  providers?: string[];
  error?: string;
  message?: string;
  [key: string]: unknown;
};
