import { Point } from "./analysis-types";
export function normalizedPoint(
  clientX: number,
  clientY: number,
  rect: { left: number; top: number; width: number; height: number },
): Point {
  if (rect.width <= 0 || rect.height <= 0)
    throw new Error("Кадр ещё не отображается");
  return [
    Math.max(0, Math.min(1, (clientX - rect.left) / rect.width)),
    Math.max(0, Math.min(1, (clientY - rect.top) / rect.height)),
  ];
}
export function normalizedBox(
  a: Point,
  b: Point,
): [number, number, number, number] {
  return [
    Math.min(a[0], b[0]),
    Math.min(a[1], b[1]),
    Math.max(a[0], b[0]),
    Math.max(a[1], b[1]),
  ];
}
export function inverse3(m: number[][]): number[][] | null {
  if (
    m.length !== 3 ||
    m.some((row) => row.length !== 3 || row.some((v) => !Number.isFinite(v)))
  )
    return null;
  const [[a, b, c], [d, e, f], [g, h, i]] = m;
  const A = e * i - f * h,
    B = c * h - b * i,
    C = b * f - c * e,
    D = f * g - d * i,
    E = a * i - c * g,
    F = c * d - a * f,
    G = d * h - e * g,
    H = b * g - a * h,
    I = a * e - b * d;
  const det = a * A + b * D + c * G;
  if (!Number.isFinite(det) || Math.abs(det) < 1e-12) return null;
  return [
    [A, B, C],
    [D, E, F],
    [G, H, I],
  ].map((row) => row.map((v) => v / det));
}
export function project(matrix: number[][], point: Point): Point | null {
  const denominator =
    matrix[2][0] * point[0] + matrix[2][1] * point[1] + matrix[2][2];
  if (!Number.isFinite(denominator) || Math.abs(denominator) < 1e-10)
    return null;
  const result: Point = [
    (matrix[0][0] * point[0] + matrix[0][1] * point[1] + matrix[0][2]) /
      denominator,
    (matrix[1][0] * point[0] + matrix[1][1] * point[1] + matrix[1][2]) /
      denominator,
  ];
  return result.every(Number.isFinite) ? result : null;
}
