import { useEffect, useRef, useState } from "react";
import {
  Activity,
  CheckCircle2,
  Download,
  ExternalLink,
  MapPinned,
  Play,
  Save,
  Trash2,
  Users,
} from "lucide-react";
import { api, errorMessage } from "../api";
import {
  AnalysisRun,
  Calibration,
  Point,
  RuntimeInfo,
  VideoSetup,
} from "../analysis-types";
import { Detail, Player, Team, stamp } from "../types";
import { inverse3, normalizedBox, normalizedPoint, project } from "../geometry";

const emptyCalibration: Calibration = {
  mode: "image",
  points: [],
  visibility_polygon: [],
  frame_time: 0,
  lens: "unknown",
};
const statusLabels: Record<string, string> = {
  queued: "Ожидание",
  running: "Анализируется",
  interrupted: "Прервано — можно продолжить",
  failed: "Ошибка",
  completed: "Детекция завершена",
};
function message(error: unknown) {
  return error instanceof Error
    ? error.message
    : "Не удалось выполнить операцию";
}
async function latestAnalysis(videoId: number): Promise<AnalysisRun | null> {
  const response = await fetch(`/api/videos/${videoId}/analysis/latest`);
  if (response.status === 404) return null;
  if (!response.ok) {
    const body = await response.json().catch(() => null);
    throw new Error(errorMessage(body?.detail, response.status));
  }
  return response.json();
}
export function AnalysisWorkspace({
  match,
  players,
  teams,
  initialVideoId,
}: {
  match: Detail;
  players: Player[];
  teams: Team[];
  initialVideoId: number;
}) {
  const [videoId, setVideoId] = useState(
      initialVideoId || match.videos[0]?.id || 0,
    ),
    [setup, setSetup] = useState<VideoSetup | null>(null),
    [calibration, setCalibration] = useState<Calibration>(emptyCalibration),
    [cards, setCards] = useState<VideoSetup["cards"]>([]),
    [dirty, setDirty] = useState(false),
    [loading, setLoading] = useState(false),
    [saving, setSaving] = useState(false),
    [error, setError] = useState(""),
    [notice, setNotice] = useState("");
  const [tool, setTool] = useState<"floor" | "visibility" | "card">(
      "visibility",
    ),
    [frameTime, setFrameTime] = useState(0),
    [shownTime, setShownTime] = useState(0),
    [frameLoaded, setFrameLoaded] = useState(false),
    [frameNonce, setFrameNonce] = useState(0),
    [frameSize, setFrameSize] = useState<[number, number]>([1920, 1080]),
    [firstCorner, setFirstCorner] = useState<Point | null>(null),
    [cardPlayer, setCardPlayer] = useState(match.roster[0]?.player_id || 0),
    [showGrid, setShowGrid] = useState(true);
  const [run, setRun] = useState<AnalysisRun | null>(null),
    [runtime, setRuntime] = useState<RuntimeInfo | null>(null),
    [strategy, setStrategy] = useState("fullframe"),
    [sampleFps, setSampleFps] = useState(2),
    [device, setDevice] = useState("auto"),
    [launching, setLaunching] = useState(false),
    [showReport, setShowReport] = useState(false);
  const request = useRef(0),
    report = useRef<HTMLDivElement>(null),
    opened = useRef<number | null>(null);
  const source = match.videos.find((v) => v.id === videoId);
  useEffect(() => {
    if (!match.roster.some((r) => r.player_id === cardPlayer))
      setCardPlayer(match.roster[0]?.player_id || 0);
  }, [match.roster, cardPlayer]);
  useEffect(() => {
    void api<RuntimeInfo>("/analysis/runtime")
      .then(setRuntime)
      .catch((e) => setRuntime({ error: message(e) }));
  }, []);
  useEffect(() => {
    if (!videoId) return;
    const id = ++request.current;
    setLoading(true);
    setError("");
    setNotice("");
    setSetup(null);
    // A failed load for another source must not display the previous source's cards/geometry.
    setCalibration(emptyCalibration);
    setCards([]);
    setFrameTime(0);
    setShownTime(0);
    setRun(null);
    setShowReport(false);
    setFirstCorner(null);
    setFrameLoaded(false);
    setDirty(false);
    void Promise.all([
      api<VideoSetup>(`/videos/${videoId}/setup`),
      latestAnalysis(videoId),
    ])
      .then(([config, latest]) => {
        if (id !== request.current) return;
        setSetup(config);
        setCalibration(config.calibration);
        setCards(config.cards);
        setFrameTime(config.calibration.frame_time);
        setShownTime(config.calibration.frame_time);
        setRun(latest);
        setStrategy(latest?.strategy || "fullframe");
        setSampleFps(latest?.sample_fps || 2);
        setDevice(latest?.device || "auto");
        setShowReport(latest?.status === "completed");
      })
      .catch((e) => {
        if (id === request.current) setError(message(e));
      })
      .finally(() => {
        if (id === request.current) setLoading(false);
      });
    return () => {
      request.current++;
    };
  }, [videoId]);
  useEffect(() => {
    if (!run || !["queued", "running"].includes(run.status)) return;
    let active = true;
    const tick = () =>
      void api<AnalysisRun>(`/analysis/${run.id}`)
        .then((value) => {
          if (active) setRun(value);
        })
        .catch((e) => {
          if (active)
            setError(
              `${message(e)} Задача на ПК продолжает выполняться; страница повторит запрос.`,
            );
        });
    const timer = setInterval(tick, 2000);
    return () => {
      active = false;
      clearInterval(timer);
    };
  }, [run?.id, run?.status]);
  useEffect(() => {
    if (run?.status === "completed" && opened.current !== run.id) {
      opened.current = run.id;
      setShowReport(true);
      setTimeout(
        () =>
          report.current?.scrollIntoView({
            behavior: "smooth",
            block: "start",
          }),
        100,
      );
    }
  }, [run?.id, run?.status]);
  const change = (update: Partial<Calibration>) => {
    setCalibration((c) => ({ ...c, ...update }));
    setDirty(true);
    setNotice("");
  };
  const seekFrame = () => {
    if (!source) return;
    const last = Math.max(
      0,
      source.duration - (source.fps > 0 ? 1 / source.fps : 0.05),
    );
    const time = Math.max(
      0,
      Math.min(Number.isFinite(frameTime) ? frameTime : 0, last),
    );
    setFrameTime(time);
    setShownTime(time);
    setFrameLoaded(false);
    setFrameNonce((n) => n + 1);
    setFirstCorner(null);
    change({ frame_time: time });
  };
  const selectPoint = (event: React.PointerEvent<SVGSVGElement>) => {
    if (!frameLoaded || loading || saving) return;
    event.preventDefault();
    const point = normalizedPoint(
      event.clientX,
      event.clientY,
      event.currentTarget.getBoundingClientRect(),
    );
    if (tool === "floor") {
      if (calibration.points.length >= 20) {
        setError("Для одной калибровки можно отметить до 20 опорных точек.");
        return;
      }
      change({
        points: [...calibration.points, { image: point, court: [0, 0] }],
      });
    }
    if (tool === "visibility") {
      if (calibration.visibility_polygon.length >= 30) {
        setError("Достаточно до 30 вершин области наблюдения.");
        return;
      }
      change({
        visibility_polygon: [...calibration.visibility_polygon, point],
      });
    }
    if (tool === "card") {
      if (!cardPlayer) {
        setError("Сначала добавьте игрока в состав матча.");
        return;
      }
      if (!firstCorner) {
        setFirstCorner(point);
        return;
      }
      const bbox = normalizedBox(firstCorner, point);
      setFirstCorner(null);
      if (bbox[2] - bbox[0] < 0.005 || bbox[3] - bbox[1] < 0.005) {
        setError(
          "Область слишком мала. Отметьте два противоположных угла формы игрока.",
        );
        return;
      }
      const roster = match.roster.find((r) => r.player_id === cardPlayer)!;
      const existing = cards.find((c) => c.player_id === cardPlayer);
      if ((existing?.samples.length || 0) >= 8) {
        setError("Можно сохранить до 8 кадров на одного игрока.");
        return;
      }
      const next = {
        player_id: cardPlayer,
        team_id: roster.team_id,
        number: existing?.number ?? roster.number ?? "",
        confirmed: false,
        samples: [...(existing?.samples || []), { time: shownTime, bbox }],
      };
      setCards((current) => [
        ...current.filter((c) => c.player_id !== cardPlayer),
        next,
      ]);
      setDirty(true);
      setNotice(
        "Кадр добавлен. Подтвердите личность по видимому номеру и форме.",
      );
    }
  };
  const save = async () => {
    if (!setup || saving) return;
    setSaving(true);
    setError("");
    setNotice("");
    try {
      const result = await api<VideoSetup>(`/videos/${videoId}/setup`, "PUT", {
        revision: setup.revision,
        calibration: {
          mode: calibration.mode,
          points: calibration.points,
          visibility_polygon: calibration.visibility_polygon,
          frame_time: shownTime,
          lens: calibration.lens,
        },
        cards,
      });
      setSetup(result);
      setCalibration(result.calibration);
      setCards(result.cards);
      setDirty(false);
      setNotice(
        "Начальная настройка сохранена. После запуска обязательных вопросов не будет.",
      );
    } catch (e) {
      setError(message(e));
    } finally {
      setSaving(false);
    }
  };
  const launch = async () => {
    if (!setup || dirty || launching) return;
    setLaunching(true);
    setError("");
    setNotice("");
    try {
      const result = await api<AnalysisRun>(
        `/videos/${videoId}/analysis`,
        "POST",
        {
          sample_fps: sampleFps,
          strategy,
          device,
          segment_seconds: 30,
          start: 0,
          end: null,
        },
      );
      setRun(result);
      setShowReport(result.status === "completed");
      setNotice(
        result.status === "completed"
          ? "Повторно использован готовый результат этой конфигурации."
          : "Задача сохранена на ПК. Можно закрыть страницу и открыть её позже.",
      );
    } catch (e) {
      setError(message(e));
    } finally {
      setLaunching(false);
    }
  };
  const inverse = calibration.homography
    ? inverse3(calibration.homography)
    : null;
  const gridLines: Point[][] = [];
  if (inverse && showGrid && !dirty) {
    for (const x of [0, 3, 6, 9, 12, 15, 18]) {
      const a = project(inverse, [x, 0]),
        b = project(inverse, [x, 9]);
      if (a && b) gridLines.push([a, b]);
    }
    for (const y of [0, 3, 6, 9]) {
      const a = project(inverse, [0, y]),
        b = project(inverse, [18, y]);
      if (a && b) gridLines.push([a, b]);
    }
  }
  const runActive = !!run && ["queued", "running"].includes(run.status);
  const stale =
    !!run &&
    ((Boolean(run.setup_sha256) && run.setup_sha256 !== setup?.config_sha256) ||
      (run.strategy !== undefined && run.strategy !== strategy) ||
      (run.sample_fps !== undefined && run.sample_fps !== sampleFps) ||
      (run.device !== undefined && run.device !== device));
  const modelName =
    typeof runtime?.model === "string"
      ? runtime.model
      : runtime?.model?.name || runtime?.model?.model_id || runtime?.model_id;
  return (
    <div className="analysis-workspace">
      <div className="honesty">
        <Activity size={22} />
        <div>
          <strong>Локальная детекция и проверяемый отчёт</strong>
          <p>
            Этот этап обнаруживает людей и возможный мяч. Касания, номера,
            исходы и волейбольные действия не считаются распознанными только по
            детекции объектов. Сохранённая ручная разметка не перезаписывается.
          </p>
        </div>
      </div>
      <section className="panel">
        <div className="section-heading">
          <h2>
            <MapPinned size={18} /> Один ракурс — одна настройка
          </h2>
          <select
            aria-label="Видео для автоанализа"
            value={videoId}
            onChange={(e) => {
              if (dirty) {
                setError(
                  "Сохраните или отмените несохранённую настройку перед сменой видео.",
                );
                return;
              }
              setVideoId(Number(e.target.value));
            }}
            disabled={saving || launching || loading}
          >
            {match.videos.map((v) => (
              <option key={v.id} value={v.id}>
                {v.name}
              </option>
            ))}
          </select>
        </div>
        {!source ? (
          <div className="empty small">
            Сначала импортируйте видео во вкладке «Видео и состав».
          </div>
        ) : (
          <>
            <p className="muted">
              Отметьте только видимую разметку пола. Четыре внешних угла не
              обязательны: подойдут известные пересечения линий. Когда геометрии
              недостаточно, отчёт использует координаты видео.
            </p>
            <div className="form-row frame-controls">
              <label>
                Стоп-кадр, секунды
                <input
                  aria-label="Время стоп-кадра"
                  disabled={saving || loading}
                  type="number"
                  min={0}
                  max={source.duration}
                  step="0.001"
                  value={frameTime}
                  onChange={(e) => setFrameTime(Number(e.target.value))}
                />
              </label>
              <button
                disabled={loading || saving}
                type="button"
                onClick={seekFrame}
              >
                Показать кадр
              </button>
              <label>
                Координаты
                <select
                  aria-label="Режим калибровки"
                  disabled={saving || loading}
                  value={calibration.mode}
                  onChange={(e) =>
                    change({ mode: e.target.value as "image" | "court" })
                  }
                >
                  <option value="image">
                    Координаты видео / приблизительные зоны
                  </option>
                  <option value="court">
                    Проекция пола по известным точкам
                  </option>
                </select>
              </label>
              <label>
                Объектив
                <select
                  value={calibration.lens}
                  disabled={saving || loading}
                  onChange={(e) =>
                    change({ lens: e.target.value as Calibration["lens"] })
                  }
                >
                  <option value="unknown">Параметры неизвестны</option>
                  <option value="uncalibrated_ultrawide">
                    0.5×, дисторсия не откалибрована
                  </option>
                </select>
              </label>
            </div>
            <div className="action-buttons setup-tools">
              <button
                type="button"
                className={tool === "visibility" ? "selected" : ""}
                onClick={() => {
                  setTool("visibility");
                  setFirstCorner(null);
                }}
              >
                Область наблюдения
              </button>
              <button
                type="button"
                className={tool === "floor" ? "selected" : ""}
                onClick={() => {
                  setTool("floor");
                  setFirstCorner(null);
                }}
              >
                Опорные точки пола
              </button>
              <button
                type="button"
                className={tool === "card" ? "selected" : ""}
                onClick={() => {
                  setTool("card");
                  setFirstCorner(null);
                }}
              >
                Карточка игрока
              </button>
              {inverse && (
                <label className="inline-check">
                  <input
                    type="checkbox"
                    checked={showGrid}
                    onChange={(e) => setShowGrid(e.target.checked)}
                  />{" "}
                  Проверка совмещения сетки
                </label>
              )}
            </div>
            <p className="muted">
              {tool === "visibility"
                ? "Нажимайте по границе видимой области. Три и более точки задают многоугольник; пустая область означает неизвестную видимость. Мяч над полом не ограничивается этой маской."
                : tool === "floor"
                  ? "Нажмите на известное пересечение линий, затем задайте его реальные X/Y ниже. Проекция относится только к полу, не к летящему мячу или рукам."
                  : "Выберите игрока и отметьте два противоположных угла его формы на читаемом кадре. Лица не распознаются."}
            </p>
            {tool === "card" && (
              <label className="card-player-select">
                Игрок для кадра
                <select
                  aria-label="Игрок для карточки"
                  disabled={saving || loading}
                  value={cardPlayer}
                  onChange={(e) => {
                    setCardPlayer(Number(e.target.value));
                    setFirstCorner(null);
                  }}
                >
                  {match.roster.map((r) => (
                    <option key={r.player_id} value={r.player_id}>
                      {teams.find((t) => t.id === r.team_id)?.name} · #
                      {r.number || "—"}{" "}
                      {players.find((p) => p.id === r.player_id)?.name}
                    </option>
                  ))}
                </select>
              </label>
            )}
            <div className="frame-canvas">
              {loading ? (
                <div className="empty">Загрузка настройки…</div>
              ) : (
                <>
                  <img
                    key={`${videoId}-${shownTime}-${frameNonce}`}
                    src={`/api/videos/${videoId}/frame?time=${shownTime}`}
                    alt={`Стоп-кадр ${source.name} ${stamp(shownTime)}`}
                    draggable={false}
                    onLoad={(e) => {
                      setFrameLoaded(true);
                      setFrameSize([
                        e.currentTarget.naturalWidth,
                        e.currentTarget.naturalHeight,
                      ]);
                    }}
                    onError={() => {
                      setFrameLoaded(false);
                      setError(
                        "Не удалось открыть кадр. Проверьте видео/таймкод; подготовьте прокси, если кодек не поддерживается.",
                      );
                    }}
                  />
                  {frameLoaded && (
                    <svg
                      aria-label="Разметка стоп-кадра"
                      role="img"
                      viewBox="0 0 1 1"
                      preserveAspectRatio="none"
                      onPointerDown={selectPoint}
                    >
                      {gridLines.map((line, i) => (
                        <line
                          key={`grid${i}`}
                          x1={line[0][0]}
                          y1={line[0][1]}
                          x2={line[1][0]}
                          y2={line[1][1]}
                          className="court-gridline"
                        />
                      ))}
                      {calibration.visibility_polygon.length > 1 && (
                        <polygon
                          points={calibration.visibility_polygon
                            .map((p) => p.join(","))
                            .join(" ")}
                          className="visibility-polygon"
                        />
                      )}
                      {calibration.visibility_polygon.map((p, i) => (
                        <circle
                          key={`v${i}`}
                          cx={p[0]}
                          cy={p[1]}
                          r=".006"
                          className="visibility-point"
                        />
                      ))}
                      {calibration.points.map((p, i) => (
                        <g key={`p${i}`}>
                          <circle
                            cx={p.image[0]}
                            cy={p.image[1]}
                            r=".008"
                            className="floor-point"
                          />
                          <text
                            x={p.image[0] + 0.012}
                            y={p.image[1] - 0.01}
                            fontSize=".028"
                          >
                            {i + 1}
                          </text>
                        </g>
                      ))}
                      {cards.flatMap((card) =>
                        card.samples
                          .filter((s) => Math.abs(s.time - shownTime) < 0.001)
                          .map((s, i) => (
                            <rect
                              key={`${card.player_id}-${i}`}
                              x={s.bbox[0]}
                              y={s.bbox[1]}
                              width={s.bbox[2] - s.bbox[0]}
                              height={s.bbox[3] - s.bbox[1]}
                              className="card-box"
                            />
                          )),
                      )}
                      {firstCorner && (
                        <circle
                          cx={firstCorner[0]}
                          cy={firstCorner[1]}
                          r=".008"
                          className="floor-point"
                        />
                      )}
                    </svg>
                  )}
                </>
              )}
            </div>
            <div className="setup-actions">
              <span className="badge">
                Кадр {stamp(shownTime)} · {source.width}×{source.height}
              </span>
              <button
                type="button"
                onClick={() =>
                  change({
                    visibility_polygon: calibration.visibility_polygon.slice(
                      0,
                      -1,
                    ),
                  })
                }
                disabled={
                  saving || loading || !calibration.visibility_polygon.length
                }
              >
                Убрать вершину области
              </button>
              <button
                type="button"
                onClick={() => change({ visibility_polygon: [] })}
                disabled={
                  saving || loading || !calibration.visibility_polygon.length
                }
              >
                Очистить область
              </button>
            </div>
            {calibration.points.length > 0 && (
              <div className="table-wrap">
                <table>
                  <thead>
                    <tr>
                      <th>Точка</th>
                      <th>X, м (0–18)</th>
                      <th>Y, м (0–9)</th>
                      <th>Изображение</th>
                      <th />
                    </tr>
                  </thead>
                  <tbody>
                    {calibration.points.map((point, i) => (
                      <tr key={i}>
                        <td>{i + 1}</td>
                        <td>
                          <input
                            aria-label={`Корт X точки ${i + 1}`}
                            disabled={saving || loading}
                            type="number"
                            min={0}
                            max={18}
                            step="0.01"
                            value={point.court[0]}
                            onChange={(e) =>
                              change({
                                points: calibration.points.map((p, n) =>
                                  n === i
                                    ? {
                                        ...p,
                                        court: [
                                          Number(e.target.value),
                                          p.court[1],
                                        ],
                                      }
                                    : p,
                                ),
                              })
                            }
                          />
                        </td>
                        <td>
                          <input
                            aria-label={`Корт Y точки ${i + 1}`}
                            disabled={saving || loading}
                            type="number"
                            min={0}
                            max={9}
                            step="0.01"
                            value={point.court[1]}
                            onChange={(e) =>
                              change({
                                points: calibration.points.map((p, n) =>
                                  n === i
                                    ? {
                                        ...p,
                                        court: [
                                          p.court[0],
                                          Number(e.target.value),
                                        ],
                                      }
                                    : p,
                                ),
                              })
                            }
                          />
                        </td>
                        <td>
                          {point.image.map((p) => p.toFixed(3)).join(", ")}
                        </td>
                        <td>
                          <button
                            type="button"
                            aria-label={`Удалить точку ${i + 1}`}
                            disabled={saving || loading}
                            onClick={() =>
                              change({
                                points: calibration.points.filter(
                                  (_, n) => n !== i,
                                ),
                              })
                            }
                          >
                            <Trash2 size={14} />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
            {setup && (
              <p className="muted">
                {calibration.reason ||
                  "Геометрия будет проверена при сохранении."}{" "}
                {calibration.reprojection_error_pixels !== undefined &&
                  `Ошибка совмещения опорных точек: ${calibration.reprojection_error_pixels.toFixed(2)} px.`}{" "}
                Это проверка совмещения, а не доказательство точности. Параметры
                дисторсии не определены.
              </p>
            )}
            <section className="player-cards-section">
              <h3>
                <Users size={17} /> Карточки игроков
              </h3>
              <p className="muted">
                Несколько читаемых кадров могут подтвердить номер и команду.
                Подтверждение карточки не подтверждает все действия игрока;
                треки пока не получают личность автоматически.
              </p>
              {cards.length === 0 && (
                <p className="muted">
                  Карточек пока нет. Можно продолжить с неизвестными игроками,
                  без выдуманных личных показателей.
                </p>
              )}
              <div className="player-card-grid">
                {cards.map((card) => (
                  <div className="identity-card" key={card.player_id}>
                    <strong>
                      {players.find((p) => p.id === card.player_id)?.name ||
                        `Игрок ${card.player_id}`}
                    </strong>
                    <small>
                      {teams.find((t) => t.id === card.team_id)?.name}
                    </small>
                    <label>
                      Номер на форме
                      <input
                        aria-label={`Номер карточки игрока ${card.player_id}`}
                        disabled={saving || loading}
                        value={card.number || ""}
                        maxLength={8}
                        onChange={(e) => {
                          setCards((cs) =>
                            cs.map((c) =>
                              c.player_id === card.player_id
                                ? {
                                    ...c,
                                    number: e.target.value,
                                    confirmed: false,
                                  }
                                : c,
                            ),
                          );
                          setDirty(true);
                        }}
                      />
                    </label>
                    <div className="sample-grid">
                      {card.samples.map((sample, i) => (
                        <div key={i}>
                          <svg
                            role="img"
                            aria-label={`Кадр игрока ${card.player_id} ${stamp(sample.time)}`}
                            viewBox={`${sample.bbox[0]} ${sample.bbox[1]} ${sample.bbox[2] - sample.bbox[0]} ${sample.bbox[3] - sample.bbox[1]}`}
                            style={{
                              aspectRatio:
                                ((sample.bbox[2] - sample.bbox[0]) *
                                  frameSize[0]) /
                                ((sample.bbox[3] - sample.bbox[1]) *
                                  frameSize[1]),
                            }}
                          >
                            <image
                              href={`/api/videos/${videoId}/frame?time=${sample.time}`}
                              x="0"
                              y="0"
                              width="1"
                              height="1"
                              preserveAspectRatio="none"
                            />
                          </svg>
                          <button
                            className="text-button"
                            type="button"
                            disabled={saving || loading}
                            onClick={() => {
                              setCards((cs) =>
                                cs
                                  .map((c) =>
                                    c.player_id === card.player_id
                                      ? {
                                          ...c,
                                          confirmed: false,
                                          samples: c.samples.filter(
                                            (_, n) => n !== i,
                                          ),
                                        }
                                      : c,
                                  )
                                  .filter((c) => c.samples.length),
                              );
                              setDirty(true);
                            }}
                          >
                            Убрать {stamp(sample.time)}
                          </button>
                        </div>
                      ))}
                    </div>
                    <label className="inline-check">
                      <input
                        type="checkbox"
                        checked={card.confirmed}
                        disabled={saving || loading}
                        onChange={(e) => {
                          setCards((cs) =>
                            cs.map((c) =>
                              c.player_id === card.player_id
                                ? { ...c, confirmed: e.target.checked }
                                : c,
                            ),
                          );
                          setDirty(true);
                        }}
                      />{" "}
                      Подтверждаю личность по этим кадрам
                    </label>
                  </div>
                ))}
              </div>
            </section>
            <div className="setup-save">
              <span>
                {dirty
                  ? "Есть несохранённые изменения"
                  : setup
                    ? `Сохранено · версия ${setup.revision}`
                    : "Настройка не загружена"}
              </span>
              {dirty && (
                <button
                  type="button"
                  disabled={!setup || saving || loading}
                  onClick={() => {
                    if (!setup) return;
                    setCalibration(setup.calibration);
                    setCards(setup.cards);
                    setFrameTime(setup.calibration.frame_time);
                    setShownTime(setup.calibration.frame_time);
                    setFirstCorner(null);
                    setDirty(false);
                    setError("");
                    setNotice("Несохранённые изменения отменены.");
                  }}
                >
                  Отменить несохранённые изменения
                </button>
              )}
              <button
                className="primary"
                type="button"
                disabled={!setup || saving || loading || runActive}
                onClick={() => void save()}
              >
                <Save size={15} />
                {saving ? "Сохранение…" : "Сохранить начальную настройку"}
              </button>
            </div>
          </>
        )}
      </section>
      {error && (
        <div className="alert" role="alert">
          {error}
        </div>
      )}
      {notice && (
        <div className="notice" role="status">
          {notice}
        </div>
      )}
      <section className="panel">
        <h2>
          <Play size={18} /> Анализ на домашнем ПК
        </h2>
        <p className="muted">
          {modelName ? `Модель: ${modelName}. ` : ""}
          {runtime?.active_device || runtime?.device
            ? `Устройство: ${runtime.active_device || runtime.device}. `
            : ""}
          {runtime?.provider ? `Исполнитель: ${runtime.provider}. ` : ""}
          {runtime?.error ||
            runtime?.message ||
            "Фактическое устройство и время появятся в отчёте. Автоматическая классификация волейбольных действий пока не подключена."}
        </p>
        {runtime?.installed === false && (
          <p className="alert" role="status">
            Локальные веса или AI-зависимости не установлены либо не прошли
            проверку. Выполните установку AI-модуля по README на домашнем ПК.
            Ручная разметка и её статистика доступны без нейросети.
          </p>
        )}
        <div className="form-row">
          <label>
            Область детекции
            <select
              value={strategy}
              onChange={(e) => setStrategy(e.target.value)}
              disabled={runActive}
            >
              <option value="fullframe">Полный кадр · базовый вариант</option>
              <option value="tiles">Фрагменты · экспериментально</option>
            </select>
          </label>
          <label>
            Выборка кадров, FPS
            <input
              aria-label="FPS анализа"
              type="number"
              min={0.25}
              max={10}
              step={0.25}
              value={sampleFps}
              onChange={(e) => setSampleFps(Number(e.target.value))}
              disabled={runActive}
            />
          </label>
          <label>
            Устройство
            <select
              value={device}
              onChange={(e) => setDevice(e.target.value)}
              disabled={runActive}
            >
              <option value="auto">Автоматически, с явным CPU fallback</option>
              <option value="cpu">CPU</option>
              <option value="cuda">
                CUDA · только при доступном исполнителе
              </option>
            </select>
          </label>
          <button
            type="button"
            className="primary"
            disabled={
              !source ||
              !setup ||
              dirty ||
              loading ||
              saving ||
              launching ||
              runActive ||
              runtime?.installed === false
            }
            onClick={() => void launch()}
          >
            <Play size={16} />
            {launching
              ? "Постановка в очередь…"
              : run && ["interrupted", "failed"].includes(run.status)
                ? "Возобновить анализ"
                : "Анализировать"}
          </button>
        </div>
        <p className="muted">
          Это частота предварительной детекции, не частота точного поиска
          касаний. Снижение FPS пропускает быстрые мячи; «точный» профиль без
          измерения качества не заявляется. Закрытие Safari не отменяет
          сохранённую задачу.
        </p>
        {dirty && (
          <p className="muted">Перед запуском сохраните начальную настройку.</p>
        )}
        {run && (
          <div className="analysis-progress" role="status">
            <div>
              <strong>{statusLabels[run.status] || run.status}</strong>
              <span>Задача #{run.id}</span>
            </div>
            <progress
              aria-label="Прогресс анализа"
              max={1}
              value={run.progress}
            />
            <span>{Math.round(run.progress * 100)}%</span>
            {run.error && <p className="error-text">{run.error}</p>}
            {stale && (
              <p className="alert">
                Результат создан с другой начальной настройкой или параметрами
                анализа. Для текущих параметров запустите новый анализ; старый
                отчёт сохраняется.
              </p>
            )}
            {run.status === "completed" && (
              <>
                <p>
                  Люди и возможный мяч обработаны. Номера, касания и исходы не
                  установлены этой моделью.
                </p>
                <button type="button" onClick={() => setShowReport(true)}>
                  <CheckCircle2 size={16} /> Открыть готовый отчёт
                </button>
              </>
            )}
          </div>
        )}
      </section>
      {showReport && run?.status === "completed" && (
        <section className="panel report-panel" ref={report}>
          <div className="section-heading">
            <h2>Автоматический отчёт детекции</h2>
            <a
              className="button"
              href={run.report_url}
              target="_blank"
              rel="noreferrer"
            >
              <ExternalLink size={15} /> Открыть отдельно
            </a>
          </div>
          <p className="muted">
            Отчёт содержит наблюдения, ограничения видимости и проверяемую
            статистику сохранённых событий. Ноль принятых автоматических
            действий не считается подтверждением точности распознавания.
          </p>
          <iframe
            title="Отчёт анализа"
            src={run.report_url}
            sandbox="allow-same-origin allow-downloads allow-top-navigation-by-user-activation"
          />
          <div className="filters">
            <a
              className="button"
              href={run.report_url}
              download={`volleyvision-match-${match.id}-analysis-${run.id}.html`}
            >
              <Download size={15} /> Скачать HTML-отчёт
            </a>
            {["xlsx", "json"].map((fmt) => (
              <a
                className="button"
                key={fmt}
                href={`/api/matches/${match.id}/export/${fmt}`}
              >
                <Download size={15} /> {fmt.toUpperCase()} ручной разметки
              </a>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
