import { useEffect, useRef, useState } from "react";
import { FolderOpen, Pause, Play, Upload } from "lucide-react";
import { api } from "../api";
import { hashFile, missingChunks, sendChunk, UploadState } from "../upload";

type LocalFiles = {
  configured: boolean;
  path: string;
  files: {
    path: string;
    name: string;
    size: number;
    type: "file" | "directory";
  }[];
};
export function VideoImport({
  matchId,
  onImported,
}: {
  matchId: number;
  onImported: () => Promise<void>;
}) {
  const [file, setFile] = useState<File | null>(null),
    [stage, setStage] = useState(""),
    [progress, setProgress] = useState(0),
    [error, setError] = useState(""),
    [complete, setComplete] = useState(false),
    [active, setActive] = useState(false),
    [local, setLocal] = useState<LocalFiles | null>(null),
    [localBusy, setLocalBusy] = useState(false);
  const control = useRef<AbortController | null>(null),
    mounted = useRef(true);
  useEffect(() => {
    mounted.current = true;
    return () => {
      mounted.current = false;
      control.current?.abort();
    };
  }, []);
  const run = async (source: File) => {
    if (control.current) return;
    const abort = new AbortController();
    control.current = abort;
    setActive(true);
    setError("");
    setComplete(false);
    setProgress(0);
    setStage("Проверка файла на устройстве");
    try {
      const digest = await hashFile(source, setProgress, abort.signal);
      if (abort.signal.aborted)
        throw new DOMException("Приостановлено", "AbortError");
      setStage("Передача отсутствующих частей");
      let state = await api<UploadState>(
        `/matches/${matchId}/uploads`,
        "POST",
        { name: source.name, size: source.size, sha256: digest },
      );
      setProgress(state.received_bytes / source.size);
      for (const index of missingChunks(state)) {
        if (abort.signal.aborted)
          throw new DOMException("Приостановлено", "AbortError");
        const start = index * state.chunk_size;
        state = await sendChunk(
          state.id,
          index,
          source.slice(start, Math.min(start + state.chunk_size, source.size)),
          abort.signal,
        );
        if (mounted.current) setProgress(state.received_bytes / source.size);
      }
      if (abort.signal.aborted)
        throw new DOMException("Приостановлено", "AbortError");
      setStage("Проверка целостности и метаданных");
      await api(`/uploads/${encodeURIComponent(state.id)}/finalize`, "POST");
      if (mounted.current) {
        await onImported();
        setComplete(true);
        setStage("Видео загружено");
        setProgress(1);
      }
    } catch (e) {
      if (mounted.current) {
        if ((e as Error).name === "AbortError")
          setStage("Приостановлено. Полученные части сохранены на сервере.");
        else {
          setError(
            (e as Error).message ||
              "Сеть прервалась. Выберите тот же файл и продолжите.",
          );
          setStage("Загрузка не завершена. Полученные части сохраняются.");
        }
      }
    } finally {
      control.current = null;
      if (mounted.current) setActive(false);
    }
  };
  const browse = async (path = "") => {
    setLocalBusy(true);
    setError("");
    try {
      setLocal(
        await api<LocalFiles>(
          `/local-import/files?path=${encodeURIComponent(path)}`,
        ),
      );
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setLocalBusy(false);
    }
  };
  const localImport = async (path: string) => {
    setLocalBusy(true);
    setError("");
    setComplete(false);
    try {
      await api(`/matches/${matchId}/local-import`, "POST", { path });
      if (mounted.current) {
        await onImported();
        setComplete(true);
        setStage("Видео загружено");
      }
    } catch (e) {
      if (mounted.current) setError((e as Error).message);
    } finally {
      if (mounted.current) setLocalBusy(false);
    }
  };
  return (
    <section className="panel resumable-import">
      <h2>
        <Upload size={18} /> Загрузка видео
      </h2>
      <p className="muted">
        MP4, MOV, MKV, AVI, WebM · до 20 ГБ. Файл проверяется потоково; при
        обрыве повторно передаются только недостающие части.
      </p>
      <input
        aria-label="Загрузить видео"
        type="file"
        accept="video/*,.mkv,.m4v"
        disabled={active || localBusy}
        onChange={(e) => {
          const selected = e.currentTarget.files?.[0];
          e.currentTarget.value = "";
          if (selected) {
            setFile(selected);
            void run(selected);
          }
        }}
      />
      {file && (
        <div className="upload-status">
          <div>
            <strong>{file.name}</strong>
            <small>
              {(file.size / 1024 ** 2).toFixed(1)} МиБ · {stage}
            </small>
          </div>
          <progress aria-label="Прогресс загрузки" value={progress} max={1} />
          <span>{Math.round(progress * 100)}%</span>
          {active ? (
            <button type="button" onClick={() => control.current?.abort()}>
              <Pause size={14} /> Приостановить
            </button>
          ) : (
            !complete && (
              <button type="button" onClick={() => void run(file)}>
                <Play size={14} /> Продолжить
              </button>
            )
          )}
        </div>
      )}
      {complete && (
        <p className="notice" role="status">
          Видео загружено
        </p>
      )}
      {error && (
        <p className="alert" role="alert">
          {error}
        </p>
      )}
      <p className="muted">
        После закрытия Safari выберите тот же файл заново: сервер проверит его
        SHA-256 и продолжит загрузку. Это не запускает анализ повторно.
      </p>
      <button
        type="button"
        disabled={active || localBusy}
        onClick={() => void browse("")}
      >
        <FolderOpen size={15} /> Выбрать файл на домашнем ПК
      </button>
      {local && (
        <div className="local-import-list">
          {!local.configured ? (
            <p className="muted">
              Папка импорта на ПК не настроена. Укажите разрешённую папку в
              VOLLEYVISION_IMPORT_ROOT и перезапустите приложение. Её содержимое
              не публикуется как статика.
            </p>
          ) : (
            <>
              <div className="section-heading">
                <strong>{local.path || "Разрешённая папка"}</strong>
                {local.path && (
                  <button
                    type="button"
                    disabled={localBusy}
                    onClick={() =>
                      void browse(local.path.split("/").slice(0, -1).join("/"))
                    }
                  >
                    Вверх
                  </button>
                )}
              </div>
              {local.files.length === 0 && (
                <p className="muted">Папка пуста.</p>
              )}
              {local.files.map((entry) => (
                <div className="video-row" key={entry.path}>
                  <span>{entry.name}</span>
                  <small>
                    {entry.type === "directory"
                      ? "Папка"
                      : `${(entry.size / 1024 ** 2).toFixed(1)} МиБ`}
                  </small>
                  <button
                    disabled={localBusy || active}
                    type="button"
                    onClick={() =>
                      void (entry.type === "directory"
                        ? browse(entry.path)
                        : localImport(entry.path))
                    }
                  >
                    {entry.type === "directory"
                      ? "Открыть"
                      : "Импортировать без передачи по сети"}
                  </button>
                </div>
              ))}
            </>
          )}
        </div>
      )}
    </section>
  );
}
